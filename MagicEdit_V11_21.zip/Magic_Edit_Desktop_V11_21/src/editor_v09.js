// V09: paragrafos por sinais reconhecidos e respiracoes; nao inventa texto.
// Silencios sao verificados tambem pela energia REAL do audio, quando disponivel.
import {suggestSilences, mergeIntervals} from './engine.js';
import {cutWordIndices} from './selection.js';

export function groupParagraphs(words, maxWords=38) {
  if (!Array.isArray(words) || words.length===0) return [];
  const groups=[]; let first=0;
  for (let i=0;i<words.length;i++) {
    const word=String(words[i]?.word||'');
    const next=words[i+1];
    const count=i-first+1;
    const gap=next ? next.start-words[i].end : 0;
    const endPunctuation=/[.!?…]["”’)]?$/.test(word);
    const split=!next || gap>=1.25 || count>=maxWords || (endPunctuation && count>=10) || (gap>=.65 && count>=14);
    if(split){groups.push({start:first,end:i});first=i+1;}
  }
  return groups;
}

// Mantem o corte temporal intacto e oferece um ponto para restaura-lo no texto.
export function transcriptCutMarkers(words, cuts) {
  const markers=new Map(), covered=new Set();
  if(!Array.isArray(words)||!Array.isArray(cuts))return {markers,covered};
  const coverage=cutWordIndices(words,cuts);
  for(let i=0;i<cuts.length;i++){
    const cut=cuts[i];
    if(!Number.isFinite(cut.start)||!Number.isFinite(cut.end)||cut.end<=cut.start)continue;
    if((coverage.byCut.get(i)||[]).length)continue;
    const at=words.findIndex(w=>w.end>cut.start);
    const index=at<0?words.length:at;
    if(!markers.has(index))markers.set(index,[]);
    markers.get(index).push({...cut,index:i});
  }
  for(const idx of coverage.covered)covered.add(idx);
  return {markers,covered};
}

function configuredSilenceProtection(words,speech,duration,edge,padding){
  const parts=speech.map(s=>{
    const rawStart=s.start<=0?0:s.start+padding;
    const rawEnd=s.end>=duration?duration:s.end-padding;
    return {start:Math.max(0,s.start-(padding?0:edge)),end:Math.min(duration,s.end+(padding?0:edge)),
      rawStart:rawEnd>rawStart?rawStart:s.start,rawEnd:rawEnd>rawStart?rawEnd:s.end};
  }).concat(words.map(w=>({start:Math.max(0,w.start-edge),end:Math.min(duration,w.end+edge),rawStart:w.start,rawEnd:w.end})))
    .filter(s=>Number.isFinite(s.start)&&Number.isFinite(s.end)&&s.end>=s.start)
    .sort((a,b)=>a.start-b.start||a.end-b.end);
  const merged=[];
  for(const part of parts){
    const last=merged.at(-1);
    if(last&&part.start<=last.end){last.end=Math.max(last.end,part.end);last.rawStart=Math.min(last.rawStart,part.rawStart);last.rawEnd=Math.max(last.rawEnd,part.rawEnd);}
    else merged.push({...part});
  }
  return merged;
}

export function detectVerifiedSilences(words, duration, peaks, rate=20, options={}) {
  // Nunca inferir silencio da falta de palavras. VAD e energia sao sinais independentes.
  const speech=options.speech;
  if(!Array.isArray(speech)||!Array.isArray(words)||!Array.isArray(peaks)||!peaks.length||!Number.isFinite(rate)||rate<=0)return [];
  // Cada nivel inclui os cortes mais cautelosos. Mover o controle para a
  // direita jamais deve restaurar uma pausa por acidente.
  if(!options._single){
    const selected=Math.max(0,Math.min(100,Number(options.strength??50)));
    return mergeIntervals([0,25,50,75,100].filter(x=>x<=selected).flatMap(strength=>
      detectVerifiedSilences(words,duration,peaks,rate,{...options,strength,_single:true})),duration);
  }
  const norm=Math.max(8,options.norm??100);
  const cutoff=Math.max(3,Math.min(18,Math.round(norm*.07)));
  const strength=Math.max(0,Math.min(1,Number(options.strength??50)/100));
  const configured=Number.isFinite(options.minSilenceSeconds)&&options.minSilenceSeconds>=.3&&options.minSilenceSeconds<=10;
  const minPause=configured?options.minSilenceSeconds:0;
  // O limite explicito mede a pausa ANTES das margens. A margem nao deve
  // transformar uma pausa de 0,8 s em uma pausa curta demais para o limite 0,7.
  const edge=configured?Math.min(.16-.08*strength,Math.max(.08,minPause*.2)):.28-.16*strength;
  const minLength=configured ? .12 : 1.65-.9*strength;
  const vadPad=configured?0:.12,wordPad=configured?0:.30;
  const padding=Number.isFinite(options.speechPadding)?Math.max(0,options.speechPadding):0;
  const protectedRanges=configured?configuredSilenceProtection(words,speech,duration,edge,padding):mergeIntervals([
    ...speech.map(x=>({start:Math.max(0,x.start-vadPad),end:Math.min(duration,x.end+vadPad)})),
    ...words.filter(x=>Number.isFinite(x.start)&&Number.isFinite(x.end)).map(x=>({start:Math.max(0,x.start-wordPad),end:Math.min(duration,x.end+wordPad)}))
  ],duration,configured?0:.02);
  const accepted=[];
  let cursor=0,rawCursor=0;
  for(const protectedRange of [...protectedRanges,{start:duration,end:duration,rawStart:duration,rawEnd:duration}]){
    const rawGap=(configured?protectedRange.rawStart:protectedRange.start)-rawCursor;
    const start=cursor+(configured?0:edge),end=protectedRange.start-(configured?0:edge);
    cursor=Math.max(cursor,protectedRange.end);
    rawCursor=Math.max(rawCursor,configured?protectedRange.rawEnd:protectedRange.end);
    if(configured&&rawGap<=minPause+1e-8)continue;
    if(end-start<minLength)continue;
    const from=Math.max(0,Math.ceil(start*rate)),to=Math.min(peaks.length,Math.floor(end*rate));
    if(to-from<(configured?2:Math.ceil(rate*minLength*.9)))continue;
    let quiet=0,total=0,energy=0,noisyRun=0,longestNoise=0,quietRun=0,longestQuiet=0;
    const levels=new Uint32Array(256);
    for(let i=from;i<to;i++) {
      const p=peaks[i];if(!Number.isFinite(p))continue;
      total++;energy+=p;levels[Math.max(0,Math.min(255,Math.round(p)))]++;
      if(p<=cutoff){quiet++;quietRun++;longestQuiet=Math.max(longestQuiet,quietRun);noisyRun=0;}
      else{noisyRun++;longestNoise=Math.max(longestNoise,noisyRun);quietRun=0;}
    }
    // Silero sem voz + grande maioria de audio baixo. Picos breves (tosse,
    // batida) sao permitidos, mas som sustentado sem legenda continua protegido.
    // Um ruido constante de microfone pode ficar acima do limite de silencio
    // absoluto. Aceitar apenas a faixa inteira com energia baixa e estavel,
    // depois de excluir voz Silero e todas as palavras com margens generosas.
    const percentile=quantile=>{
      const target=Math.ceil(total*quantile);let count=0;
      for(let level=0;level<levels.length;level++)if((count+=levels[level])>=target)return level;
      return 255;
    };
    const backgroundLimit=Math.max(cutoff,Math.min(24,Math.round(norm*(.13+.06*strength))));
    const spikeLimit=Math.max(backgroundLimit+5,Math.min(34,Math.round(norm*.24)));
    const stableBackground=total>0&&percentile(.90)<=backgroundLimit&&
      percentile(.99)<=spikeLimit&&energy/total<=backgroundLimit*(.78+.08*strength);
    const nearlyMute=total>0&&quiet/total>=.98&&energy/total<=cutoff*.5;
    const briefNoise=total>0&&end-start>=3&&quiet/total>=.78&&longestNoise/rate<=.85&&longestQuiet/rate>=.85;
    let low=0,run=0,longestBurst=0,lowRun=0,longestLow=0;
    for(let i=from;i<to;i++){
      const p=peaks[i];if(!Number.isFinite(p))continue;
      if(p<=backgroundLimit){low++;lowRun++;longestLow=Math.max(longestLow,lowRun);run=0;}
      else{run++;longestBurst=Math.max(longestBurst,run);lowRun=0;}
    }
    // Forte: permite uma tosse ou batida breve DENTRO de uma pausa sem voz.
    // Se Silero marcou voz, o intervalo ja foi excluido acima.
    const briefBurst=strength>=.75&&total>0&&end-start>=2.5&&low/total>=.68&&
      longestBurst/rate<=.75&&longestLow/rate>=.6&&energy/total<=backgroundLimit*2.2;
    const required=configured?Math.ceil((Math.floor(end*rate)-from)*.95):Math.ceil((end-start)*rate*.9);
    if(total>=required&&(nearlyMute||briefNoise||stableBackground||briefBurst))accepted.push({start,end});
  }
  return mergeIntervals(accepted,duration);
}

// O VAD pode classificar uma tosse como voz; nesses casos apenas oferecer
// audicao e selecao manual, sem transformar ausencia de legenda em corte.
export function reviewableAudioGaps(words,duration,peaks,rate=20,options={}){
  if(!Array.isArray(words)||!words.length||!Array.isArray(peaks)||!peaks.length||!Array.isArray(options.speech))return [];
  const threshold=Math.max(14,(options.norm||100)*.22);
  return suggestSilences(words,duration,.9,.14).map(gap=>{
    const speech=options.speech.some(s=>Math.min(s.end,gap.end)-Math.max(s.start,gap.start)>.14);
    const from=Math.max(0,Math.floor(gap.start*rate)),to=Math.min(peaks.length,Math.ceil(gap.end*rate));
    const audible=peaks.slice(from,to).some(p=>p>=threshold);
    return speech||audible?{start:gap.start,end:gap.end,reason:speech?'Possível voz sem texto':'Ruído ou tosse possível'}:null;
  }).filter(Boolean);
}

// Energia sem legenda pode ser fala nao reconhecida, musica ou ruido: somente alerta.
export function findUntranscribedGaps(words,duration,peaks,rate=20,options={}){
  if(!Array.isArray(words)||!Array.isArray(peaks)||!peaks.length||!Number.isFinite(rate)||rate<=0)return [];
  const bounds=[{end:0},...words,{start:duration}],warnings=[];
  const threshold=Math.max(10,(options.norm||100)*.18);
  for(let j=0;j<bounds.length-1;j++){
    const left=bounds[j].end??0,right=bounds[j+1].start??duration;
    if(right-left<1.1)continue;
    const first=Math.ceil((left+.12)*rate),last=Math.min(peaks.length,Math.floor((right-.12)*rate));
    let start=-1;
    for(let i=first;i<=last;i++){
      const audible=i<last&&peaks[i]>=threshold;
      if(audible&&start<0)start=i;
      if(!audible&&start>=0){
        if((i-start)/rate>=.6)warnings.push({start:start/rate,end:i/rate});
        start=-1;
      }
    }
  }
  return warnings;
}

export function timeAtClientX(clientX,rect,view){
  return Math.max(0,Math.min(view.duration,view.start+Math.max(0,Math.min(1,(clientX-rect.left)/rect.width))*view.span));
}
