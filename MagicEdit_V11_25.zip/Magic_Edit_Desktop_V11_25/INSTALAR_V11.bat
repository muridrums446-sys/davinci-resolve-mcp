@echo off
call "%~dp0ATUALIZAR_V11_25_CASA.bat"
exit /b %ERRORLEVEL%
