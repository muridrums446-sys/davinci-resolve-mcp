"""Real local server/Chromium/FFmpeg; simulated Google model HTTP boundary."""
import argparse,io,json,os,subprocess,sys,threading
from pathlib import Path
from http.server import ThreadingHTTPServer
from unittest.mock import patch
from urllib.error import HTTPError
ROOT=Path(__file__).resolve().parents[1]
def main():
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);args=p.parse_args()
 out=args.output.resolve();out.mkdir(parents=True,exist_ok=True);os.environ['APPDATA']=str(out/'settings');sys.path.insert(0,str(ROOT))
 import magicedit_server as app
 import gemini_audio as ga
 from playwright.sync_api import sync_playwright
 video=out/'original.mp4';subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i','color=c=blue:s=320x180:r=25:d=3','-f','lavfi','-i',
  'sine=frequency=440:sample_rate=16000:duration=3','-shortest','-c:v','libx264','-preset','ultrafast','-c:a','aac','-y',str(video)],check=True)
 project=out/'projeto.json';project.write_text(json.dumps({'schema':1,'path':str(video),'media':app.probe_video(str(video)),
 'words':[{'word':'teste','start':1,'end':1.5}],'deletedIndices':[],'extraCuts':[]}))
 key='AIza_dummy_key_for_tests_only_123456789';mode='failure';entered=threading.Event();release=threading.Event();checks=[];errors=[];calls=[]
 class Reply:
  def __enter__(self):return self
  def __exit__(self,*_):pass
  def read(self,_):return json.dumps({'models':[{'name':'models/gemini-test-flash','displayName':'Gemini teste','supportedGenerationMethods':['generateContent']}]}).encode()
 class Opener:
  def open(self,request,timeout):
   assert request.get_header('X-goog-api-key')==key
   assert key not in request.full_url
   assert ':generateContent' not in request.full_url
   calls.append(request.full_url);entered.set();release.wait(10)
   if mode=='failure':
    body=json.dumps({'error':{'message':key,'details':[{'reason':'SERVICE_DISABLED'}]}}).encode()
    raise HTTPError(request.full_url,403,key,{},io.BytesIO(body))
   return Reply()
 server=ThreadingHTTPServer(('127.0.0.1',0),app.Handler);threading.Thread(target=server.serve_forever,daemon=True).start()
 try:
  with patch.object(app,'native_file_dialog',return_value=str(project)),patch.object(ga,'build_opener',return_value=Opener()),sync_playwright() as pw:
   browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox']);page=browser.new_page(viewport={'width':1366,'height':900});page.on('pageerror',lambda e:errors.append(str(e)))
   page.goto(f'http://127.0.0.1:{server.server_port}/');page.locator('#homeOpen').click();page.wait_for_selector('.word')
   page.locator('#toolsMenu > summary').click();page.locator('#geminiPanel > summary').click();page.locator('#geminiKey').fill(key)
   page.locator('#geminiModels').click();assert entered.wait(5)
   assert 'Consultando' in page.locator('#geminiModels').inner_text(),'lookup button has no loading feedback'
   assert page.locator('#geminiModelsStatus').is_visible(),'lookup status missing beside button'
   release.set();page.wait_for_function('!document.getElementById("geminiModels").disabled')
   status=page.locator('#geminiModelsStatus');assert 'Generative Language API' in status.inner_text()
   assert status.get_attribute('data-state')=='error'
   # It must actually be within the scroll viewport, not just present in DOM.
   assert status.evaluate('(el)=>{const a=el.getBoundingClientRect(),b=el.closest(".tools-popover").getBoundingClientRect();return a.top>=b.top&&a.bottom<=b.bottom}')
   assert key not in status.inner_text();assert page.locator('#geminiAnalyze').is_disabled()
   page.screenshot(path=str(out/'erro-modelos-visivel.png'),full_page=True)
   text=status.inner_text();page.evaluate('document.getElementById("geminiAnalyze").click()');assert status.inner_text()==text
   checks.append('Erro403 estruturado ao lado do botao, visivel sem procurar abaixo; nao expoe chave nem e apagado por analisar')
   mode='success';page.locator('#geminiModels').click();page.wait_for_function('document.querySelectorAll("#geminiModel option").length>1')
   assert status.get_attribute('data-state')=='success';assert page.locator('#geminiAnalyze').is_disabled()
   page.locator('#geminiModel').select_option('gemini-test-flash');assert page.locator('#geminiAnalyze').is_enabled()
   checks.append('Sucesso preenche lista, exige escolher modelo e libera analise sem troca automatica')
   page.locator('#geminiKey').fill(key+'x');assert page.locator('#geminiAnalyze').is_disabled();assert page.locator('#geminiModel').input_value()==''
   checks.append('Alterar chave limpa selecao antiga e impede uso de lista desatualizada')
   page.locator('#geminiKey').fill(key)
   page.route('**/api/gemini_models',lambda route:route.fulfill(status=404,content_type='application/json',body='{"error":"Rota nao encontrada."}'))
   page.locator('#geminiModels').click();page.wait_for_function('!document.getElementById("geminiModels").disabled')
   assert 'servidor' in status.inner_text().lower();assert 'INICIAR_MAGIC_EDIT' in status.inner_text()
   checks.append('Servidor antigo404 orienta reiniciar pela pasta definitiva, sem recriar chave')
   page.unroute('**/api/gemini_models');pending=[]
   page.route('**/api/gemini_models',lambda route:pending.append(route))
   page.clock.install();page.locator('#geminiModels').click();page.wait_for_function('document.getElementById("geminiModels").disabled')
   page.clock.fast_forward(46000);page.wait_for_function('!document.getElementById("geminiModels").disabled')
   assert 'tempo' in status.inner_text().lower();assert status.get_attribute('data-state')=='error';assert page.locator('#geminiAnalyze').is_disabled()
   checks.append('Consulta travada expira45s com mensagem visivel e botoes recuperados')
   assert not errors,errors
   assert key not in page.evaluate('JSON.stringify({...localStorage})')
   report={'checks':checks,'errors':errors,'realChromium':True,'realHTTP':True,'realFFmpeg':True,'googleHTTPTransportSimulated':True,'liveGoogle':False,'windows':False}
   (out/'resultado.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
   for route in pending:
    try:route.abort()
    except Exception:pass
   page.unroute_all(behavior='ignoreErrors');browser.close()
 finally:release.set();server.shutdown();server.server_close();app.WORKDIR.cleanup()
 print(json.dumps({'checks':len(checks),'errors':errors}))
if __name__=='__main__':main()
