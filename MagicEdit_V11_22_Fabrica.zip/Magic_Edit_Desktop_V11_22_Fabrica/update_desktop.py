"""Atualizacao cumulativa local: backup integral verificado antes de qualquer troca."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
from datetime import datetime
from pathlib import Path

VERSION='0.11.22'
# JavaScript da distribuicao validada na nuvem; Node nao e dependencia do aplicativo.
JS_SHA256={
    'src/autoedit.js': 'a2e144f6fc3065bf8735737370ffdf118e3a239c398476fff2c230391d5d0ba1',
    'src/editor_v09.js': '36801529f0d5c64e8e663cf2e6e5c95f520af7acc1351b5f14988bda48fded96',
    'src/engine.js': '043507644358f35044c1951162f3b5df3f328b818e26d941c6a3e11c5eb5f58a',
    'src/main.js': '7eef2aea97a585ebe24df94bbfb89a81697f27133f91a67b47cb9c094160d7ae',
    'src/preview_v11.js': 'ef1570ad389cb19a194d6b862f0361ed03a138bf944d3f807b33573901806c6a',
    'src/selection.js': '666e0c76d0cd9d470e8dc54aefe48735710a87d476ec919511d32de6787e50fb',
    'src/word_hit.js': '32874ee7b0d780c3578895ad626007d1687482a1ad30bc42cae00fa2f202fb56',
}
FILES=(
    'magicedit_server.py','audio_wave.py','vad_local.py','mp4_export.py','resolve_export.py','review_takes.py',
    'silero_vad.onnx','SILERO_LICENSE.txt','package.json','index.html','INICIAR_MAGIC_EDIT.bat',
    'PREPARAR_GROQ.bat','VERIFICAR_REQUISITOS.bat','LEIA_PRIMEIRO.txt','update_desktop.py',
    'INSTALAR_V11.py','INSTALAR_V11.bat','ATUALIZAR_V11_22.bat',
    'src/main.js','src/style.css','src/engine.js','src/autoedit.js','src/editor_v09.js',
    'src/selection.js','src/preview_v11.js','src/word_hit.js',
)
# Lista fechada dos testes e ferramentas desta versao; nao copiar arquivos arbitrarios.
FILES += (
    'tests/autoedit.test.mjs',
    'tests/candidate_words.test.mjs',
    'tests/editor_v09.test.mjs',
    'tests/engine.test.mjs',
    'tests/fixtures/V11_17_patch/ATUALIZAR_V11_17.bat',
    'tests/fixtures/V11_17_patch/ATUALIZAR_V11_17.py',
    'tests/fixtures/V11_17_patch/LEIA_V11_17.txt',
    'tests/fixtures/V11_17_patch/arquivos/INICIAR_MAGIC_EDIT.bat',
    'tests/fixtures/V11_17_patch/arquivos/SILERO_LICENSE.txt',
    'tests/fixtures/V11_17_patch/arquivos/audio_wave.py',
    'tests/fixtures/V11_17_patch/arquivos/index.html',
    'tests/fixtures/V11_17_patch/arquivos/magicedit_server.py',
    'tests/fixtures/V11_17_patch/arquivos/mp4_export.py',
    'tests/fixtures/V11_17_patch/arquivos/package.json',
    'tests/fixtures/V11_17_patch/arquivos/review_takes.py',
    'tests/fixtures/V11_17_patch/arquivos/silero_vad.onnx',
    'tests/fixtures/V11_17_patch/arquivos/src/autoedit.js',
    'tests/fixtures/V11_17_patch/arquivos/src/editor_v09.js',
    'tests/fixtures/V11_17_patch/arquivos/src/engine.js',
    'tests/fixtures/V11_17_patch/arquivos/src/main.js',
    'tests/fixtures/V11_17_patch/arquivos/src/preview_v11.js',
    'tests/fixtures/V11_17_patch/arquivos/src/selection.js',
    'tests/fixtures/V11_17_patch/arquivos/src/style.css',
    'tests/fixtures/V11_17_patch/arquivos/src/word_hit.js',
    'tests/fixtures/V11_17_patch/arquivos/vad_local.py',
    'tests/home_flow.test.mjs',
    'tests/preview_v11.test.mjs',
    'tests/selection.test.mjs',
    'tests/selection_word_v07.test.mjs',
    'tests/speech_safety.test.mjs',
    'tests/repeats_v19.test.mjs',
    'tests/repeats_v21.test.mjs',
    'tests/timeline_drag.test.mjs',
    'tests/timeline_toggle.test.mjs',
    'tests/silences_v21.test.mjs',
    'tests/export_selection.test.mjs',
    'tests/silences_v22.test.mjs',
    'tests/test_audio_wave.py',
    'tests/test_automatic_context.py',
    'tests/test_autosave_v11.py',
    'tests/test_groq_sdk_mock.py',
    'tests/test_installer_v11.py',
    'tests/test_mp4_export.py',
    'tests/test_resolve_export.py',
    'tests/test_probe_timing.py',
    'tests/test_short_silences_audio.py',
    'tests/test_review_groq_mock.py',
    'tests/test_review_takes.py',
    'tests/test_speech_boundaries.py',
    'tests/test_static_routes.py',
    'tests/test_upgrade_v11_10.py',
    'tests/test_upgrade_v11_11.py',
    'tests/test_upgrade_v11_12.py',
    'tests/test_upgrade_v11_13.py',
    'tests/test_upgrade_v11_14.py',
    'tests/test_upgrade_v11_15.py',
    'tests/test_upgrade_v11_16.py',
    'tests/test_upgrade_v11_17.py',
    'tests/test_upgrade_v11_18.py',
    'tests/test_upgrade_v11_19.py',
    'tests/test_upgrade_factory.py',
    'tests/test_updater_without_node.py',
    'tests/test_v11_routes.py',
    'tests/test_vad_local.py',
    'tests/test_xml_v11.py',
    'tests/word_hit.test.mjs',
    'validacao/comparar_amostras.py',
    'validacao/interface_real.py',
    'validacao/interface_selection_v22.py',
)

FILES += (
    'RELATORIO_VALIDACAO.md',
    'evidencias/arquivos-alterados.json',
    'evidencias/comparacao.json',
    'evidencias/cortes-auditaveis.png',
    'evidencias/editor.png',
    'evidencias/selecao-manual.png',
    'evidencias/resolve-exportado.png',
    'evidencias/fcpxml-referencia.json',
    'evidencias/interface.json',
    'evidencias/interface-selecao-v11-22.json',
    'evidencias/selecao-leve.png',
    'evidencias/mp4-concluido.png',
    'evidencias/responsividade-v11-18.json',
    'evidencias/testes-node.txt',
    'evidencias/testes-python.txt',
    'evidencias/upgrade.json',
)


def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        while block:=f.read(4*1024*1024):h.update(block)
    return h.hexdigest()

def inventory(folder):
    result={}
    for path in sorted(folder.rglob('*')):
        if path.is_symlink() or getattr(path,'is_junction',lambda:False)():
            raise RuntimeError('Link ou juncao encontrado; backup exige arquivos locais independentes: '+str(path))
        if path.is_file():result[path.relative_to(folder).as_posix()]={'size':path.stat().st_size,'sha256':digest(path)}
    return result

def verify_project(folder,target):
    env=dict(os.environ)
    env['PYTHONDONTWRITEBYTECODE']='1'
    env['PATH']=str(target)+os.pathsep+env.get('PATH','')
    # compile() valida sem gravar __pycache__ na instalacao em uso.
    for path in folder.glob('*.py'):compile(path.read_text('utf-8-sig'),str(path),'exec')
    expected_js={rel for rel in FILES if rel.startswith('src/') and rel.endswith('.js')}
    if set(JS_SHA256)!=expected_js:
        raise RuntimeError('Manifesto JavaScript incompleto. Nada foi alterado.')
    for rel,expected in JS_SHA256.items():
        path=folder/rel
        if not path.is_file() or digest(path)!=expected:
            raise RuntimeError('JavaScript diferente do pacote validado: '+rel)
    node=shutil.which('node',path=env['PATH'])
    if node:
        for rel in sorted(expected_js):
            subprocess.run([node,'--check',str(folder/rel)],check=True,cwd=folder,env=env)
    else:
        print('Node.js opcional ausente: JavaScript conferido por SHA-256 contra a versao validada. Continuando.',flush=True)
    subprocess.run([sys.executable,'-B','-c',
        'import groq,numpy,onnxruntime; import magicedit_server as app; '
        'from vad_local import MODEL,MODEL_SHA256; import hashlib; '
        'assert hashlib.sha256(MODEL.read_bytes()).hexdigest()==MODEL_SHA256; '
        'app.WORKDIR.cleanup()'],cwd=folder,env=env,check=True)
    for name in ('ffmpeg','ffprobe'):
        local=target/(name+('.exe' if os.name=='nt' else ''))
        if not shutil.which(name,path=env['PATH']) and not local.is_file():
            raise RuntimeError(name+' ausente: instale ou mantenha na pasta definitiva.')

def install(source,target,verify=verify_project,copy=shutil.copy2):
    requested=Path(target)
    if requested.is_symlink() or getattr(requested,'is_junction',lambda:False)():
        raise RuntimeError('Desktop_V10 precisa ser uma pasta local, sem link ou juncao.')
    source,target=Path(source).resolve(),Path(target).resolve()
    allowed_names={'desktop_v10','magicedit_desktop_v11'}
    protected=any(p.casefold() in {'motion','remotion','src'} or p.casefold().startswith('_backup_') for p in target.parts)
    if target.name.casefold() not in allowed_names or protected:
        raise RuntimeError('Atualize somente Desktop_V10 ou MagicEdit_Desktop_V11; backups, src, Motion e Remotion sao protegidos.')
    if source==target or source in target.parents or target in source.parents:
        raise RuntimeError('Extraia o pacote fora da pasta definitiva. Nada foi alterado.')
    if not all((target/p).is_file() for p in ('magicedit_server.py','src/main.js','package.json')):
        raise RuntimeError('Instalacao Magic Edit nao encontrada. Nada foi alterado.')
    try:current=json.loads((target/'package.json').read_text('utf-8-sig'))['version']
    except (ValueError,OSError,KeyError) as exc:raise RuntimeError('Versao instalada ilegivel. Nada foi alterado.') from exc
    if not isinstance(current,str) or not re.fullmatch(r'0\.(?:10\.\d+|11\.(?:[0-9]|1[0-9]|2[0-2]))',current):
        raise RuntimeError('Versao nao suportada: '+str(current)+'. Nada foi alterado.')
    missing=[p for p in FILES if not (source/p).is_file()]
    if missing:raise RuntimeError('Pacote incompleto: '+', '.join(missing))
    if json.loads((source/'package.json').read_text('utf-8-sig')).get('version')!=VERSION:
        raise RuntimeError('Versao do pacote incorreta. Nada foi alterado.')
    # Rejeitar symlinks/juncoes antes de tocar em qualquer arquivo de destino.
    before=inventory(target)
    print('Versao instalada:',current,'; atualizacao:',VERSION,flush=True)
    verify(source,target)
    required=sum(x['size'] for x in before.values())+sum((source/p).stat().st_size for p in FILES)
    if shutil.disk_usage(target.parent).free < required*1.1+20_000_000:
        raise RuntimeError('Espaco insuficiente para backup integral. Nada foi alterado.')
    backup=target.parent/('_BACKUP_'+target.name+'_preV11_22_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f'))
    print('Copiando e verificando backup integral:',backup,flush=True)
    shutil.copytree(target,backup,symlinks=False)
    if inventory(backup)!=before or inventory(target)!=before:
        raise RuntimeError('Verificacao do backup falhou ou a instalacao mudou. Feche o programa e tente novamente; destino preservado.')
    manifest=backup.with_suffix('.manifest.json')
    manifest.write_text(json.dumps({'versionBefore':current,'backup':str(backup),'target':str(target),'files':before},ensure_ascii=False,indent=2),'utf-8')
    installed=[]
    try:
        for rel in FILES:
            dest=target/rel;dest.parent.mkdir(parents=True,exist_ok=True)
            pending=dest.with_name(dest.name+'.v1122-pending')
            try:
                copy(source/rel,pending)
                if digest(pending)!=digest(source/rel):raise RuntimeError('Copia incompleta: '+rel)
                os.replace(pending,dest);installed.append(rel)
            finally:pending.unlink(missing_ok=True)
        verify(target,target)
    except Exception:
        for rel in reversed(installed):
            dest=target/rel
            if (backup/rel).is_file():shutil.copy2(backup/rel,dest)
            else:dest.unlink(missing_ok=True)
        raise
    print('Atualizado na pasta definitiva:',target,flush=True)
    return backup

def main():
    parser=argparse.ArgumentParser(description='Magic Edit Desktop V11.22 — backup integral e atualizacao')
    parser.add_argument('--target',type=Path,default=Path(r'C:\MagicEdit\Desktop_V10'))
    args=parser.parse_args()
    backup=install(Path(__file__).resolve().parent,args.target)
    print('Backup recuperavel:',backup)
    print('Abra INICIAR_MAGIC_EDIT.bat na pasta definitiva. Mantenha o backup ate conferir a edicao.')

if __name__=='__main__':
    try:main()
    except Exception as exc:
        print('ATUALIZACAO INTERROMPIDA:',exc,file=sys.stderr)
        sys.exit(1)
