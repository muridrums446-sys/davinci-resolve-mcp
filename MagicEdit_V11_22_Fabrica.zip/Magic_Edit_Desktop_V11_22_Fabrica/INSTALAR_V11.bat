@echo off
call "%~dp0ATUALIZAR_V11_22.bat"
exit /b %ERRORLEVEL%
