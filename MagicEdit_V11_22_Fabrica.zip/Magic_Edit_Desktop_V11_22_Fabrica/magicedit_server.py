"""Magic Edit Desktop — piloto local. Somente localhost. Dependencias: Python 3 + FFmpeg/FFprobe.
O arquivo do video nao e enviado ao Groq; apenas FLACs temporarios de audio.
"""
from __future__ import annotations
import json
import hashlib
import math
import os
import re
import shutil
import socket
import subprocess
import tempfile
import threading
import time
import traceback
import uuid
import webbrowser
from fractions import Fraction
from audio_wave import peaks_from_pcm
from mp4_export import export_mp4, validate_segments
from resolve_export import export_resolve
from review_takes import MODEL as REVIEW_MODEL, MAX_WORDS as REVIEW_MAX_WORDS, SCHEMA as REVIEW_SCHEMA, cache_key as review_cache_key, run_review
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs

ROOT = Path(__file__).resolve().parent
MEDIA_EXTENSIONS = {'.mp4', '.m4v', '.mov', '.mkv', '.avi', '.webm'}
STATE = {'file': None, 'media': None, 'preview': None, 'job': {'state': 'idle'}, 'waveform': {'state':'idle','peaks':[]}, 'vad': {'state':'idle','speech':[]}}
LOCK = threading.RLock()
WORKDIR = tempfile.TemporaryDirectory(prefix='magicedit_desktop_')
THUMBNAILS = {}
RECENT_PATH = (Path(os.environ['APPDATA']) if os.environ.get('APPDATA') else Path.home() / '.config') / 'MagicEditDesktop' / 'recent.json'
AUTOSAVE_PATH = RECENT_PATH.parent / 'autosave.json'
AUTOSAVE_POSITION_PATH = RECENT_PATH.parent / 'autosave_position.json'
TRANSCRIPT_CACHE_VERSION = 1


class GroqRateLimit(RuntimeError):
    def __init__(self, retry_after: float | None):
        self.retry_after = retry_after
        super().__init__('Groq retornou 429: limite de transcricao atingido.')


def transcript_cache_path(path: str, model: str) -> Path:
    file = Path(path).resolve()
    info = file.stat()
    identity = json.dumps([TRANSCRIPT_CACHE_VERSION, str(file), info.st_size, info.st_mtime_ns, model], ensure_ascii=False)
    return RECENT_PATH.parent / 'transcript_cache' / (hashlib.sha256(identity.encode('utf-8')).hexdigest() + '.json')


def load_transcript_parts(cache: Path, chunks: list[dict]) -> dict[int, list[dict]]:
    try:
        saved = json.loads(cache.read_text(encoding='utf-8'))
        if saved.get('version') != TRANSCRIPT_CACHE_VERSION or not isinstance(saved.get('parts'), dict):
            return {}
        valid = {}
        for index, expected in enumerate(chunks):
            item = saved['parts'].get(str(index), {})
            words = item.get('words')
            if item.get('chunk') == expected and isinstance(words, list) and all(
                isinstance(w, dict) and isinstance(w.get('word'), str)
                and isinstance(w.get('start'), (int, float)) and isinstance(w.get('end'), (int, float))
                for w in words
            ):
                valid[index] = words
        return valid
    except (OSError, ValueError, TypeError, AttributeError):
        return {}


def save_transcript_parts(cache: Path, chunks: list[dict], parts: dict[int, list[dict]]) -> None:
    cache.parent.mkdir(parents=True, exist_ok=True)
    payload = {'version': TRANSCRIPT_CACHE_VERSION, 'parts': {
        str(i): {'chunk': chunks[i], 'words': words} for i, words in parts.items()
    }}
    pending = cache.with_name(cache.name + '.' + uuid.uuid4().hex + '.tmp')
    try:
        pending.write_text(json.dumps(payload, ensure_ascii=False), encoding='utf-8')
        if os.name != 'nt': pending.chmod(0o600)
        pending.replace(cache)
    finally:
        pending.unlink(missing_ok=True)


def read_recent() -> list[dict]:
    try:
        data = json.loads(RECENT_PATH.read_text(encoding='utf-8'))
        return data if isinstance(data,list) else []
    except (OSError, ValueError):
        return []


def write_recent(items: list[dict]) -> None:
    if not isinstance(items,list): raise ValueError('Lista de projetos invalida.')
    clean=[]
    for item in items[:12]:
        if not isinstance(item,dict) or item.get('kind') not in ('video','project') or not isinstance(item.get('path'),str) or not item['path'] or len(item['path'])>2048:
            raise ValueError('Projeto recente invalido.')
        clean.append({'kind':item['kind'],'path':item['path'],'name':str(item.get('name',''))[:140]})
    RECENT_PATH.parent.mkdir(parents=True,exist_ok=True)
    temporary=RECENT_PATH.with_name(RECENT_PATH.name+'.tmp')
    temporary.write_text(json.dumps(clean,ensure_ascii=False),encoding='utf-8')
    temporary.replace(RECENT_PATH)


def _atomic_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    pending = path.with_name(path.name + '.' + uuid.uuid4().hex + '.tmp')
    try:
        pending.write_text(json.dumps(payload, ensure_ascii=False), encoding='utf-8')
        if os.name != 'nt': pending.chmod(0o600)
        pending.replace(path)
    finally:
        pending.unlink(missing_ok=True)


def read_autosave() -> dict | None:
    try:
        doc = json.loads(AUTOSAVE_PATH.read_text(encoding='utf-8'))
        if doc.get('schema') != 1 or not isinstance(doc.get('path'), str) or not isinstance(doc.get('words'), list): return None
        try:
            position = json.loads(AUTOSAVE_POSITION_PATH.read_text(encoding='utf-8'))
            if position.get('path') == doc['path'] and isinstance(position.get('time'), (int, float)) and math.isfinite(position['time']):
                doc['playhead'] = max(0, min(float(position['time']), float(doc['media']['duration'])))
        except (OSError, ValueError, TypeError, KeyError): pass
        return doc
    except (OSError, ValueError, TypeError, AttributeError):
        return None


def write_autosave(doc: dict) -> None:
    if (not isinstance(doc, dict) or doc.get('schema') != 1 or not isinstance(doc.get('path'), str)
            or not isinstance(doc.get('media'), dict) or not isinstance(doc.get('words'), list)
            or len(doc['words']) > 100_000 or not isinstance(doc.get('playhead'), (int, float))
            or not math.isfinite(doc['playhead'])):
        raise ValueError('Projeto de recuperacao invalido.')
    clean = {key: doc[key] for key in ('schema','autoEditVersion','projectName','path','media','words','deletedIndices','extraCuts','splitFrames','model','playhead','editingReport','editorialContext','silenceMinSeconds','silenceSettingsVersion') if key in doc}
    _atomic_json(AUTOSAVE_PATH, clean)
    write_autosave_position(doc['path'], doc['playhead'])


def write_autosave_position(path: str, timecode: float) -> None:
    if not isinstance(path, str) or not path or not isinstance(timecode, (int, float)) or not math.isfinite(timecode) or timecode < 0:
        raise ValueError('Posicao de reproducao invalida.')
    _atomic_json(AUTOSAVE_POSITION_PATH, {'path': path, 'time': timecode})


def recent_video_path(recent_path: str) -> Path | None:
    """Somente entradas do historico podem solicitar miniaturas; JSON aponta para seu video."""
    item = next((x for x in read_recent() if x.get('path') == recent_path), None)
    if not item: return None
    source = Path(recent_path)
    if item['kind'] == 'project':
        if source.suffix.lower() != '.json' or not source.is_file() or source.stat().st_size > 9_000_000:
            return None
        try:
            document = json.loads(source.read_text(encoding='utf-8'))
            source = Path(document['path'])
        except (OSError, ValueError, TypeError, KeyError):
            return None
    if source.suffix.lower() not in MEDIA_EXTENSIONS or not source.is_file(): return None
    return source


def executable(name: str) -> str:
    path = shutil.which(name)
    if path:
        return path
    candidate = ROOT / (name + ('.exe' if os.name == 'nt' else ''))
    if candidate.is_file():
        return str(candidate)
    raise RuntimeError(f'{name} nao encontrado. Instale FFmpeg e adicione ffmpeg/ffprobe ao PATH, ou copie os executaveis para a pasta do Magic Edit.')


def run_process(args: list[str], timeout: int = 220) -> bytes:
    p = subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout, creationflags=(subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0))
    if p.returncode:
        raise RuntimeError((p.stderr.decode('utf-8', errors='replace')[-1000:]).strip() or 'Falha ao executar FFmpeg.')
    return p.stdout


def probe_video(path: str) -> dict:
    if not Path(path).is_file() or Path(path).suffix.lower() not in MEDIA_EXTENSIONS:
        raise ValueError('Selecione um video suportado existente no seu computador.')
    raw = run_process([executable('ffprobe'), '-v', 'error', '-show_entries', 'format=duration:stream=index,codec_type,width,height,avg_frame_rate,r_frame_rate,channels,sample_rate', '-of', 'json', path], timeout=35)
    data = json.loads(raw)
    video = next((s for s in data.get('streams', []) if s.get('codec_type') == 'video'), None)
    audio = next((s for s in data.get('streams', []) if s.get('codec_type') == 'audio'), None)
    if not video or not audio:
        raise ValueError('O arquivo precisa conter uma faixa de video e uma faixa de audio.')
    fps_str = video.get('avg_frame_rate', '0/0')
    if fps_str in ('0/0', '0'):
        fps_str = video.get('r_frame_rate', '0/0')
    try:
        fps = Fraction(fps_str)
        # MOV/MKV podem informar media afetada pela duracao do container.
        # Usar a taxa nominal padrao quando quase identica, comum a XML e MP4.
        nominal = Fraction(video.get('r_frame_rate', '0/1'))
        standards = [Fraction(x) for x in ('24','25','30','48','50','60','100','120','24000/1001','30000/1001','60000/1001')]
        if nominal in standards and abs(float(fps/nominal)-1) < .001:
            fps = nominal
        if not (10 <= float(fps) <= 120):
            raise ValueError()
    except (ValueError, ZeroDivisionError):
        raise ValueError('FPS nao identificado. Precisamos de um arquivo com taxa de quadros definida.')
    duration = float(data.get('format', {}).get('duration') or 0)
    if duration <= 0:
        raise ValueError('A duracao do video nao foi identificada pelo FFprobe.')
    return dict(name=Path(path).name, duration=duration, fpsNum=fps.numerator, fpsDen=fps.denominator, width=video.get('width', 1920), height=video.get('height', 1080), audioChannels=int(audio.get('channels') or 2), audioRate=int(audio.get('sample_rate') or 48000))


def thumbnail_at(path: str, second: float) -> bytes:
    """Extrai um frame do arquivo ativo sem tocar no original; cache limitado em RAM."""
    key = (path, Path(path).stat().st_mtime_ns, round(second, 2))
    with LOCK:
        if key in THUMBNAILS:
            return THUMBNAILS[key]
    data = run_process([executable('ffmpeg'), '-hide_banner', '-loglevel', 'error',
                        '-ss', f'{second:.3f}', '-i', path, '-frames:v', '1',
                        '-vf', 'scale=192:-2', '-q:v', '5', '-f', 'image2', '-vcodec', 'mjpeg', '-'], timeout=35)
    if not data.startswith(b'\xff\xd8'):
        raise RuntimeError('Frame indisponivel neste ponto do video.')
    with LOCK:
        if len(THUMBNAILS) >= 120:
            THUMBNAILS.pop(next(iter(THUMBNAILS)))
        THUMBNAILS[key] = data
    return data


def trim_and_offset_words(parts: list[dict]) -> list[dict]:
    """Junta partes sobrepostas e preserva falas que so um bloco reconheceu."""
    candidates = []
    for part_index,item in enumerate(parts):
        lo, hi, origin = item['lo'], item['hi'], item['origin']
        stop = item.get('stop', hi)
        previous_start = float('-inf')
        for entry in item['words']:
            try:
                a, b = float(entry['start']) + origin, float(entry['end']) + origin
                word = str(entry['word']).strip()
            except (KeyError, ValueError, TypeError):
                continue
            if not (math.isfinite(a) and math.isfinite(b)):
                continue
            estimated = b <= a or a <= previous_start
            # Whisper pode reconhecer o texto mas devolver duracao zero.
            # Preservar o token; o ajuste de tempo e explicitamente sinalizado.
            b = max(b, a + .03)
            mid = (a + b) / 2
            if word and a >= 0 and origin-.1 <= mid < stop+.1:
                # A lista do Whisper segue a fala. Os tempos por palavra podem
                # regredir e nao devem embaralhar a frase ao ordenar os blocos.
                a = max(a, previous_start + .001)
                b = max(b, a + .03)
                previous_start = a
                candidates.append((a,b,word,lo <= mid < hi,part_index,estimated))
    candidates.sort(key=lambda x: (x[0], x[1]))
    combined = []
    for a,b,word,core,part_index,estimated in candidates:
        token = re.sub(r'\W+', '', word.casefold())
        duplicate = next((i for i,old in enumerate(combined)
                          if part_index not in old['part_indices']
                          and token == re.sub(r'\W+', '', old['word'].casefold())
                          and min(b,old['end'])-max(a,old['start']) >= .45*min(b-a,old['end']-old['start'])),None)
        if duplicate is not None:
            if core and not combined[duplicate]['core']:
                combined[duplicate].update(word=word,start=round(a,3),end=round(b,3),core=True)
            combined[duplicate]['part_indices'].add(part_index)
            continue
        record={'word':word,'start':round(a,3),'end':round(b,3),'core':core,'part_indices':{part_index}}
        if estimated: record['timingEstimated']=True
        combined.append(record)
    previous_start = float('-inf')
    for word in combined:
        if word['start'] <= previous_start: word['timingEstimated']=True
        word['start'] = round(max(word['start'], previous_start + .001), 3)
        word['end'] = round(max(word['end'], word['start'] + .03), 3)
        previous_start = word['start']
        word.pop('core')
        word.pop('part_indices')
    return combined


def groq_transcribe(audio_path: Path, key: str, model: str) -> list[dict]:
    """Transcreve usando a biblioteca oficial Groq (em vez do urllib generico).

    SDK oficial fornece cliente HTTP identificado e requisicao multipart padronizada.
    O servidor nao persiste a chave; o arquivo de video nunca e transmitido.
    """
    if model not in {'whisper-large-v3', 'whisper-large-v3-turbo'}:
        raise ValueError('Modelo Groq invalido.')
    if audio_path.stat().st_size >= 24_000_000:
        raise ValueError('Audio acima do limite seguro por envio (24 MB).')
    try:
        from groq import (Groq, AuthenticationError, PermissionDeniedError,
                          RateLimitError, APIConnectionError, APIStatusError)
    except ImportError as exc:
        raise RuntimeError('Biblioteca Groq ausente. Feche o app e execute PREPARAR_GROQ.bat.') from exc

    client = Groq(api_key=key, timeout=180.0, max_retries=0)
    try:
        with open(audio_path, 'rb') as audio_file:
            resp = client.audio.transcriptions.create(
                file=(audio_path.name, audio_file, 'audio/flac'),
                model=model,
                language='pt',
                response_format='verbose_json',
                timestamp_granularities=['word'],
                temperature=0
            )
    except AuthenticationError as exc:
        raise RuntimeError('Groq retornou 401: a chave de API nao foi aceita. Confira no painel Groq.') from exc
    except RateLimitError as exc:
        headers = getattr(getattr(exc, 'response', None), 'headers', {}) or {}
        try:
            retry_after = float(headers.get('retry-after', ''))
            if not math.isfinite(retry_after) or retry_after < 0: retry_after = None
        except (ValueError, TypeError):
            retry_after = None
        raise GroqRateLimit(retry_after) from exc
    except PermissionDeniedError as exc:
        # Cloudflare pode bloquear um cliente HTTP pelo perfil da requisicao.
        # Nao tente contornar politicas do provedor; notifique caso persista no SDK oficial.
        body = getattr(getattr(exc, 'response', None), 'text', '') or ''
        if '1010' in body or 'cloudflare' in body.lower():
            raise RuntimeError('Groq/Cloudflare 403 (erro 1010): acesso bloqueado pelo provedor mesmo com cliente oficial. Verifique rede/VPN e contate suporte Groq se continuar; nao e erro na transcricao.') from exc
        raise RuntimeError('Groq retornou 403: acesso negado. Confira permissoes da conta e painel da Groq.') from exc
    except APIConnectionError as exc:
        raise RuntimeError('Nao foi possivel conectar ao Groq. Verifique internet, proxy e antivirus.') from exc
    except APIStatusError as exc:
        raise RuntimeError(f'Groq retornou HTTP {exc.status_code}. Consulte o painel Groq; se persistir, entre em contato com o suporte.') from exc

    if hasattr(resp, 'model_dump'):
        data = resp.model_dump()
    elif isinstance(resp, dict):
        data = resp
    else:
        data = {'words': getattr(resp, 'words', None)}
    words = data.get('words')
    if not isinstance(words, list):
        raise RuntimeError('Groq nao devolveu tempos por palavra. Nao foi criado nenhum corte.')
    normalized = []
    for word in words:
        if hasattr(word, 'model_dump'):
            word = word.model_dump()
        elif not isinstance(word, dict):
            word = {'word':getattr(word,'word', ''), 'start':getattr(word,'start', None), 'end':getattr(word,'end', None)}
        if all(k in word for k in ('word','start','end')):
            normalized.append({'word':word['word'], 'start':word['start'], 'end':word['end']})
    return normalized


def set_job(**kwargs):
    with LOCK:
        STATE['job'].update(kwargs)


def transcription_chunks(duration: float) -> list[dict]:
    """Blocos proximos dos 30 s recomendados pelo modelo, sem cauda minuscula."""
    chunks=[]
    lo=0.0
    while lo < duration:
        hi=duration if duration-lo<=40 else lo+30
        chunks.append({'lo':lo,'hi':hi,'origin':max(0.0,lo-(2.0 if lo else 0.0)),
                       'stop':min(duration,hi+(2.0 if hi<duration else 0.0))})
        lo=hi
    return chunks


def transcription_wait_seconds(last_attempt: float | None, now: float) -> float:
    # Limite publico da faixa gratuita: 20 requisicoes/minuto.
    return 0.0 if last_attempt is None else max(0.0,3.2-(now-last_attempt))


def background_transcribe(path: str, media: dict, key: str, model: str):
    try:
        duration = media['duration']
        chunks=transcription_chunks(duration)
        total=len(chunks)
        pieces = []
        cache = transcript_cache_path(path, model)
        completed = load_transcript_parts(cache, chunks)
        last_attempt=None
        for i,part in enumerate(chunks):
            lo,hi,origin,stop=(part[k] for k in ('lo','hi','origin','stop'))
            if i in completed:
                pieces.append(dict(lo=lo, hi=hi+(.001 if i==total-1 else 0), origin=origin, stop=stop, words=completed[i]))
                set_job(message=f'Parte {i+1}/{total} reaproveitada do cache local.', done=i+1, total=total)
                continue
            set_job(message=f'Extraindo audio da parte {i+1}/{total}...', done=i, total=total)
            audio_chunk = Path(WORKDIR.name) / f'audio_{i}_{uuid.uuid4().hex}.flac'
            try:
                run_process([executable('ffmpeg'), '-hide_banner', '-loglevel', 'error', '-y', '-ss', str(origin), '-i', path, '-t', str(stop-origin), '-vn', '-map', '0:a:0', '-ac', '1', '-ar', '16000', '-c:a', 'flac', str(audio_chunk)], timeout=240)
                delay=transcription_wait_seconds(last_attempt,time.monotonic())
                if delay:
                    set_job(message=f'Aguardando limite gratuito da Groq; parte {i+1}/{total}...', done=i, total=total)
                    time.sleep(delay)
                for attempt in range(3):
                    set_job(message=f'Transcrevendo na nuvem parte {i+1}/{total}...', done=i, total=total)
                    last_attempt=time.monotonic()
                    try:
                        words = groq_transcribe(audio_chunk, key, model)
                        break
                    except GroqRateLimit as exc:
                        if exc.retry_after is None or exc.retry_after > 90 or attempt == 2:
                            wait = f' Aguarde cerca de {math.ceil(exc.retry_after/60)} minuto(s).' if exc.retry_after is not None else ' Confira quando o limite sera liberado no painel Groq.'
                            raise RuntimeError(f'Groq 429: limite gratuito atingido.{wait} {len(completed)}/{total} partes salvas no computador. Tente novamente depois; o programa continuara das partes restantes.') from exc
                        seconds = math.ceil(exc.retry_after) + 1
                        for remaining in range(seconds, 0, -1):
                            set_job(message=f'Groq pediu espera: {remaining}s. Parte {i+1}/{total}; concluido {len(completed)}/{total}.', done=i, total=total)
                            time.sleep(1)
                completed[i] = words
                save_transcript_parts(cache, chunks, completed)
                pieces.append(dict(lo=lo, hi=hi+(.001 if i==total-1 else 0), origin=origin, stop=stop, words=words))
            finally:
                audio_chunk.unlink(missing_ok=True)
            set_job(message=f'Parte {i+1}/{total} concluida.', done=i+1, total=total)
        normalized = trim_and_offset_words(pieces)
        if not normalized:
            raise RuntimeError('Nenhuma palavra detectada. Confira se existe fala na gravacao.')
        set_job(state='done', message='Transcricao concluida.', result={'words': normalized, 'chunks': total, 'model': model}, done=total, total=total)
    except Exception as e:
        set_job(state='error', message=str(e)[:1200], result=None)


def background_review_takes(words: list[dict], key: str, context: str = ''):
    """Analise de texto solicitada pelo fluxo automatico ou pelo botao de revisao."""
    try:
        from groq import Groq, RateLimitError, AuthenticationError, APIStatusError
        client = Groq(api_key=key, timeout=100.0, max_retries=0)
        cache = RECENT_PATH.parent / 'review_cache' / (review_cache_key(words, context) + '.json')

        def request(instructions, transcript):
            for attempt in range(3):
                try:
                    reply = client.chat.completions.create(
                        model=REVIEW_MODEL,
                        messages=[{'role': 'system', 'content': instructions},
                                  {'role': 'user', 'content': transcript}],
                        temperature=0,
                        response_format={'type': 'json_schema', 'json_schema': {
                            'name': 'review_recording', 'strict': True, 'schema': REVIEW_SCHEMA}},
                    )
                    return json.loads(reply.choices[0].message.content)
                except RateLimitError as exc:
                    headers = getattr(getattr(exc, 'response', None), 'headers', {}) or {}
                    try: wait = float(headers.get('retry-after', 15))
                    except (ValueError, TypeError): wait = 15
                    if attempt == 2 or not math.isfinite(wait) or wait > 90:
                        raise RuntimeError('Limite gratuito da Groq atingido; partes concluidas foram guardadas. Tente novamente depois.') from exc
                    wait = max(2, math.ceil(wait) + 1)
                    set_job(message=f'Aguardando cota Groq por {wait}s; analise parcial guardada.')
                    time.sleep(wait)
                except AuthenticationError as exc:
                    raise RuntimeError('Chave Groq invalida para revisao textual.') from exc
                except APIStatusError as exc:
                    raise RuntimeError(f'Groq nao concluiu a revisao textual (HTTP {exc.status_code}).') from exc

        suggestions = run_review(words, request, cache,
                                 on_progress=lambda done, total: set_job(
                                     message=f'Revisando tomadas {done}/{total}...', done=done, total=total), context=context)
        set_job(state='done', message='Revisao textual concluida.',
                result={'suggestions': suggestions, 'model': REVIEW_MODEL},
                done=1, total=1)
    except Exception as exc:
        # Nunca incluir a chave, o texto enviado ou a mensagem bruta do SDK no status.
        message = str(exc) if isinstance(exc, (ValueError, RuntimeError)) else 'Revisao textual indisponivel. Tente novamente.'
        set_job(state='error', message=message[:240], result=None)


def background_preview(path: str):
    try:
        output = Path(WORKDIR.name) / ('preview_' + uuid.uuid4().hex + '.mp4')
        set_job(message='Criando previa leve 480p: isso usa temporariamente o processador...', done=0, total=1)
        run_process([executable('ffmpeg'), '-hide_banner', '-loglevel', 'error', '-y', '-i', path, '-map', '0:v:0', '-map', '0:a:0', '-vf', 'scale=-2:480', '-c:v', 'libx264', '-preset', 'ultrafast', '-crf', '31', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-b:a', '64k', '-movflags', '+faststart', str(output)], timeout=7200)
        with LOCK:
            STATE['preview'] = str(output)
        set_job(state='done', message='Previa pronta.', result={'preview': '/api/video?preview=1'}, done=1, total=1)
    except Exception as e:
        set_job(state='error', message=str(e)[:1200], result=None)


def background_export_mp4(path: str, media: dict, segments: list[dict], target: str, analysis_clip: bool = False):
    try:
        def progress(done, total):
            set_job(message='Exportando selecao em MP4 leve...' if analysis_clip else 'Renderizando um unico MP4...', done=done, total=total)
        result=export_mp4(path,media,segments,target,executable('ffmpeg'),progress,executable('ffprobe'),analysis_clip=analysis_clip)
        set_job(state='done',message='Trecho leve salvo e verificado.' if analysis_clip else 'MP4 final salvo e verificado.',result=result,done=100,total=100)
    except Exception as exc:
        set_job(state='error',message=str(exc)[:1200],result=None)


def background_export_resolve(path: str, media: dict, segments: list[dict], target: str, name: str, compatible: bool):
    try:
        def progress(done,total):
            set_job(message='Criando midia completa e FCPXML...' if compatible else 'Salvando FCPXML...',done=done,total=total)
        result=export_resolve(path,media,segments,target,name,compatible,executable('ffmpeg'),progress,executable('ffprobe'))
        set_job(state='done',message='FCPXML salvo. Importe como timeline no DaVinci.',result=result,done=100,total=100)
    except Exception as exc:
        set_job(state='error',message=str(exc)[:1200],result=None)


def generate_waveform(path: str):
    """Decodificar so o audio em 2000 Hz, maximo 20 picos por segundo.
    Evitar gerar um WAV temporario enorme, sem criar cache na pasta Downloads.
    """
    try:
        raw=run_process([executable('ffmpeg'),'-hide_banner','-loglevel','error',
             '-i',path,'-vn','-map','0:a:0','-ac','1','-ar','2000',
             '-f','s16le','-acodec','pcm_s16le','-'],timeout=1200)
        peaks=peaks_from_pcm(raw,rate=2000,bins_per_second=20)
        with LOCK:
            if STATE['file']==path: STATE['waveform']={'state':'done','peaks':peaks,'rate':20}
    except Exception as exc:
        with LOCK:
            if STATE['file']==path: STATE['waveform']={'state':'error','message':str(exc)[:240],'peaks':[]}


def start_waveform(path: str):
    with LOCK: STATE['waveform']={'state':'running','peaks':[]}
    threading.Thread(target=generate_waveform,args=(path,),daemon=True).start()


def generate_vad(path: str, duration: float):
    try:
        from vad_local import analyze
        result = analyze(path, executable('ffmpeg'), duration)
    except Exception as exc:
        result = {'state': 'error', 'speech': [], 'message': str(exc)[:240]}
    with LOCK:
        if STATE['file'] == path:
            STATE['vad'] = result


def start_vad(path: str, duration: float):
    with LOCK: STATE['vad'] = {'state': 'running', 'speech': []}
    threading.Thread(target=generate_vad, args=(path, duration), daemon=True).start()


def native_file_dialog(kind: str, default='') -> str | None:
    import tkinter as tk
    from tkinter import filedialog
    root = tk.Tk()
    root.withdraw()
    root.attributes('-topmost', True)
    try:
        if kind == 'video':
            return filedialog.askopenfilename(parent=root, title='Selecione o video original', filetypes=[('Videos', '*.mp4 *.mov *.mkv *.m4v *.avi *.webm'), ('Todos os arquivos', '*.*')]) or None
        if kind == 'project':
            return filedialog.askopenfilename(parent=root, title='Abrir projeto Magic Edit', filetypes=[('Projeto Magic Edit', '*.json')]) or None
        if kind == 'xml':
            return filedialog.asksaveasfilename(parent=root, title='Salvar FCP XML para DaVinci', defaultextension='.xml', initialfile=default or 'MagicEdit.xml', filetypes=[('Final Cut Pro 7 XML', '*.xml')]) or None
        if kind == 'fcpxml':
            return filedialog.asksaveasfilename(parent=root, title='Exportar timeline editavel para DaVinci Resolve', defaultextension='.fcpxml', initialfile=default or 'MagicEdit.fcpxml', filetypes=[('Final Cut Pro XML 1.9', '*.fcpxml')]) or None
        if kind == 'json':
            return filedialog.asksaveasfilename(parent=root, title='Salvar projeto', defaultextension='.json', initialfile=default or 'MagicEdit.json', filetypes=[('Projeto Magic Edit', '*.json')]) or None
        if kind == 'mp4':
            return filedialog.asksaveasfilename(parent=root, title='Exportar video editado', defaultextension='.mp4', initialfile=default or 'MagicEdit_editado.mp4', filetypes=[('Video MP4', '*.mp4')]) or None
        raise ValueError('Dialogo desconhecido')
    finally:
        root.destroy()


class Handler(BaseHTTPRequestHandler):
    server_version = 'MagicEditLocal/0.5'
    def log_message(self, fmt, *args):
        # nao registrar key da API ou dados de trabalho
        if not self.path.startswith('/api/'):
            return
    def _send(self, status, body, mime='application/json; charset=utf-8', headers=None):
        try:
            self.send_response(status)
            self.send_header('Content-Type', mime)
            self.send_header('Content-Length', str(len(body)))
            self.send_header('Cache-Control', 'no-store')
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.send_header('X-Frame-Options', 'DENY')
            if headers:
                for k,v in headers.items(): self.send_header(k,v)
            self.end_headers()
            if self.command != 'HEAD':
                self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
            # Windows WinError 10053/10054: navegador fechou/cancelou a requisicao.
            # Nao tente devolver JSON de erro por uma conexao ja encerrada.
            self.close_connection = True
    def _json(self, status, obj):
        self._send(status, json.dumps(obj, ensure_ascii=False).encode('utf-8'))
    def _media(self, path: Path):
        size = path.stat().st_size
        start, end = 0, size - 1
        range_header = self.headers.get('Range','')
        if range_header:
            m = re.fullmatch(r'bytes=(\d*)-(\d*)', range_header)
            if not m:
                self.send_error(416)
                return
            if m.group(1):
                start = int(m.group(1)); end = min(size-1, int(m.group(2))) if m.group(2) else size-1
            elif m.group(2):
                start = max(0, size-int(m.group(2)))
            if start >= size or end < start:
                self.send_error(416)
                return
        code = 206 if range_header else 200
        self.send_response(code)
        self.send_header('Content-Type','video/mp4' if path.suffix.lower()=='.mp4' else 'video/x-matroska' if path.suffix.lower()=='.mkv' else 'video/quicktime' if path.suffix.lower()=='.mov' else 'application/octet-stream')
        self.send_header('Content-Length', str(end-start+1))
        self.send_header('Accept-Ranges', 'bytes')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        if code==206: self.send_header('Content-Range',f'bytes {start}-{end}/{size}')
        self.end_headers()
        if self.command=='HEAD': return
        try:
            with open(path,'rb') as f:
                f.seek(start)
                remaining=end-start+1
                while remaining:
                    data=f.read(min(1024*512, remaining))
                    if not data: break
                    self.wfile.write(data)
                    remaining-=len(data)
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
            self.close_connection = True
    def do_HEAD(self): self.do_GET()
    def do_GET(self):
        url=urlparse(self.path)
        try:
            if url.path == '/api/vad':
                with LOCK: result=dict(STATE['vad'])
                self._json(200,result)
            elif url.path == '/api/waveform':
                with LOCK: result=dict(STATE['waveform'])
                self._json(200,result)
            elif url.path == '/api/recent':
                self._json(200,{'items':read_recent()})
            elif url.path == '/api/autosave':
                self._json(200,{'project':read_autosave()})
            elif url.path == '/api/recent_thumbnail':
                requested=parse_qs(url.query).get('path',[''])[0]
                source=recent_video_path(requested)
                if source is None: self._json(404,{'error':'Miniatura indisponivel.'});return
                self._send(200,thumbnail_at(str(source),0.4),'image/jpeg')
            elif url.path == '/api/status':
                with LOCK: job = dict(STATE['job'])
                self._json(200,job)
            elif url.path=='/api/video':
                with LOCK:
                    path=STATE['preview'] if parse_qs(url.query).get('preview')==['1'] else STATE['file']
                if not path or not Path(path).is_file(): self._json(404,{'error':'Video nao encontrado.'});return
                self._media(Path(path))
            elif url.path=='/api/thumbnail':
                with LOCK:
                    path, media = STATE['file'], STATE['media']
                if not path or not media: self._json(404,{'error':'Video nao selecionado.'});return
                try:
                    t=float(parse_qs(url.query).get('t',[''])[0])
                    if not (0 <= t < media['duration']): raise ValueError()
                except (ValueError, OverflowError):
                    self._json(400,{'error':'Tempo de miniatura invalido.'});return
                self._send(200,thumbnail_at(path,t),'image/jpeg')
            elif url.path in ('/','/index.html','/src/main.js','/src/engine.js','/src/selection.js','/src/autoedit.js','/src/editor_v09.js','/src/preview_v11.js','/src/word_hit.js','/src/style.css'):
                path=ROOT / ('index.html' if url.path=='/' else url.path.lstrip('/'))
                mime = 'text/javascript; charset=utf-8' if path.suffix=='.js' else 'text/css; charset=utf-8' if path.suffix=='.css' else 'text/html; charset=utf-8'
                self._send(200,path.read_bytes(),mime)
            else: self._json(404,{'error':'Rota nao encontrada.'})
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
            self.close_connection = True
        except Exception as e: self._json(500, {'error':str(e)})
    def do_POST(self):
        url=urlparse(self.path)
        if self.headers.get('Content-Length') is None:
            self._json(411,{'error':'Comprimento necessario.'});return
        try:
            origin=self.headers.get('Origin','')
            if origin and origin != f'http://{self.headers.get("Host","")}' :
                self._json(403,{'error':'Origem externa nao autorizada.'}); return
            if not self.headers.get('Content-Type','').startswith('application/json'):
                self._json(415,{'error':'Formato de requisicao nao suportado.'}); return
            length=int(self.headers['Content-Length'])
            if length<0 or length>9_000_000: raise ValueError('Requisicao muito grande.')
            data=json.loads(self.rfile.read(length)) if length else {}
            if url.path=='/api/choose':
                if STATE['job']['state']=='running': raise RuntimeError('Finalize o processamento antes de selecionar outro arquivo.')
                path=native_file_dialog(data.get('kind','video'))
                if not path: self._json(200,{'cancelled':True}); return
                if data.get('kind')=='video':
                    media=probe_video(path)
                    with LOCK:
                        STATE['file']=path; STATE['media']=media; STATE['preview']=None
                    start_waveform(path)
                    start_vad(path,media['duration'])
                    self._json(200,{'path':path,'media':media})
                else:
                    self._json(200,{'path':path,'text':Path(path).read_text(encoding='utf-8')})
            elif url.path=='/api/set_video':
                if STATE['job']['state']=='running': raise RuntimeError('Finalize o processamento antes de trocar o video.')
                path=data.get('path','')
                media=probe_video(path)
                with LOCK:
                    STATE['file']=path; STATE['media']=media;STATE['preview']=None
                start_waveform(path)
                start_vad(path,media['duration'])
                self._json(200,{'path':path,'media':media})
            elif url.path=='/api/open_project':
                path=Path(data.get('path',''))
                if path.suffix.lower()!='.json' or not path.is_file() or path.stat().st_size>9_000_000:
                    raise ValueError('Projeto JSON nao encontrado ou invalido.')
                self._json(200,{'path':str(path),'text':path.read_text(encoding='utf-8')})
            elif url.path=='/api/recent':
                write_recent(data.get('items'))
                self._json(200,{'saved':True})
            elif url.path=='/api/autosave':
                write_autosave(data)
                self._json(200,{'saved':True})
            elif url.path=='/api/autosave_position':
                write_autosave_position(data.get('path'),data.get('time'))
                self._json(200,{'saved':True})
            elif url.path=='/api/transcribe':
                key=str(data.get('apiKey','')).strip()
                model=str(data.get('model','whisper-large-v3'))
                if not key.startswith('gsk_'): raise ValueError('Chave Groq invalida ou ausente.')
                with LOCK:
                    if STATE['job']['state']=='running': raise RuntimeError('Ha um processamento em andamento.')
                    if not STATE['file'] or not STATE['media']: raise ValueError('Selecione um video primeiro.')
                    path,media=STATE['file'],dict(STATE['media'])
                    STATE['job']={'state':'running','message':'Preparando audio...','done':0,'total':1}
                threading.Thread(target=background_transcribe,args=(path,media,key,model),daemon=True).start()
                self._json(202,{'started':True})
            elif url.path=='/api/review_takes':
                key=str(data.get('apiKey','')).strip()
                words=data.get('words')
                if not key.startswith('gsk_'): raise ValueError('Informe a chave Groq para a revisao opcional.')
                if not isinstance(words,list) or not words or len(words)>REVIEW_MAX_WORDS or any(
                        not isinstance(w,dict) or not isinstance(w.get('word'),str) or len(w['word'])>100
                        or not isinstance(w.get('start'),(int,float)) or not isinstance(w.get('end'),(int,float))
                        or not math.isfinite(w['start']) or not math.isfinite(w['end']) or w['end']<w['start']
                        for w in words):
                    raise ValueError('Transcricao invalida ou grande demais para revisao por IA.')
                context=data.get('context','')
                if not isinstance(context,str) or len(context)>3000: raise ValueError('Assunto/roteiro invalido.')
                with LOCK:
                    if STATE['job']['state']=='running': raise RuntimeError('Finalize o processamento atual antes da revisao.')
                    if not STATE['file']: raise ValueError('Selecione o video do projeto antes da revisao.')
                    STATE['job']={'state':'running','message':'Preparando revisao textual...', 'done':0,'total':1}
                threading.Thread(target=background_review_takes,args=(words,key,context),daemon=True).start()
                self._json(202,{'started':True})
            elif url.path=='/api/preview':
                with LOCK:
                    if STATE['job']['state']=='running': raise RuntimeError('Ha outro processamento em andamento.')
                    if not STATE['file']: raise ValueError('Selecione um video.')
                    path=STATE['file'];STATE['job']={'state':'running','message':'Preparando previa','done':0,'total':1}
                threading.Thread(target=background_preview,args=(path,),daemon=True).start()
                self._json(202,{'started':True})
            elif url.path=='/api/export_resolve':
                with LOCK:
                    if STATE['job']['state']=='running': raise RuntimeError('Ha outro processamento em andamento.')
                    if not STATE['file'] or not STATE['media']: raise ValueError('Selecione um video primeiro.')
                    path,media=STATE['file'],dict(STATE['media'])
                segments=data.get('segments')
                validate_segments(segments,media)
                compatible=data.get('compatible',False)
                if type(compatible) is not bool:raise ValueError('Opcao de midia invalida.')
                name=data.get('name','Magic Edit')
                if not isinstance(name,str) or len(name)>200:raise ValueError('Nome de timeline invalido.')
                target=native_file_dialog('fcpxml',str(data.get('default',''))[:120])
                if not target:self._json(200,{'cancelled':True});return
                with LOCK:
                    if STATE['file']!=path or STATE['job']['state']=='running':
                        raise RuntimeError('O video mudou durante a escolha do destino. Tente novamente.')
                    STATE['job']={'state':'running','message':'Preparando exportacao DaVinci...','done':0,'total':100}
                threading.Thread(target=background_export_resolve,args=(path,media,segments,target,name,compatible),daemon=True).start()
                self._json(202,{'started':True})
            elif url.path=='/api/export_mp4':
                with LOCK:
                    if STATE['job']['state']=='running': raise RuntimeError('Ha outro processamento em andamento.')
                    if not STATE['file'] or not STATE['media']: raise ValueError('Selecione um video primeiro.')
                    path,media=STATE['file'],dict(STATE['media'])
                segments=data.get('segments')
                validate_segments(segments,media)
                analysis_clip=data.get('analysisClip',False)
                if type(analysis_clip) is not bool:raise ValueError('Perfil de exportacao invalido.')
                target=native_file_dialog('mp4',str(data.get('default',''))[:120])
                if not target: self._json(200,{'cancelled':True});return
                with LOCK:
                    if STATE['file']!=path or STATE['job']['state']=='running':
                        raise RuntimeError('O video mudou durante a escolha do destino. Tente novamente.')
                    STATE['job']={'state':'running','message':'Preparando MP4...','done':0,'total':100}
                threading.Thread(target=background_export_mp4,args=(path,media,segments,target,analysis_clip),daemon=True).start()
                self._json(202,{'started':True})
            elif url.path=='/api/save':
                ext=data.get('kind')
                if ext not in ('xml','json'): raise ValueError('Formato de salvamento invalido.')
                target=native_file_dialog(ext,data.get('default',''))
                if not target: self._json(200,{'cancelled':True});return
                contents=data.get('contents','')
                if not isinstance(contents,str): raise ValueError('Conteudo invalido.')
                Path(target).write_text(contents,encoding='utf-8')
                self._json(200,{'saved':True,'path':target})
            else:
                self._json(404,{'error':'Rota nao encontrada.'})
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
            self.close_connection = True
        except Exception as e:
            self._json(400,{'error':str(e)})


def main():
    print('\nMAGIC EDIT DESKTOP V11.22')
    print('O aplicativo nao envia o video inteiro para a nuvem.\n')
    if not shutil.which('ffmpeg') or not shutil.which('ffprobe'):
        print('ATENCAO: FFmpeg e FFprobe precisam estar no PATH ou nesta pasta para importar/transcrever.\n')
    server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
    host,port=server.server_address
    url=f'http://127.0.0.1:{port}/'
    print('Abrindo',url,'\nDeixe esta janela aberta durante a edicao. Ctrl+C para encerrar.\n')
    threading.Timer(1, lambda:webbrowser.open(url)).start()
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally: server.server_close();WORKDIR.cleanup()

if __name__=='__main__': main()
