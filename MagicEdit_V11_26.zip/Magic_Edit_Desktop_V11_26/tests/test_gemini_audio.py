"""Catch unmeasured cuts, key leakage, bad cache identity and provider failures."""
import copy, io, json, subprocess, tempfile, unittest
from pathlib import Path
from unittest.mock import patch
from urllib.error import HTTPError, URLError
import gemini_audio as ga

KEY='AIza_dummy_key_for_tests_only_123456789'
MODEL='gemini-test-flash'

def words(text):
    return [dict(word=t,start=round(1+i*.5,3),end=round(1.3+i*.5,3)) for i,t in enumerate(text.split())]

def candidate(**changes):
    item=dict(start=1,end=2.3,kind='duplicate',spokenText='vamos começar agora',reason='Primeira tentativa refeita logo depois',clear=True,
              keepStart=2.5,keepEnd=3.8,keepText='vamos começar agora')
    return {**item,**changes}

class GeminiAudioTest(unittest.TestCase):
    def setUp(self):self.words=words('vamos começar agora vamos começar agora continuamos falando de investimentos')
    def validate(self,item,ws=None,selection=None):
        return ga.validate_audio_suggestions({'suggestions':[item]},ws or self.words,(0,10,0,10),selection)
    def test_automatic_cut_has_matching_measured_edges_and_preserves_later_take(self):
        before=copy.deepcopy(self.words)
        s=self.validate(candidate())[0]
        self.assertFalse(s['requiresReview']);self.assertEqual((s['start'],s['end']),(1,2.3))
        self.assertEqual(s['origin'],'gemini-audio');self.assertEqual(self.words,before)
    def test_snapping_must_not_clip_overlapping_neighbor_words(self):
        ws=[{'word':'anterior','start':.8,'end':1.1}]+copy.deepcopy(self.words)
        ws[1]['end']=1.4
        self.assertTrue(self.validate(candidate(start=1.11),ws)[0]['requiresReview'])
        ws=copy.deepcopy(self.words)
        ws.insert(3,{'word':'vizinha','start':2.2,'end':2.45})
        self.assertTrue(self.validate(candidate(end=2.19),ws)[0]['requiresReview'])
    def test_uncertain_inside_word_or_wrong_quote_remain_review_only(self):
        for item in [candidate(start=1.23),candidate(spokenText='outras palavras aqui'),candidate(clear=False),candidate(clear=1)]:
            with self.subTest(item=item):self.assertTrue(self.validate(item)[0]['requiresReview'])
    def test_audio_missing_from_transcript_is_visible_but_not_cut_automatically(self):
        s=self.validate(candidate(start=.1,end=.7,kind='offtopic',spokenText='fecha a janela agora'))[0]
        self.assertTrue(s['requiresReview']);self.assertEqual(s['start'],.1)
    def test_short_distant_overlapping_and_complete_different_take_not_automatic(self):
        for item in [candidate(keepStart=1.5),candidate(keepEnd=None),candidate(keepText='vamos parar agora'),candidate(kind='noise'),candidate(kind='invalid')]:
            result=self.validate(item)
            self.assertTrue(not result or result[0]['requiresReview'])
    def test_nonfinite_outside_selection_or_window_rejected(self):
        for item in [candidate(start=float('nan')),candidate(end=20),candidate(start=True),candidate(start=-1),candidate(end=.2)]:
            self.assertEqual(self.validate(item),[])
        self.assertEqual(self.validate(candidate(),selection={'start':1.5,'end':4}),[])
    def test_kept_take_vetoes_another_cut(self):
        items=[candidate(),candidate(start=2.5,end=3.8,kind='offtopic',spokenText='vamos começar agora')]
        result=ga.validate_audio_suggestions({'suggestions':items},self.words,(0,10,0,10),None)
        self.assertFalse(result[0]['requiresReview']);self.assertTrue(result[1]['requiresReview'])
    def test_word_polarity_changes_never_removed_as_duplicate(self):
        ws=words('não vamos investir agora vamos investir agora continuamos')
        item=candidate(end=2.8,spokenText='não vamos investir agora',keepStart=3,keepEnd=4.3,keepText='vamos investir agora')
        self.assertTrue(self.validate(item,ws)[0]['requiresReview'])
    def test_common_prefix_of_two_complete_different_sentences_is_not_automatic(self):
        ws=words('vamos falar sobre ações agora vamos falar sobre fundos agora')
        item=candidate(spokenText='vamos falar sobre',keepStart=3.5,keepEnd=4.8,keepText='vamos falar sobre')
        self.assertTrue(self.validate(item,ws)[0]['requiresReview'])
    def test_partial_quota_error_caches_completed_parts_and_retries_remaining_only(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);source=root/'audio.wav'
            subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i','anullsrc=r=16000:cl=mono','-t','65','-y',str(source)],check=True)
            kwargs=dict(path=str(source),media={'duration':65},words=[],key=KEY,model=MODEL,context='',selection=None,
                        cache_dir=root/'cache',work_dir=root,ffmpeg='ffmpeg',on_progress=lambda *_:None)
            response={'candidates':[{'finishReason':'STOP','content':{'parts':[{'text':'{"suggestions":[]}'}]}}]}
            with patch.object(ga,'google_json',side_effect=[response,RuntimeError('cota')]),patch.object(ga.time,'sleep'):
                with self.assertRaisesRegex(RuntimeError,'cota'):ga.review_audio(**kwargs)
            self.assertEqual(list(root.glob('gemini-*.flac')),[])
            with patch.object(ga,'google_json',return_value=response) as request,patch.object(ga.time,'sleep'):
                self.assertEqual(ga.review_audio(**kwargs)['windows'],2)
                self.assertEqual(request.call_count,1)
    def test_windows_own_each_region_once_with_context(self):
        self.assertEqual(ga.audio_windows(110,None),[(0,60,0,48),(48,108,48,96),(96,110,96,110)])
        win=ga.audio_windows(110,{'start':50,'end':55})
        self.assertEqual(win,[(44,67,50,55)])
    def test_invalid_input_fails_before_network(self):
        for key,model in [('',MODEL),(KEY,'../../evil'),('bad key',MODEL)]:
            with self.assertRaises(ValueError):ga.validate_credentials(key,model)
    def test_credentials_are_opaque_instead_of_a_guessed_google_key_format(self):
        for key in ['fake.token:with/symbols+and=padding_-', 'X'*240, 'short-but-opaque']:
            with self.subTest(length=len(key)):
                self.assertEqual(ga.validate_credentials(key,MODEL),key)
    def test_clipboard_edge_formatting_is_normalized_but_internal_controls_rejected(self):
        self.assertEqual(ga.validate_credentials(' \ufeff\u200b'+KEY+'\u200b\r\n'),KEY)
        for key in [KEY+'\r\nInjected: value',KEY+' '+KEY,KEY+'\x00',KEY+'\u200b'+KEY,'X'*4097]:
            with self.subTest(length=len(key)):
                with self.assertRaises(ValueError) as caught:ga.validate_credentials(key)
                self.assertNotIn(key,str(caught.exception))
    def test_opaque_normalized_key_reaches_provider_header_not_url_or_result(self):
        key='fake.token:with/symbols+and=padding_-';headers=[]
        class Reply:
            def __enter__(self):return self
            def __exit__(self,*_):pass
            def read(self,_):return b'{"models":[{"name":"models/gemini-test","supportedGenerationMethods":["generateContent"]}]}'
        class Opener:
            def open(self,req,timeout):
                headers.append(req.get_header('X-goog-api-key'));self_url=req.full_url
                if key in self_url:raise AssertionError('key leaked into URL')
                return Reply()
        with patch.object(ga,'build_opener',return_value=Opener()):
            result=ga.list_models('\ufeff\u200b'+key+'\u200b\r\n')
        self.assertEqual(headers,[key]);self.assertEqual(result[0]['id'],'gemini-test')
        self.assertNotIn(key,json.dumps(result))
    def test_http_uses_fixed_host_header_key_and_sanitized_errors(self):
        captured=[]
        class Reply:
            def __enter__(self):return self
            def __exit__(self,*_):pass
            def read(self,n):return b'{"models":[]}'
        class Opener:
            def open(self,req,timeout):captured.append(req);return Reply()
        with patch.object(ga,'build_opener',return_value=Opener()):
            self.assertEqual(ga.google_json(KEY,'models'),{'models':[]})
        self.assertNotIn(KEY,captured[0].full_url)
        self.assertEqual(captured[0].get_header('X-goog-api-key'),KEY)
        for code,expected in [(429,'cota'),(403,'chave'),(404,'modelo')]:
            class Fail:
                def open(self,*args,**kwargs):raise HTTPError('https://x',code,KEY,{},io.BytesIO(KEY.encode()))
            with patch.object(ga,'build_opener',return_value=Fail()):
                with self.assertRaisesRegex(RuntimeError,expected) as error:ga.google_json(KEY,'models')
                self.assertNotIn(KEY,str(error.exception))
    def test_structured_google_failure_is_actionable_without_echoing_body_or_key(self):
        for code,reason,want in [(400,'API_KEY_INVALID','chave'),(403,'SERVICE_DISABLED','Generative Language API'),
                                 (403,'API_KEY_SERVICE_BLOCKED','restricoes')]:
            raw=json.dumps({'error':{'message':KEY,'details':[{'reason':reason,'metadata':{'secret':KEY}}]}}).encode()
            class Fail:
                def open(self,*a,**kw):raise HTTPError('https://x',code,KEY,{},io.BytesIO(raw))
            with patch.object(ga,'build_opener',return_value=Fail()):
                with self.assertRaisesRegex(RuntimeError,want) as caught:ga.google_json(KEY,'models?pageSize=100')
                self.assertNotIn(KEY,str(caught.exception))
    def test_model_discovery_filters_non_generating_and_paginates(self):
        replies=[{'models':[{'name':'models/gemini-a','supportedGenerationMethods':['generateContent'],'displayName':'Audio A'},
                           {'name':'models/embed','supportedGenerationMethods':['embedContent']}],'nextPageToken':'abc'},
                 {'models':[{'name':'models/gemini-b','supportedGenerationMethods':['generateContent']}]}]
        with patch.object(ga,'google_json',side_effect=replies) as request:
            result=ga.list_models(KEY)
        self.assertEqual([m['id'] for m in result],['gemini-a','gemini-b']);self.assertEqual(request.call_count,2)
    def test_real_audio_extraction_cache_resume_and_secret_exclusion(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);source=root/'source.wav'
            subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i','sine=frequency=300:duration=5','-y',str(source)],check=True)
            seen=[]
            def request(key,resource,payload=None):
                seen.append(payload)
                import base64
                raw=base64.b64decode(payload['contents'][0]['parts'][1]['inlineData']['data'])
                self.assertTrue(raw.startswith(b'fLaC'))
                self.assertEqual(payload['contents'][0]['parts'][1]['inlineData']['mimeType'],'audio/flac')
                return {'candidates':[{'finishReason':'STOP','content':{'parts':[{'text':json.dumps({'suggestions':[]})}]}}]}
            kwargs=dict(path=str(source),media={'duration':5},words=[],key=KEY,model=MODEL,context='finanças',selection=None,
                        cache_dir=root/'cache',work_dir=root,ffmpeg='ffmpeg',on_progress=lambda *_:None)
            with patch.object(ga,'google_json',side_effect=request),patch.object(ga.time,'sleep'):
                result=ga.review_audio(**kwargs);self.assertEqual(result['suggestions'],[])
                ga.review_audio(**kwargs);self.assertEqual(len(seen),1)
                ga.review_audio(**{**kwargs,'context':'outro'});self.assertEqual(len(seen),2)
                ga.review_audio(**{**kwargs,'model':'gemini-other'});self.assertEqual(len(seen),3)
            self.assertEqual(list(root.glob('gemini-*.flac')),[])
            for file in (root/'cache').glob('*.json'):self.assertNotIn(KEY,file.read_text())
    def test_truncated_or_blocked_model_output_is_not_success(self):
        for raw in [{'candidates':[]},{'candidates':[{'finishReason':'MAX_TOKENS','content':{'parts':[{'text':'{}'}]}}]}]:
            with self.assertRaises(RuntimeError):ga.decode_response(raw)

if __name__=='__main__':unittest.main()
