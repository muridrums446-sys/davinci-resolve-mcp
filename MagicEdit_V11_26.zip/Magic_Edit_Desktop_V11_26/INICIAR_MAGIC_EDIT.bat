@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Magic Edit Desktop - V11.26
set "PY=py -3"
where py >nul 2>nul
if errorlevel 1 set "PY=python"
%PY% -c "import sys; print(sys.version)" >nul 2>nul
if errorlevel 1 (
  echo ERRO: Python nao encontrado. Consulte LEIA_PRIMEIRO.txt
  pause
  exit /b 1
)
%PY% -c "import groq" >nul 2>nul
if errorlevel 1 (
  echo.
  echo Falta a biblioteca Groq. Execute PREPARAR_GROQ.bat primeiro.
  pause
  exit /b 1
)
echo.
echo MAGIC EDIT DESKTOP - V11.26
echo A IA processa so o audio. Nunca envie sua chave por mensagem.
echo.
%PY% magicedit_server.py
echo.
echo Programa encerrado.
pause
