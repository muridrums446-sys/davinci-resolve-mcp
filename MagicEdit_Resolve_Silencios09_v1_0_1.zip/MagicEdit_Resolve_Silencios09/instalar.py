"""Local reversible patch. Does not modify MCP, Motion, media or project databases."""
import argparse,ast,datetime,hashlib,json,os,re,shutil,subprocess,sys,uuid
from pathlib import Path
ROOT=Path(__file__).resolve().parent
VERSION='1.0.1'
PANEL_SHA='c6c4219cd85020ed4a5c5646e21383a362a696ad2b2426d2513fa14ea8e3ede3'
MOTOR_SHA='bd7d007ed219a24e6bf9ebcf61732566760db8fd35221f4fa44367f74da3c5a9'

def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def safe_path(path):
    path=Path(path).absolute()
    for p in (path,*path.parents):
        if p.is_symlink() or getattr(p,'is_junction',lambda:False)():raise ValueError('Pasta com link/juncao nao aceita: '+str(p))
    return path

def atomic(path,data):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True);tmp=path.with_name(path.name+'.'+uuid.uuid4().hex+'.tmp')
    try:
        with tmp.open('xb') as f:f.write(data)
        tmp.replace(path)
    finally:tmp.unlink(missing_ok=True)
def json_write(path,value):atomic(path,json.dumps(value,ensure_ascii=False,indent=2).encode())
def replace_once(text,old,new):
    if text.count(old)!=1:raise ValueError('O painel tem estrutura diferente. Nenhum ajuste sera aplicado.')
    return text.replace(old,new,1)

ASYNC_HANDLERS = r'''def _magic09_error(stage, error):
    import traceback as _trace09
    import sys as _sys09
    from pathlib import Path as _P09
    report = {'stage': stage, 'error': str(error), 'traceback': _trace09.format_exc(), 'python': _sys09.version}
    try:
        _r = bmd.scriptapp('Resolve')
        _p = _r.GetProjectManager().GetCurrentProject()
        _tl = _p.GetCurrentTimeline() if _p else None
        if _tl:
            report['timeline'] = _tl.GetName()
            report['fps'] = _tl.GetSetting('timelineFrameRate')
            report['tracks'] = {kind: _tl.GetTrackCount(kind) for kind in ['video','audio']}
    except Exception:
        pass
    try:
        path = _P09(os.environ['LOCALAPPDATA']) / 'MagicEdit' / 'Silencios09' / 'ultimo_erro.json'
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    except Exception:
        pass
    try:
        print('MAGIC EDIT - ERRO:', stage, report['traceback'])
    except Exception:
        pass
    itens['Status'].Text = 'ERRO: ' + str(error)[:180] + ' | Detalhes: Console (F6).'

def _magic09_enabled(enabled):
    for name in ['AcaoAnalisar','AcaoAplicar','MenuTranscricaoAuto','GerarMotion','EditarMotionAtual','AtualizarMotion']:
        itens[name].Enabled = enabled

def executar_analise(ev):
    global _MAGIC09_JOB
    if _MAGIC09_JOB is not None:
        return
    try:
        strength = 50
        _MAGIC09_JOB = _magic09_bridge().begin_analysis(bmd, strength)
        _magic09_enabled(False)
        itens['Status'].Text = 'Analisando audio local... voce pode cancelar em Fechar.'
        _MAGIC09_TIMER.Start()
    except Exception as erro:
        _magic09_enabled(True)
        _magic09_error('preparar_analise', erro)

def _magic09_poll(ev=None):
    global _MAGIC09_JOB
    if _MAGIC09_JOB is None:
        return
    if _MAGIC09_JOB['process'].poll() is None:
        import time as _t09
        elapsed = int(_t09.monotonic() - _MAGIC09_JOB['started'])
        itens['Status'].Text = 'Analisando audio local... {} s'.format(elapsed)
        return
    try:
        _magic09_bridge().finish_analysis(_MAGIC09_JOB)
        verdes, amarelos = atualizar()
        itens['Status'].Text = '{} silencios >0,9s. Confira e crie a copia.'.format(verdes)
    except Exception as erro:
        _magic09_error('concluir_analise', erro)
    finally:
        _MAGIC09_JOB = None
        _MAGIC09_TIMER.Stop()
        _magic09_enabled(True)

def executar_aplicacao(ev):
    if _MAGIC09_JOB is not None:
        itens['Status'].Text = 'Aguarde a analise terminar.'
        return
    try:
        itens['Status'].Text = 'Montando copia; original preservada...'
        aplicar()
        atualizar()
        itens['Status'].Text = 'Copia pronta. Salve o projeto no Resolve.'
    except Exception as erro:
        _magic09_error('aplicar', erro)
'''

def patch_panel(raw):
    text=raw.decode('utf-8-sig').replace('\r\n','\n')
    text=replace_once(text,'"WindowTitle": "Magic Edit",','"WindowTitle": "Magic Edit · Silêncios 0,9s · 1.0.1",')
    text=replace_once(text,'"Text": "ANALISAR  •  Silêncios + Emendas",','"Text": "ANALISAR  •  Pausas > 0,9s",')
    text=replace_once(text,'"Text": "APLICAR  •  Executar cortes",','"Text": "CRIAR CÓPIA  •  Aplicar silêncios",')
    text=replace_once(text,'"MaximumSize": [350, 190]','"MaximumSize": [350, 230]')
    anchor='                                            ui.VGap(4),\n\n                                            ui.HGroup('
    row='''                                            ui.Label({"ID": "SilencioInfo", "Text": "Pausas > 0,9s · proteção da fala", "Weight": 0, "MinimumSize": [0, 20], "MaximumSize": [350, 20]}),

'''
    text=replace_once(text,anchor,row+anchor)
    text=replace_once(text,'itens = win.GetItems()','itens = win.GetItems()\n\n_MAGIC09_JOB = None\n_MAGIC09_TIMER = ui.Timer({"ID": "MagicSilencioPoll", "Interval": 500, "SingleShot": False})')
    status='"ID": "Status",\n                                                "Text": "Pronto.",\n                                                "MaximumSize": [10000, 30]'
    text=replace_once(text,status,'"ID": "Status", "Text": "Pronto. Clique em ANALISAR.", "WordWrap": True, "Weight": 0, "MinimumSize": [0, 40], "MaximumSize": [350, 52]')
    a=text.index('    itens["CountYellow"].Text = ('); b=text.index('\n    )',a)+len('\n    )')
    text=text[:a]+'    itens["CountYellow"].Text = "Voz protegida"'+text[b:]
    text=text.replace('"Text": "Backup ✓"','"Text": "Original ✓"')
    text=replace_once(text,'"Backup + aplicação..."','"Montando cópia; original preservada..."')
    text=replace_once(text,'"✓ Cortes aplicados."','"✓ Cópia pronta. Salve o projeto no Resolve."')
    start=text.index('def executar_analise(ev):')
    stop=text.index('def click_atualizar(ev):',start)
    text=text[:start]+ASYNC_HANDLERS+'\n\n'+text[stop:]
    text=replace_once(text,'def fechar(ev):\n    disp.ExitLoop()',"def fechar(ev):\n\n    if _MAGIC09_JOB is not None:\n        _magic09_bridge().cancel_analysis(_MAGIC09_JOB)\n    _MAGIC09_TIMER.Stop()\n    disp.ExitLoop()")
    text=replace_once(text,'win.Show()\ndisp.RunLoop()\nwin.Hide()',"disp.On.Timeout = _magic09_poll\nwin.Show()\ntry:\n    disp.RunLoop()\nfinally:\n    _MAGIC09_TIMER.Stop()\n    if _MAGIC09_JOB is not None:\n        _magic09_bridge().cancel_analysis(_MAGIC09_JOB)\n    win.Hide()")
    text=text.replace('" emendas"','" — original preservada"')
    compile(text,'Magic Edit.py','exec')
    return text.replace('\n','\r\n').encode('utf-8')

DELEGATE='''

# MAGIC_EDIT_SILENCIOS_09_V1 - delegacao local; motor anterior preservado acima.
_MAGIC09_BRIDGE_CACHE = None

def _magic09_bridge():
    global _MAGIC09_BRIDGE_CACHE
    if _MAGIC09_BRIDGE_CACHE is None:
        import importlib.util as _spec09
        from pathlib import Path as _Path09
        _state09 = _Path09(os.environ['LOCALAPPDATA']) / 'MagicEdit' / 'Silencios09'
        _config09 = json.loads((_state09 / 'active.json').read_text('utf-8'))
        _runtime09 = _Path09(_config09['runtime']).resolve()
        if _state09.resolve() not in _runtime09.parents:
            raise RuntimeError('Pasta do analisador invalida. Reinstale o pacote.')
        _spec = _spec09.spec_from_file_location('magicedit_silencio09_bridge', _runtime09 / 'bridge.py')
        _module = _spec09.module_from_spec(_spec)
        _spec.loader.exec_module(_module)
        _MAGIC09_BRIDGE_CACHE = _module
    return _MAGIC09_BRIDGE_CACHE

def analisar():
    _strength09 = 50
    if 'itens' in globals() and 'SilencioForca' in itens:
        _strength09 = (0,25,50,75,100)[int(itens['SilencioForca'].CurrentIndex)]
    return _magic09_bridge().analisar(bmd, _strength09)

def aplicar():
    return _magic09_bridge().aplicar(bmd)
'''
def patch_motor(raw):
    text=raw.decode('utf-8-sig').replace('\r\n','\n')+DELEGATE
    compile(text,'cortes_v1.py','exec');return text.replace('\n','\r\n').encode('utf-8')

def find_motor(panel):
    tree=ast.parse(Path(panel).read_text('utf-8-sig'))
    for node in tree.body:
        if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='MOTOR' for t in node.targets):
            value=ast.literal_eval(node.value)
            if isinstance(value,str) and Path(value).name=='cortes_v1.py':return safe_path(value)
    raise ValueError('Caminho do motor nao encontrado no painel.')
MENU_BACKUPS = ('magic edit - backup_pre_label_20261003_181936.py', 'magic edit - backup_pre_ui_v12_20261003_174249.py', 'magic edit - backup_pre_v12_1_campo_20261003_183538.py', 'magic edit - backup_pre_v12_2_stack_20261003_184558.py', 'magic edit - backup_pre_v12_3_1_20261003_191336.py', 'magic edit - backup_pre_v12_3_2_20261003_191943.py', 'magic edit - backup_pre_v12_3_3_20261003_192333.py', 'magic edit - backup_pre_v12_3_compact_20261003_185347.py', 'magic edit - backup_ultimo.py', 'magic edit - backup_v1.py', 'magic edit - backup_v2.py', 'magicedit_poc_fala_umdestaque.backup_20261006_201051.py', 'magicedit_poc_fala_umdestaque.backup_20261006_201825.py')
def is_backup(name):
    return name.casefold() in MENU_BACKUPS

def check_bundle():
    manifest=json.loads((ROOT/'manifest.json').read_text())
    for rel,sha in manifest.items():
        p=(ROOT/rel).resolve()
        if ROOT not in p.parents or digest(p)!=sha:raise ValueError('Pacote incompleto ou alterado: '+rel)
    return manifest

def prepare_environment(state):
    node=shutil.which('node')
    if not node:
        candidate=Path(os.environ.get('ProgramFiles',r'C:\Program Files'))/'nodejs/node.exe'
        if candidate.is_file():node=str(candidate)
    if not node:raise ValueError('Node.js nao encontrado. O recurso usa o mesmo Node do Motion; nada foi alterado.')
    major=int(subprocess.check_output([node,'--version'],text=True,timeout=30).strip().lstrip('v').split('.')[0])
    if major<18:raise ValueError('Node18+ necessario; nada foi alterado.')
    def exe(name):
        found=shutil.which(name)
        candidate=Path(r'C:\MagicEdit\Desktop_V10')/(name+'.exe')
        if not found and candidate.is_file():found=str(candidate)
        if not found:raise ValueError(name+' nao encontrado; nada foi alterado.')
        subprocess.run([found,'-version'],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=30)
        return found
    ffmpeg,ffprobe=exe('ffmpeg'),exe('ffprobe')
    candidates=[]
    existing=state/'environment'/('Scripts/python.exe' if os.name=='nt' else 'bin/python')
    if existing.is_file():candidates.append([str(existing)])
    if shutil.which('py'):candidates+=[['py','-3.12'],['py','-3.11'],['py','-3']]
    if Path(sys.executable).name.lower().startswith('python'):candidates.append([sys.executable])
    if shutil.which('python'):candidates.append(['python'])
    selected=None
    for command in candidates:
        if subprocess.run(command+['-c','import numpy, onnxruntime'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=60).returncode==0:selected=command;break
    if not selected:
        print('Preparando ambiente local proprio para numpy/onnxruntime; sem alterar o Python do MCP...',flush=True)
        launcher=None
        for command in candidates:
            if subprocess.run(command+['-c','import sys;assert sys.version_info>=(3,10)'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=30).returncode==0:launcher=command;break
        if not launcher:raise ValueError('Python3.10+ nao encontrado.')
        venv=state/'environment'
        subprocess.run(launcher+['-m','venv',str(venv)],check=True,timeout=180)
        python=venv/('Scripts/python.exe' if os.name=='nt' else 'bin/python')
        subprocess.run([str(python),'-m','pip','install','numpy','onnxruntime'],check=True,timeout=900)
        selected=[str(python)]
    probe='import onnxruntime as o; p=o.SessionOptions();p.intra_op_num_threads=1;o.InferenceSession(__import__("sys").argv[1],sess_options=p,providers=["CPUExecutionProvider"])'
    subprocess.run(selected+['-c',probe,str(ROOT/'runtime/silero_vad.onnx')],check=True,timeout=90)
    return {'python':selected,'node':node,'ffmpeg':ffmpeg,'ffprobe':ffprobe}

def closed_resolve():
    if os.name=='nt':
        text=subprocess.check_output(['tasklist','/FI','IMAGENAME eq Resolve.exe','/FO','CSV','/NH'],text=True,errors='replace',timeout=30)
        if re.search(r'^"Resolve\.exe"',text,re.I|re.M):raise ValueError('Feche o DaVinci Resolve antes de instalar ou restaurar.')

def _restore(manifest):
    # Inspect every target before changing any: never overwrite later user edits.
    for record in manifest['records']:
        target=safe_path(record['target']);current=digest(target) if target.is_file() else None
        if current not in (record['beforeSha'],record['afterSha'],None):raise ValueError('Arquivo mudou depois da instalacao; preservado: '+str(target))
        if record['beforeSha'] and digest(record['backup'])!=record['beforeSha']:raise ValueError('Backup alterado; restauracao cancelada.')
    for record in manifest['records']:
        target=Path(record['target'])
        if record['beforeSha']:
            if not target.is_file() or digest(target)!=record['beforeSha']:atomic(target,Path(record['backup']).read_bytes())
        elif target.exists():target.unlink()
    manifest['restored']=True;json_write(manifest['manifestPath'],manifest)
    return {'restored':True,'backup':str(Path(manifest['manifestPath']).parent)}

def restore(state):
    closed_resolve();index=Path(state)/'last_install.json'
    for _ in range(16):
        data=json.loads(index.read_text('utf-8'));manifest=json.loads(Path(data['manifest']).read_text('utf-8'))
        if not manifest.get('restored'):
            result=_restore(manifest)
            previous_index(state)
            return result
        # Repair a pointer left behind by an interrupted previous restore.
        previous_index(state)
        next_data=json.loads(index.read_text('utf-8'))
        if next_data['manifest']==data['manifest']:return {'restored':True,'alreadyRestored':True}
    raise ValueError('Cadeia de restauracao inconsistente; arquivos preservados.')

def previous_index(state):
    active=Path(state)/'active.json'
    if active.is_file():
        previous=json.loads(active.read_text('utf-8')).get('manifest')
        if previous and Path(previous).is_file():json_write(Path(state)/'last_install.json',{'manifest':previous})

def original_bytes(target,expected,config,state):
    if digest(target)==expected:return target.read_bytes()
    if not config:raise ValueError('Arquivo modificado; preservado: '+str(target))
    manifest_path=config.get('manifest')
    for _ in range(12):
        if not manifest_path:break
        manifest=json.loads(safe_path(manifest_path).read_text('utf-8'))
        previous=None
        for record in manifest['records']:
            if record['beforeSha'] and Path(record['target'])==target and record['beforeSha']==expected:
                backup=safe_path(record['backup'])
                if digest(backup)!=expected:raise ValueError('Backup base alterado; atualizacao cancelada.')
                return backup.read_bytes()
            if Path(record['target'])==state/'active.json' and record['beforeSha']:
                backup=safe_path(record['backup'])
                if digest(backup)!=record['beforeSha']:raise ValueError('Historico de instalacao alterado.')
                previous=json.loads(backup.read_text('utf-8')).get('manifest')
        manifest_path=previous
    raise ValueError('Nao localizei o codigo base verificado para atualizar: '+str(target))

def install(utility,motor,state):
    utility=safe_path(utility);motor=safe_path(motor);state=safe_path(state);panel=safe_path(utility/'Magic Edit.py');active=state/'active.json'
    closed_resolve()
    index=state/'last_install.json'
    if index.is_file():
        previous=json.loads(Path(json.loads(index.read_text('utf-8'))['manifest']).read_text('utf-8'))
        if not previous.get('completed') and not previous.get('restored'):
            raise ValueError('Uma instalacao foi interrompida. Execute RESTAURAR.bat antes de tentar novamente.')
    bundle=check_bundle()
    installed_config=None
    if active.is_file():
        config=json.loads(active.read_text('utf-8'))
        if panel.is_file() and motor.is_file() and digest(panel)==config.get('panelSha') and digest(motor)==config.get('motorSha'):
            installed_config=config
            transaction=json.loads(Path(config['manifest']).read_text('utf-8'))
            if not transaction.get('completed') or transaction.get('restored'):
                raise ValueError('Estado de instalacao incompleto. Execute RESTAURAR.bat.')
        if config.get('version')==VERSION and panel.is_file() and motor.is_file() and digest(panel)==config.get('panelSha') and digest(motor)==config.get('motorSha'):
            transaction=json.loads(Path(config['manifest']).read_text('utf-8'))
            if not transaction.get('completed') or transaction.get('restored'):raise ValueError('Estado de instalacao incompleto. Execute RESTAURAR.bat.')
            runtime=safe_path(config['runtime'])
            if (state/'versions') not in runtime.parents:raise ValueError('Pasta de runtime invalida.')
            for rel,sha in bundle.items():
                if not rel.startswith('runtime/'):continue
                target=runtime/rel[len('runtime/'):]
                if target.exists() and digest(target)!=sha:raise ValueError('Runtime modificado; preservado: '+str(target))
            for rel,sha in bundle.items():
                if rel.startswith('runtime/'):
                    target=runtime/rel[len('runtime/'):]
                    if not target.exists():atomic(target,(ROOT/rel).read_bytes())
            return {'alreadyInstalled':True,'movedBackups':0}
    if motor.name!='cortes_v1.py' or panel.name!='Magic Edit.py':raise ValueError('Arquivos de destino invalidos.')
    initial_panel=digest(panel);initial_motor=digest(motor)
    base_panel=original_bytes(panel,PANEL_SHA,installed_config,state)
    base_motor=original_bytes(motor,MOTOR_SHA,installed_config,state)
    if any(state==p.parent or state in p.parents or p.parent in state.parents for p in (panel,motor)):raise ValueError('Pasta de runtime sobrepoe a instalacao.')
    new_panel=patch_panel(base_panel);new_motor=patch_motor(base_motor)
    config=prepare_environment(state)
    version_dir=state/'versions'/(VERSION+'_'+digest(ROOT/'manifest.json')[:10])
    if installed_config:
        prior=safe_path(installed_config['runtime'])
        if (state/'versions') in prior.parents and all((prior/rel[len('runtime/'):]).is_file() and digest(prior/rel[len('runtime/'):])==sha for rel,sha in bundle.items() if rel.startswith('runtime/')):
            version_dir=prior
    version_dir.mkdir(parents=True,exist_ok=True)
    for rel,sha in bundle.items():
        if not rel.startswith('runtime/'):continue
        source=ROOT/rel;dest=version_dir/rel[len('runtime/'):]
        if dest.exists() and digest(dest)!=sha:raise ValueError('Runtime anterior alterado: '+str(dest))
        if not dest.exists():atomic(dest,source.read_bytes())
    old_backups=[safe_path(p) for p in sorted(utility.iterdir()) if p.is_file() and is_backup(p.name)]
    backup_root=state/'history'/(datetime.datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:6]);backup_root.mkdir(parents=True)
    manifest_path=backup_root/'manifest.json'
    config.update({'schema':1,'version':VERSION,'runtime':str(version_dir),'panelSha':hashlib.sha256(new_panel).hexdigest(),'motorSha':hashlib.sha256(new_motor).hexdigest(),'manifest':str(manifest_path),'minSilenceSeconds':.9})
    active_bytes=json.dumps(config,ensure_ascii=False,indent=2).encode()
    changes=[(panel,new_panel),(motor,new_motor),(active,active_bytes)]+[(p,None) for p in old_backups]
    records=[]
    for i,(target,new_data) in enumerate(changes):
        previous=target.read_bytes() if target.exists() else None;backup=backup_root/'before'/str(i)
        if previous is not None:atomic(backup,previous)
        record={'target':str(target),'backup':str(backup),'beforeSha':hashlib.sha256(previous).hexdigest() if previous is not None else None,'afterSha':hashlib.sha256(new_data).hexdigest() if new_data is not None else None}
        if previous is not None and digest(backup)!=record['beforeSha']:raise ValueError('Backup nao confere; nada foi substituido.')
        records.append(record)
    if digest(panel)!=initial_panel or digest(motor)!=initial_motor:raise ValueError('Arquivos mudaram durante o preparo; nada foi substituido.')
    manifest={'manifestPath':str(manifest_path),'records':records,'completed':False,'restored':False,'version':VERSION};json_write(manifest_path,manifest)
    # Durable recovery pointer exists before the first original is replaced.
    json_write(state/'last_install.json',{'manifest':str(manifest_path)})
    try:
        for target,data in changes:
            record=next(r for r in records if r['target']==str(target))
            current=digest(target) if target.is_file() else None
            if current!=record['beforeSha']:raise ValueError('Arquivo mudou durante a instalacao: '+str(target))
            if data is not None:atomic(target,data)
            else:
                archived=backup_root/'menu-backups'/target.name;archived.parent.mkdir(exist_ok=True);shutil.move(str(target),str(archived))
                if digest(archived)!=record['beforeSha']:raise ValueError('Copia movida nao confere.')
        for target,data in changes:
            if data is not None and target.read_bytes()!=data:raise ValueError('Pos-verificacao falhou.')
        compile(panel.read_bytes(),str(panel),'exec');compile(motor.read_bytes(),str(motor),'exec')
        manifest['completed']=True;json_write(manifest_path,manifest);json_write(state/'last_install.json',{'manifest':str(manifest_path)})
    except Exception:
        _restore(manifest);previous_index(state);raise
    return {'installed':True,'movedBackups':len(old_backups),'backup':str(backup_root),'runtime':str(version_dir)}

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--restore',action='store_true');args=parser.parse_args()
    state=Path(os.environ['LOCALAPPDATA'])/'MagicEdit/Silencios09'
    if args.restore:print(json.dumps(restore(state),ensure_ascii=False,indent=2));return
    utility=Path(os.environ['APPDATA'])/'Blackmagic Design/DaVinci Resolve/Support/Fusion/Scripts/Utility'
    panel=utility/'Magic Edit.py';motor=find_motor(panel)
    print('Painel:',panel,'\nMotor:',motor,'\nPreparando e conferindo backup...',flush=True)
    print(json.dumps(install(utility,motor,state),ensure_ascii=False,indent=2))
    print('Instalacao concluida. Abra o DaVinci e Magic Edit. Use primeiro uma timeline de bruto V1/A1.')
if __name__=='__main__':
    try:main()
    except Exception as exc:print('INTERROMPIDO:',exc,flush=True);sys.exit(1)
