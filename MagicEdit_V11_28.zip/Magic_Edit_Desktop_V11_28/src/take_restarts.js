// Retomadas proximas: comparar tentativas completas, preservando a ultima.
const norm=s=>String(s||'').toLowerCase().normalize('NFD').replace(/\p{M}/gu,'').replace(/[^\p{L}\p{N}]/gu,'');
const terminal=s=>/[.!?…]["”’)]?$/.test(s);
const interrupted=s=>/(?:\.\.\.|…)["”’)]?$/.test(s);
const contains=(haystack,needle)=>needle.length>0&&haystack.some((_,i)=>needle.every((t,k)=>t===haystack[i+k]));
const samePrefix=(a,b,n)=>a.length>=n&&b.length>=n&&a.slice(0,n).every((t,k)=>t===b[k]);
const meaningful=new Set(['a','o','as','os','um','uma','e','de','do','da','no','na','em','que','como','voce','ao','entao','quando','por','para','se']);
const dangling=new Set(['voce','eu','ele','ela','a','o','as','os','uma','um','de','do','da','com','sem','para','pra','que','e','mas','quando','se']);
const polarity=new Set(['nao','nunca','jamais','sem','nem','nenhum','nenhuma']);

export function safeInterruptedContent(firstTokens,laterTokens){
  const first=core(firstTokens.map(norm)),later=core(laterTokens.map(norm));
  const firstPolarity=first.filter(t=>polarity.has(t)),laterPolarity=later.filter(t=>polarity.has(t));
  if(firstPolarity.length||laterPolarity.length)return firstPolarity.join('|')===laterPolarity.join('|')&&contains(later,first);
  const unfinished=dangling.has(first.at(-1));
  if(!contains(later,first)&&!unfinished)return false;
  const numbers=part=>part.map(t=>t.replace(/\D/g,'')).filter(Boolean);
  const changed=numbers(first).some(n=>!numbers(later).includes(n));
  if(changed&&!unfinished)return false;
  // Conservar conteudo, ordem e multiplicidade, inclusive sujeitos internos.
  // Apenas a palavra pendente FINAL pode sair do alinhamento.
  const grammatical=t=>meaningful.has(t)&&t!=='voce';
  const content=first.slice(0,unfinished?-1:undefined).filter(t=>!grammatical(t)&&!(changed&&/^\d+$/.test(t)));
  const retained=later.filter(t=>!grammatical(t)&&!(changed&&/^\d+$/.test(t)));
  let cursor=0;
  for(const token of retained)if(token===content[cursor])cursor++;
  return cursor===content.length;
}

function core(tokens){
  let out=[...tokens];
  while(out[0]==='entao'||out[0]==='agora')out.shift();
  if(out[0]==='proximo'&&out[1]==='passo')out.splice(0,2);
  if(out[0]==='um'&&out[1]==='exemplo')out.shift();
  if(out[0]==='exemplo'){
    out.shift();if(['de','que'].includes(out[0]))out.shift();
  }
  return out.filter((t,i)=>!(t==='que'&&out[i-1]==='como'));
}
function units(words,tokens){
  const starts=new Set([0]);
  for(let i=1;i<words.length;i++){
    if(terminal(words[i-1].word)||words[i].start-words[i-1].end>=.6)starts.add(i);
    if(tokens[i]==='proximo'&&tokens[i+1]==='passo')starts.add(i);
    if(tokens[i]==='entao'&&(tokens[i+1]==='exemplo'||tokens[i+1]==='quando'||tokens[i+1]==='um'&&tokens[i+2]==='exemplo'))starts.add(i);
    if(tokens[i]==='ao'&&/^[\p{L}]{3,}[aei]r$/u.test(tokens[i+1]||''))
      starts.add(tokens[i-1]==='entao'?i-1:i);
  }
  const indices=[...starts].sort((a,b)=>a-b);
  return indices.map((from,k)=>{
    const to=(indices[k+1]??words.length)-1;
    const raw=tokens.slice(from,to+1);
    return {from,to,raw,core:core(raw),ellipsis:interrupted(words[to].word),question:/\?$/.test(words[to].word)};
  });
}
function intentional(words,unit){
  const text=words.slice(Math.max(0,unit.from-5),unit.to+1).map(w=>norm(w.word)).join(' ');
  return /\b(repito|enfase|novamente|importante|repetindo)\b/.test(text)||
    /\b(por exemplo|outro exemplo|primeiro exemplo|segundo exemplo|como eu disse)\b/.test(text);
}
function matching(a,b){
  let longest=0,previous=Array(b.length+1).fill(0),lcs=Array(b.length+1).fill(0);
  for(const token of a){
    const next=Array(b.length+1).fill(0),nextLcs=[0];
    for(let j=0;j<b.length;j++){
      if(token===b[j]){next[j+1]=previous[j]+1;longest=Math.max(longest,next[j+1]);}
      nextLcs[j+1]=token===b[j]?lcs[j]+1:Math.max(lcs[j+1],nextLcs[j]);
    }
    previous=next;lcs=nextLcs;
  }
  return {longest,coverage:a.length?lcs.at(-1)/a.length:0};
}

export function detectTakeRestarts(words){
  if(!Array.isArray(words)||!words.length)return [];
  const tokens=words.map(w=>norm(w.word)),takes=units(words,tokens),result=[];
  const near=(first,last)=>last.from>first.to&&words[last.from].start-words[first.to].end>=0&&words[last.from].start-words[first.to].end<=12;
  function add(first,last,kind,matched){
    if(first.to-first.from>=120||words[first.to].end-words[first.from].start>45)return;
    if(intentional(words,first)||intentional(words,last))return;
    if(kind==='question-rephrase'&&!safeInterruptedContent(first.core,last.core))return;
    if(kind==='infinitive-chain'&&last.core.some(t=>polarity.has(t)))return;
    let keepTo=last.to;
    // Uma respiracao pode dividir a conclusao ("150, [pausa] bateu 250 reais").
    // O marcador da tomada preservada acompanha essa continuacao ate o ponto.
    while(keepTo+1<words.length&&!terminal(words[keepTo].word)&&keepTo-last.from<120&&
          words[keepTo+1].start-words[keepTo].end<=2&&words[keepTo+1].end-words[last.from].start<=45&&
          !['entao','agora','proximo','ao'].includes(tokens[keepTo+1]))keepTo++;
    result.push({type:'restart',from:first.from,to:first.to,start:words[first.from].start,end:words[first.to].end,
      keepFrom:last.from,keepTo,confidence:'alta',automatic:true,origin:'retake-local',retakeKind:kind,matchedWords:matched,
      reason:kind==='infinitive-chain'?'Tentativas curtas interrompidas; preservar a retomada completa':
        kind==='question-rephrase'?'Pergunta retomada com outra introdução; preservar a última versão':
        'Tentativa interrompida e reformulada; preservar a última versão completa'});
  }
  // Perguntas equivalentes por contencao literal, com introducao na retomada.
  for(let j=0;j<takes.length;j++){
    const last=takes[j];
    if(last.ellipsis||!last.question||last.core.length<3||!['entao','agora','proximo'].includes(last.raw[0]))continue;
    for(let i=Math.max(0,j-3);i<j;i++){
      const first=takes[i];
      if(!first.question||first.ellipsis||first.core.length<3||!near(first,last))continue;
      if(!contains(last.core,first.core))continue;
      // Nada relevante entre as tentativas pode desaparecer junto com elas.
      const between=takes.slice(i+1,j);
      if(between.some(t=>!t.question||!contains(last.core,t.core)))continue;
      add(first,last,'question-rephrase',first.core.length);
    }
  }
  // Reticencias + mesma abertura permitem corrigir inclusive um valor numerico.
  for(let i=0;i<takes.length;i++){
    const first=takes[i];
    if(!first.ellipsis||first.core.length<3||first.core.length>120)continue;
    for(let j=i+1;j<Math.min(takes.length,i+3);j++){
      const last=takes[j];if(last.ellipsis||!near(first,last)||!samePrefix(first.core,last.core,3))continue;
      const match=matching(first.core,last.core);
      if(match.longest<3||match.coverage<.65||first.core.filter(t=>!meaningful.has(t)).length<2)continue;
      if(!safeInterruptedContent(first.core,last.core))continue;
      if(takes.slice(i+1,j).some(t=>t.core.length>1))continue;
      add(first,last,'interrupted-rephrase',match.longest);break;
    }
  }
  // Uma cadeia de "ao + infinitivo" incompleta so sai com retomada conjugada
  // e objeto correspondente. Uma unica expressao curta continua protegida.
  for(let j=2;j<takes.length;j++){
    const last=takes[j];if(last.ellipsis||last.core.length<5)continue;
    const stubs=[];
    for(let i=j-1;i>=Math.max(0,j-4);i--){
      const first=takes[i],c=first.core;
      if(!near(first,last)||c[0]!=='ao'||c.length<2||c.length>6||!/[aei]r$/.test(c[1]))break;
      const needle=[c[1].slice(0,-1),...c.slice(2)];
      if(!contains(last.core,needle))break;
      stubs.unshift(first);
    }
    if(stubs.length<2)continue;
    for(const first of stubs)add(first,last,'infinitive-chain',first.core.length);
  }
  return result;
}
