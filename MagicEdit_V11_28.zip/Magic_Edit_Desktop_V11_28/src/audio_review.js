import {cutRanges} from './engine.js';
import {timelineRangeRemoved} from './selection.js';

export function cleanAudioSuggestions(items,duration){
 if(!Array.isArray(items)||!Number.isFinite(duration)||duration<=0)return [];
 return items.slice(0,2000).filter(s=>s&&s.origin==='gemini-audio'&&Number.isFinite(s.start)&&Number.isFinite(s.end)&&s.start>=0&&s.end>s.start&&s.end<=duration&&s.end-s.start<=45).map(s=>({
   start:s.start,end:s.end,origin:'gemini-audio',category:String(s.category||'restart').slice(0,20),
   reason:String(s.reason||'Trecho indicado pelo Gemini').slice(0,220),spokenText:String(s.spokenText||'').slice(0,500),
   confidence:s.requiresReview===false&&s.confidence==='alta'?'alta':'revisar',requiresReview:!(s.requiresReview===false&&s.confidence==='alta'),
   keepStart:Number.isFinite(s.keepStart)&&s.keepStart>=s.end&&s.keepEnd<=duration&&s.keepEnd>s.keepStart?s.keepStart:null,
   keepEnd:Number.isFinite(s.keepStart)&&s.keepStart>=s.end&&Number.isFinite(s.keepEnd)&&s.keepEnd<=duration&&s.keepEnd>s.keepStart?s.keepEnd:null
 }));
}

export function mergeAudioReports(previous,incoming,duration){
 const merged=new Map();
 for(const s of [...cleanAudioSuggestions(previous,duration),...cleanAudioSuggestions(incoming,duration)]){
  const key=`${s.start.toFixed(4)}:${s.end.toFixed(4)}`,old=merged.get(key);
  merged.set(key,old&&s.keepStart===null&&old.keepStart!==null?{...s,keepStart:old.keepStart,keepEnd:old.keepEnd}:s);
 }
 return [...merged.values()].slice(-2000);
}

export function applyAudioSuggestions(words,deleted,extraCuts,items,duration,previous=[]){
 const candidates=cleanAudioSuggestions(items,duration),next=new Set(deleted),cuts=extraCuts.map(c=>({...c}));let applied=0;
 const keeps=[...candidates.filter(s=>!s.requiresReview),...cleanAudioSuggestions(previous,duration)]
  .filter(s=>s.keepStart!==null&&s.keepEnd!==null).map(s=>({start:s.keepStart,end:s.keepEnd}));
 for(const s of candidates){
  if(s.requiresReview)continue;
  if(keeps.some(k=>s.start<k.end&&s.end>k.start)){s.requiresReview=true;s.confidence='revisar';continue;}
  const current=cutRanges(words,next,cuts,duration);
  if(s.keepStart!==null&&current.some(c=>c.start<s.keepEnd&&c.end>s.keepStart)){s.requiresReview=true;s.confidence='revisar';continue;}
  if(timelineRangeRemoved(current,s))continue;
  const proposed=cutRanges(words,next,[...cuts,{start:s.start,end:s.end}],duration);
  // Never remove the last remaining speech or the entire source automatically.
  if(words.length?words.every(w=>timelineRangeRemoved(proposed,w)):timelineRangeRemoved(proposed,{start:0,end:duration}))continue;
  cuts.push({start:s.start,end:s.end});applied++;
 }
 return {deleted:next,extraCuts:cuts,applied,suggestions:candidates};
}
