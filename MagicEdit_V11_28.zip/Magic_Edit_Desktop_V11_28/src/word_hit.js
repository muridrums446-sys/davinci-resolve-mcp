// Browser text selection stays native; this only resolves clicks that land on a space.
export function wordFromPoint(event, transcript, doc=document) {
  if (!transcript.contains(event.target)) return null;
  const direct=event.target?.closest?.('.word[data-idx]');
  if (direct) return direct;
  const textNode=doc.caretRangeFromPoint?.(event.clientX,event.clientY)?.startContainer
    || doc.caretPositionFromPoint?.(event.clientX,event.clientY)?.offsetNode;
  const fromCaret=textNode?.parentElement?.closest?.('.word[data-idx]');
  if (fromCaret && transcript.contains(fromCaret)) return fromCaret;
  // Espacos entre spans pertencem ao paragrafo, nao a uma palavra.
  // Limitar a busca à linha e a 12px evita saltos ao clicar no fundo vazio.
  const paragraph=event.target?.closest?.('.transcript-paragraph');
  let nearest=null,distance=13;
  for(const word of paragraph?.querySelectorAll?.('.word[data-idx]')||[]){
    for(const rect of word.getClientRects()){
      if(event.clientY<rect.top||event.clientY>rect.bottom)continue;
      const dx=Math.max(rect.left-event.clientX,0,event.clientX-rect.right);
      if(dx<distance){nearest=word;distance=dx;}
    }
  }
  if(nearest)return nearest;
  return null;
}
