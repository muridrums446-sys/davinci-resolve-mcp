// O relogio da previa continua em segundos do video original, como o XML e as palavras.
export function playbackTarget(time,cuts,duration){
  const t=Math.max(0,Math.min(duration,Number(time)||0));
  for(const cut of cuts){
    if(t<cut.start)return {time:t,ended:false};
    if(t<cut.end){
      if(cut.end>=duration-0.0001)return {time:cut.start,ended:true};
      return {time:cut.end,ended:false};
    }
  }
  return {time:t,ended:t>=duration};
}

export function filmstripSamples(view,width,tileWidth=112){
  const count=Math.max(1,Math.min(24,Math.ceil(width/tileWidth)));
  return Array.from({length:count},(_,i)=>Math.min(view.duration-0.001,view.start+(i+.5)*view.span/count));
}

export function manualCutRange(first,second,duration){
  const start=Math.min(first,second),end=Math.max(first,second);
  if(!Number.isFinite(start)||!Number.isFinite(end)||start<0||end>duration||end-start<.04)return null;
  return {start,end};
}

// Uma divisao e apenas um limite em frames; so o Delete cria um corte real.
export function splitFrameAt(time, totalFrames, fps){
  if(!Number.isFinite(time)||!Number.isFinite(fps)||fps<=0)return null;
  const frame=Math.round(time*fps);
  return frame>0&&frame<totalFrames?frame:null;
}

export function segmentAtTime(time,splitFrames,totalFrames,fps){
  if(!Number.isFinite(time)||!Number.isFinite(fps)||fps<=0||totalFrames<2)return null;
  const frame=Math.max(0,Math.min(totalFrames-1,Math.floor(time*fps+1e-7)));
  const points=[0,...splitFrames.filter(x=>Number.isInteger(x)&&x>0&&x<totalFrames).sort((a,b)=>a-b),totalFrames];
  const endIndex=points.findIndex(x=>x>frame);
  if(endIndex<1)return null;
  return {start:points[endIndex-1]/fps,end:points[endIndex]/fps};
}
