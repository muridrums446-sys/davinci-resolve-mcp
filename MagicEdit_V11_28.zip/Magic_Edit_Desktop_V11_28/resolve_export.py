"""FCPXML 1.9 editavel, com opcao de master MP4 completo ao lado da timeline.

O master conserva os tempos do original e as sobras dos cortes. Nao usar o MP4
editado/concatenado como fonte: isso impediria ajustar as entradas no Resolve.
"""
from __future__ import annotations

import os
import re
import tempfile
import uuid
import xml.etree.ElementTree as ET
from fractions import Fraction
from pathlib import Path, PureWindowsPath

from mp4_export import _publish_video, _run, _verify_video, validate_segments


def media_uri(source: str) -> str:
    if re.match(r'^[A-Za-z]:[\\/]', source) or source.startswith('\\\\'):
        return PureWindowsPath(source).as_uri()
    return Path(source).resolve().as_uri()


def build_fcpxml(source: str, media: dict, segments: list[dict], name: str) -> str:
    ranges = validate_segments(segments, media)
    frame = Fraction(media['fpsDen'], media['fpsNum'])
    def at(frames):
        value = frames * frame
        return f'{value.numerator}/{value.denominator}s' if value else '0s'
    root = ET.Element('fcpxml', version='1.9')
    resources = ET.SubElement(root, 'resources')
    ET.SubElement(resources, 'format', id='r1', frameDuration=at(1),
                  width=str(int(media.get('width',1920))), height=str(int(media.get('height',1080))))
    total = round(media['duration'] / float(frame))
    asset = ET.SubElement(resources, 'asset', id='r2', name=source.replace('\\','/').rsplit('/',1)[-1],
                          start='0s', duration=at(total), hasVideo='1', hasAudio='1', format='r1',
                          audioSources='1', audioChannels=str(int(media.get('audioChannels') or 2)),
                          audioRate=str(int(media.get('audioRate') or 48000)))
    ET.SubElement(asset, 'media-rep', kind='original-media', src=media_uri(source))
    library = ET.SubElement(root,'library')
    event = ET.SubElement(library,'event',name='Magic Edit')
    project = ET.SubElement(event,'project',name=name)
    length = sum(end-start for start,end in ranges)
    sequence = ET.SubElement(project,'sequence',format='r1',duration=at(length),
                             tcStart='0s',tcFormat='NDF',audioLayout='stereo',audioRate='48k')
    spine = ET.SubElement(sequence,'spine')
    cursor = 0
    for i,(start,end) in enumerate(ranges):
        ET.SubElement(spine,'asset-clip',name=f'{asset.get("name")} - {i+1}',ref='r2',
                      offset=at(cursor),start=at(start),duration=at(end-start),format='r1',
                      audioRole='dialogue')
        cursor += end-start
    ET.indent(root,space='  ')
    return '<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE fcpxml>\n'+ET.tostring(root,encoding='unicode')+'\n'


def export_resolve(source: str, media: dict, segments: list[dict], target: str,
                   name: str, compatible: bool, ffmpeg: str,
                   progress=lambda done,total: None, ffprobe: str='ffprobe') -> dict:
    ranges = validate_segments(segments,media)
    original,destination = Path(source).resolve(),Path(target).resolve()
    if destination.suffix.lower()!='.fcpxml' or destination==original:
        raise ValueError('Escolha outro nome .fcpxml; o video original deve ser preservado.')
    master = destination.with_name(destination.stem+'.media.mp4')
    for path in [destination]+([master] if compatible else []):
        if path==original or path.exists():
            raise ValueError('Ja existe um arquivo com esse nome. Escolha outro para preservar os arquivos anteriores.')
    if not original.is_file():
        raise ValueError('O video original nao foi encontrado. Abra novamente o projeto e selecione a midia.')
    destination.parent.mkdir(parents=True,exist_ok=True)
    media_path = master if compatible else original
    export_media = dict(media)
    if compatible:
        export_media.update(audioChannels=2,audioRate=48000)
    xml = build_fcpxml(str(media_path),export_media,segments,name)
    pending = destination.with_name('.magicedit_'+uuid.uuid4().hex+'.partial.fcpxml')
    published_master = False
    try:
        progress(0,100)
        if compatible:
            frame = Fraction(media['fpsDen'],media['fpsNum'])
            duration = round(media['duration']/float(frame))*float(frame)
            rate = f'{media["fpsNum"]}/{media["fpsDen"]}'
            with tempfile.TemporaryDirectory(prefix='magicedit_resolve_') as folder:
                rendered = Path(folder)/'master.mp4'
                _run([ffmpeg,'-hide_banner','-loglevel','error','-nostdin','-nostats',
                      '-progress','pipe:1','-i',str(original),'-map','0:v:0','-map','0:a:0',
                      '-vf',f'tpad=stop_mode=clone:stop_duration=1,fps={rate}:start_time=0',
                      '-af','apad','-t',f'{duration:.9f}',
                      '-c:v','libx264','-preset','fast','-crf','16','-pix_fmt','yuv420p',
                      '-c:a','aac','-b:a','320k','-ar','48000','-ac','2',
                      '-movflags','+faststart',str(rendered)],duration,
                     lambda fraction:progress(95*fraction,100))
                _verify_video(rendered,duration,ffprobe)
                _publish_video(rendered,master,lambda done,total:progress(95+done/100*3,100))
                published_master = True
        # Publicar a timeline somente depois da midia pronta e verificada.
        with pending.open('x',encoding='utf-8',newline='\n') as output:
            output.write(xml);output.flush();os.fsync(output.fileno())
        # Windows rename recusa destino existente. No POSIX, link publica de
        # forma atomica com a mesma garantia, mesmo se surgir durante o render.
        if os.name=='nt':
            pending.rename(destination)
        else:
            os.link(pending,destination)
    except Exception:
        if published_master:master.unlink(missing_ok=True)
        raise
    finally:
        pending.unlink(missing_ok=True)
    progress(100,100)
    return dict(path=str(destination),mediaPath=str(media_path),compatible=compatible,
                segments=len(ranges),duration=sum(end-start for start,end in ranges)*media['fpsDen']/media['fpsNum'])
