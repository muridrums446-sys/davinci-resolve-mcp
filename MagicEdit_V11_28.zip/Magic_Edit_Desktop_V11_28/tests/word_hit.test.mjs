import test from 'node:test';
import assert from 'node:assert/strict';
import {wordFromPoint} from '../src/word_hit.js';

test('um clique no espaco junto da palavra encontra a palavra pelo cursor do navegador',()=>{
  const word={dataset:{idx:'9'}};
  const paragraph={closest(){return null;}};
  const textNode={parentElement:{closest(selector){return selector==='.word[data-idx]'?word:null;}}};
  const transcript={contains(node){return node===paragraph||node===word||node===textNode;}};
  const doc={caretRangeFromPoint(){return {startContainer:textNode};}};
  assert.equal(wordFromPoint({target:paragraph,clientX:100,clientY:20},transcript,doc),word);
});

test('um clique fora da transcricao nao busca palavras',()=>{
  const transcript={contains(){return false;}};
  assert.equal(wordFromPoint({target:{closest(){return null;}},clientX:10,clientY:10},transcript,{}),null);
});

test('espaco entre spans encontra a palavra mais proxima apenas na mesma linha',()=>{
 const word={getClientRects(){return [{left:100,right:140,top:20,bottom:40}];}};
 const paragraph={querySelectorAll(){return [word];},closest(selector){return selector==='.transcript-paragraph'?this:null;}};
 const transcript={contains(){return true;}};
 assert.equal(wordFromPoint({target:paragraph,clientX:145,clientY:30},transcript,{}),word);
 assert.equal(wordFromPoint({target:paragraph,clientX:145,clientY:70},transcript,{}),null);
});
