import test from 'node:test';
import assert from 'node:assert/strict';
import {normalizedSelection, chooseRange, toggleRange,cutWordIndices,toggleTranscriptCut} from '../src/selection.js';
import {cutRanges, exportFcp7Xml} from '../src/engine.js';
const words=[
  {word:'Hoje',start:0,end:.3},
  {word:'eu',start:.48,end:.65},
  {word:'falei',start:.72,end:1.05},
  {word:'errado',start:1.5,end:2.1},
  {word:'agora',start:2.2,end:2.6}
];
test('Arrastar na ordem inversa normaliza selecao, limites respeitados',()=>{
  assert.deepEqual(normalizedSelection(3,1,5),{start:1,end:3});
  assert.deepEqual(normalizedSelection(-1,200,5),{start:0,end:4});
});
test('Clique direito corta e o segundo clique restaura a frase',()=>{
  const range={start:1,end:3};
  const first=toggleRange(new Set(),range);
  assert.equal(first.action,'deleted');
  assert.deepEqual([...first.deleted],[1,2,3]);
  const again=toggleRange(first.deleted,range);
  assert.equal(again.action,'restored');
  assert.equal(again.deleted.size,0);
});
test('Selecao parcialmente cortada => corta o conjunto todo',()=>{
  const res=toggleRange(new Set([1,3]),{start:1,end:3});
  assert.deepEqual([...res.deleted],[1,3,2]);
});
test('Clique sem selecao restaura bloco contiguo de palavras cortadas',()=>{
  const r=chooseRange(new Set([1,2,3]),null,2,5);
  assert.deepEqual(r,{start:1,end:3});
  assert.deepEqual(chooseRange(new Set([1,2,3]),{start:1,end:3},1,5),{start:1,end:3});
  assert.deepEqual(chooseRange(new Set(),null,4,5),{start:4,end:4});
});
test('Apagar frase inclui pausas entre palavras e no XML',()=>{
  const deleted=new Set([1,2,3]);
  const cuts=cutRanges(words,deleted,[],3);
  assert.equal(cuts.length,1);
  assert.ok(cuts[0].start<words[1].start);
  assert.ok(cuts[0].end>words[3].end);
  const xml=exportFcp7Xml({path:'C:\\Video\\meu.mkv',media:{name:'meu.mkv',duration:3,fpsNum:30,fpsDen:1,width:1920,height:1080},words,deletedIndices:deleted});
  assert.equal((xml.match(/<clipitem id="v_/g)||[]).length,2);
  assert.equal((xml.match(/<clipitem id="a_/g)||[]).length,2);
});
test('corte da timeline risca palavras reais e clique direito restaura texto e tempo',()=>{
 const cuts=[{start:.45,end:1.1},{start:1.4,end:2.15}];
 assert.deepEqual([...cutWordIndices(words,cuts).covered],[1,2,3]);
 const restored=toggleTranscriptCut(words,new Set([2]),cuts,{start:1,end:2});
 assert.equal(restored.action,'restored');
 assert.deepEqual([...restored.deleted],[]);
 assert.deepEqual(restored.extraCuts,[cuts[1]],'somente o corte ligado as palavras escolhidas e restaurado');
 const cutAgain=toggleTranscriptCut(words,restored.deleted,restored.extraCuts,{start:1,end:2});
 assert.equal(cutAgain.action,'deleted');
 assert.deepEqual([...cutAgain.deleted],[1,2]);
});
