import unittest
from magicedit_server import trim_and_offset_words
from mp4_export import validate_segments

class SpeechBoundariesTest(unittest.TestCase):
    def test_whisper_zero_length_words_are_preserved_with_estimated_timing(self):
        parts=[dict(lo=0,hi=10,origin=0,stop=10,words=[
            dict(word='vou',start=1,end=1.2),dict(word='a',start=1.2,end=1.2),
            dict(word='bolsa',start=1.3,end=1.6)])]
        result=trim_and_offset_words(parts)
        self.assertEqual([w['word'] for w in result],['vou','a','bolsa'])
        self.assertTrue(result[1]['timingEstimated'])
        self.assertGreater(result[1]['end'],result[1]['start'])

    def test_duplicate_overlap_cannot_reverse_the_order_from_either_chunk(self):
        parts=[dict(lo=0,hi=30,origin=0,stop=32,words=[
            dict(word='vou',start=29.5,end=29.8),dict(word='agora',start=29.8,end=30.1),dict(word='explicar',start=30.1,end=30.4)]),
            dict(lo=30,hi=60,origin=28,stop=60,words=[
            dict(word='vou',start=1.55,end=1.85),dict(word='agora',start=1.70,end=2.0),dict(word='explicar',start=2.0,end=2.3)])]
        self.assertEqual([w['word'] for w in trim_and_offset_words(parts)],['vou','agora','explicar'])

    def test_two_occurrences_in_one_chunk_are_not_collapsed_into_one_neighbor_word(self):
        parts=[dict(lo=0,hi=30,origin=0,stop=32,words=[dict(word='não',start=29.7,end=30.2)]),
               dict(lo=30,hi=60,origin=28,stop=60,words=[dict(word='não',start=1.75,end=2.1),dict(word='não',start=1.80,end=2.15),dict(word='corte',start=2.2,end=2.5)])]
        self.assertEqual([w['word'] for w in trim_and_offset_words(parts)],['não','não','corte'])

    def test_mp4_accepts_one_frame_that_xml_and_preview_preserve(self):
        self.assertEqual(validate_segments([{'in':10,'out':11}],{'duration':1,'fpsNum':25,'fpsDen':1}),[(10,11)])
