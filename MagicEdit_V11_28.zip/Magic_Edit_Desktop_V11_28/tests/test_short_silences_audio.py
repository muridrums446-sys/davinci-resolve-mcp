"""Audio, FFmpeg e Silero reais; palavras conhecidas da fixture sintetica."""
import hashlib
import json
import subprocess
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import magicedit_server as app
import vad_local
from audio_wave import peaks_from_pcm

ROOT=Path(__file__).resolve().parents[1]

class ShortSilenceAudioTest(unittest.TestCase):
    def test_real_audio_removes_eight_tenths_but_preserves_six_tenths_and_words(self):
        with tempfile.TemporaryDirectory() as tmp:
            source=Path(tmp)/'pausas.mp4'
            subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i','color=c=blue:size=160x90:rate=25:duration=4.4',
                '-f','lavfi','-i','sine=frequency=440:sample_rate=16000:duration=4.4',
                '-af',"aeval=exprs='if(between(t,1,1.8)+between(t,2.8,3.4),0,val(0))',aformat=channel_layouts=mono",
                '-c:v','libx264','-c:a','aac','-shortest',str(source)],check=True)
            before=hashlib.sha256(source.read_bytes()).hexdigest()
            raw=app.run_process(['ffmpeg','-v','error','-i',str(source),'-vn','-ac','1','-ar','2000','-f','s16le','-'])
            peaks=peaks_from_pcm(raw,rate=2000,bins_per_second=20)
            with patch.object(vad_local,'CACHE',Path(tmp)/'cache'):
                vad=vad_local.analyze(str(source),'ffmpeg',4.4)
            self.assertEqual(vad['state'],'done')
            payload=dict(words=[dict(word='antes',start=0,end=1),dict(word='meio',start=1.8,end=2.8),dict(word='depois',start=3.4,end=4.4)],
                         duration=4.4,peaks=peaks,speech=vad['speech'],speechPadding=vad['speechPadding'],norm=max(peaks))
            script="""import fs from 'node:fs';import {detectVerifiedSilences} from './src/editor_v09.js';
const f=JSON.parse(fs.readFileSync(0,'utf8'));console.log(JSON.stringify(detectVerifiedSilences(f.words,f.duration,f.peaks,20,{speech:f.speech,speechPadding:f.speechPadding,norm:f.norm,strength:50,minSilenceSeconds:.7})));"""
            cuts=json.loads(subprocess.check_output(['node','--input-type=module','-e',script],input=json.dumps(payload).encode(),cwd=ROOT))
            self.assertEqual(len(cuts),1,cuts)
            self.assertGreaterEqual(cuts[0]['start'],1.08)
            self.assertLessEqual(cuts[0]['end'],1.72)
            self.assertGreater(cuts[0]['end']-cuts[0]['start'],.4)
            self.assertEqual(hashlib.sha256(source.read_bytes()).hexdigest(),before)

if __name__=='__main__':unittest.main()
