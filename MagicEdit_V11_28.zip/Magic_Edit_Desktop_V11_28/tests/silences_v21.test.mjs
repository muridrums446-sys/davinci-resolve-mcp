import test from 'node:test';
import assert from 'node:assert/strict';
import {detectVerifiedSilences} from '../src/editor_v09.js';

function fixture(gap,limit=.7){
 const words=[{word:'antes',start:0,end:.5},{word:'depois',start:.5+gap,end:1+gap}];
 const speech=words.map(({start,end})=>({start,end}));
 const duration=1+gap,peaks=Array(Math.ceil(duration*20)).fill(2);
 for(let i=0;i<10;i++)peaks[i]=100;
 for(let i=Math.ceil((.5+gap)*20);i<peaks.length;i++)peaks[i]=100;
 return {words,duration,peaks,options:{norm:100,speech,strength:50,minSilenceSeconds:limit}};
}
const detect=f=>detectVerifiedSilences(f.words,f.duration,f.peaks,20,f.options);
test('limite de 0,7 s mede pausa antes das margens; corta pausas curtas acima dele',()=>{
 for(const gap of [.71,.8,1,2]){
  const f=fixture(gap),cuts=detect(f);
  assert.equal(cuts.length,1,`pausa de ${gap}s deve ser cortada`);
  assert.ok(cuts[0].start>=.58&&cuts[0].end<=.5+gap-.08,'preservar bordas');
 }
 for(const gap of [.2,.5,.69,.7])assert.deepEqual(detect(fixture(gap)),[],`nao cortar pausa <= limite: ${gap}`);
});
test('limite ajustavel admite 0,3 s sem confundir margem com duracao minima',()=>{
 assert.equal(detect(fixture(.4,.3)).length,1);
 assert.deepEqual(detect(fixture(.4,.7)),[]);
});
test('margem de 0,22 s do Silero nao reduz a duracao medida da pausa',()=>{
 for(const gap of [.71,.8,1]){
  const f=fixture(gap);f.options.speechPadding=.22;
  f.options.speech=[{start:0,end:.72},{start:.5+gap-.22,end:1+gap}];
  const cuts=detect(f);assert.equal(cuts.length,1,`Silero com margem: pausa de ${gap}s`);
  assert.ok(cuts[0].start>=.72&&cuts[0].end<=.5+gap-.22,'nao invadir margem de voz');
 }
 const f=fixture(.6);f.options.speechPadding=.22;
 f.options.speech=[{start:0,end:.72},{start:.88,end:1.6}];assert.deepEqual(detect(f),[]);
});
test('voz baixa sem transcricao e palavras fora do VAD continuam protegidas',()=>{
 const f=fixture(.8);f.peaks.fill(1);
 f.options.speech.push({start:.65,end:1.15});assert.deepEqual(detect(f),[]);
 f.options.speech.pop();f.words.splice(1,0,{word:'baixinho',start:.65,end:1.15});assert.deepEqual(detect(f),[]);
});
test('ausencia de VAD, som sustentado e audio incompleto nao viram silencio',()=>{
 const f=fixture(2);f.options.speech=null;assert.deepEqual(detect(f),[]);
 f.options.speech=[];f.peaks.fill(90);assert.deepEqual(detect(f),[]);
 f.peaks=Array(20).fill(1);assert.deepEqual(detect(f),[]);
});
test('controle de intensidade nao desfaz cortes com limite explicito',()=>{
 const f=fixture(1),results=[0,25,50,75,100].map(strength=>detect({...f,options:{...f.options,strength}}));
 for(let i=1;i<results.length;i++){
  assert.ok(results[i][0].start<=results[i-1][0].start);
  assert.ok(results[i][0].end>=results[i-1][0].end);
 }
});
