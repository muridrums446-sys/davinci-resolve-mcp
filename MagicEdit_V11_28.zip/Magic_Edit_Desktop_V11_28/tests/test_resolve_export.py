import hashlib
import os
import json
import subprocess
import sys
import tempfile
import unittest
import xml.etree.ElementTree as ET
from fractions import Fraction
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))

def seconds(value):
    return Fraction(value.removesuffix('s'))

class ResolveExportTest(unittest.TestCase):
    def exporter(self):
        self.assertTrue((ROOT/'resolve_export.py').exists(), 'Exportador FCPXML ainda ausente')
        import resolve_export
        return resolve_export

    def test_fcpxml_19_is_editable_frame_exact_and_references_real_media(self):
        app = self.exporter()
        for num, den in [(25, 1), (30000, 1001), (24000, 1001)]:
            with self.subTest(rate=(num, den)):
                media = dict(duration=10, fpsNum=num, fpsDen=den, width=1920, height=1080,
                             audioChannels=1, audioRate=44100)
                ranges = [{'in':1,'out':2}, {'in':15,'out':45}, {'in':90,'out':100}]
                text = app.build_fcpxml('C:\\Vídeos & aulas\\Ação #1.mov', media, ranges, 'Aula & cortes')
                xml = ET.fromstring(text)
                self.assertEqual(xml.tag, 'fcpxml')
                self.assertEqual(xml.get('version'), '1.9')
                self.assertIn('<!DOCTYPE fcpxml>', text)
                fmt = xml.find('./resources/format')
                frame = Fraction(den,num)
                self.assertEqual(seconds(fmt.get('frameDuration')), frame)
                asset = xml.find('./resources/asset')
                self.assertEqual(asset.get('audioChannels'), '1')
                uri = asset.find('media-rep').get('src')
                self.assertEqual(uri, 'file:///C:/V%C3%ADdeos%20%26%20aulas/A%C3%A7%C3%A3o%20%231.mov')
                sequence = xml.find('.//sequence')
                clips = sequence.findall('./spine/asset-clip')
                self.assertEqual(len(clips), 3)
                cursor = 0
                for clip, segment in zip(clips, ranges):
                    self.assertEqual(clip.get('ref'),asset.get('id'))
                    self.assertEqual(seconds(clip.get('offset')),cursor*frame)
                    self.assertEqual(seconds(clip.get('start')),segment['in']*frame)
                    self.assertEqual(seconds(clip.get('duration')),(segment['out']-segment['in'])*frame)
                    cursor += segment['out']-segment['in']
                self.assertEqual(seconds(sequence.get('duration')),cursor*frame)
                self.assertEqual(sequence.get('tcStart'),'0s')
                self.assertEqual(sequence.get('audioRate'),'48k')
                self.assertEqual(xml.find('.//project').get('name'), 'Aula & cortes')

    def make_source(self, root):
        source=root/'original ação.mkv'
        subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i','testsrc2=size=160x90:rate=25:duration=4',
                        '-f','lavfi','-i','sine=frequency=440:sample_rate=48000:duration=4',
                        '-shortest','-c:v','libx264','-c:a','aac',str(source)],check=True)
        return source, dict(duration=4, fpsNum=25, fpsDen=1, width=160, height=90)

    def test_compatible_export_keeps_full_source_handles_original_and_synced_av(self):
        app=self.exporter()
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);source,media=self.make_source(root)
            before=hashlib.sha256(source.read_bytes()).hexdigest()
            target=root/'Aula #1.fcpxml'
            updates=[]
            ranges=[{'in':10,'out':25},{'in':50,'out':75}]
            result=app.export_resolve(str(source),media,ranges,str(target),'Aula',True,'ffmpeg',lambda *x:updates.append(x),'ffprobe')
            xml=ET.parse(target)
            uri=xml.find('./resources/asset/media-rep').get('src')
            master=root/'Aula #1.media.mp4'
            self.assertEqual(uri,master.as_uri())
            data=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(master)]))
            v=next(s for s in data['streams'] if s['codec_type']=='video')
            a=next(s for s in data['streams'] if s['codec_type']=='audio')
            self.assertEqual((v['codec_name'],v['pix_fmt'],a['codec_name']),('h264','yuv420p','aac'))
            self.assertEqual(int(v['nb_frames']),100,'Master deve conter o video completo, incluindo sobras dos cortes')
            self.assertLess(abs(float(v['start_time'])-float(a['start_time'])),.08)
            self.assertLess(abs(float(v['duration'])-float(a['duration'])),.12)
            self.assertEqual(len(xml.findall('.//spine/asset-clip')),2)
            self.assertEqual(result['mediaPath'],str(master))
            self.assertEqual(result['path'],str(target))
            self.assertEqual(hashlib.sha256(source.read_bytes()).hexdigest(),before)
            self.assertEqual(updates[-1],(100,100))
            self.assertEqual(sorted(p.name for p in root.iterdir()),sorted([source.name,target.name,master.name]))
            for dest in [target,source,root/'invalido.xml']:
                with self.assertRaises(ValueError):app.export_resolve(str(source),media,ranges,str(dest),'Aula',True,'ffmpeg')

    def test_original_reference_fast_export_and_no_overwrite_or_partial_xml_on_failure(self):
        app=self.exporter()
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);source,media=self.make_source(root)
            target=root/'cortes.fcpxml';ranges=[{'in':1,'out':20}]
            result=app.export_resolve(str(source),media,ranges,str(target),'Aula',False,'ffmpeg')
            self.assertEqual(result['mediaPath'],str(source))
            self.assertEqual(ET.parse(target).find('./resources/asset/media-rep').get('src'),source.as_uri())
            self.assertEqual(len(list(root.iterdir())),2)
            target.unlink()
            with patch('resolve_export._verify_video',side_effect=RuntimeError('midia invalida')):
                with self.assertRaisesRegex(RuntimeError,'midia invalida'):
                    app.export_resolve(str(source),media,ranges,str(target),'Aula',True,'ffmpeg')
            self.assertEqual(list(root.iterdir()),[source])
            # Recusar uma midia companheira existente antes de comecar o FFmpeg.
            master=root/'cortes.media.mp4';master.write_bytes(b'preservar')
            with self.assertRaisesRegex(ValueError,'existe'):
                app.export_resolve(str(source),media,ranges,str(target),'Aula',True,'ffmpeg')
            self.assertEqual(master.read_bytes(),b'preservar');self.assertFalse(target.exists())

    def test_unc_file_uri_and_validation(self):
        app=self.exporter()
        self.assertEqual(app.media_uri('\\\\Servidor\\Vídeos\\ação.mp4'),'file://Servidor/V%C3%ADdeos/a%C3%A7%C3%A3o.mp4')
        with self.assertRaises(ValueError):
            app.build_fcpxml('C:\\video.mp4',dict(duration=4,fpsNum=25,fpsDen=1),[], 'Aula')

    def test_xml_publication_failure_removes_only_the_master_created_by_this_export(self):
        app=self.exporter()
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);source,media=self.make_source(root)
            target=root/'cortes.fcpxml'
            with patch('resolve_export.Path.rename' if os.name=='nt' else 'resolve_export.os.link',side_effect=OSError('publicacao recusada')):
                with self.assertRaisesRegex(OSError,'publicacao recusada'):
                    app.export_resolve(str(source),media,[{'in':0,'out':25}],str(target),'Aula',True,'ffmpeg')
            self.assertEqual(list(root.iterdir()),[source])

if __name__=='__main__':unittest.main()
