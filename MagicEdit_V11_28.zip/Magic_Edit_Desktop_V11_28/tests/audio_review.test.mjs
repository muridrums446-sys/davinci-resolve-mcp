import test from 'node:test';
import assert from 'node:assert/strict';
import {cleanAudioSuggestions,applyAudioSuggestions,mergeAudioReports} from '../src/audio_review.js';
import {toggleTimelineCut,timelineRangeRemoved} from '../src/selection.js';
import {cutRanges} from '../src/engine.js';
const words=[{word:'primeira',start:1,end:1.4},{word:'segunda',start:3,end:3.4},{word:'final',start:4,end:4.4}];
const suggestion=(changes={})=>({start:1,end:1.4,origin:'gemini-audio',requiresReview:false,confidence:'alta',reason:'Primeira tentativa refeita',keepStart:3,keepEnd:3.4,...changes});
test('aplica audio sem restaurar cortes existentes e pode restaurar pelo mecanismo da timeline',()=>{
 const first=applyAudioSuggestions(words,new Set([2]),[{start:.1,end:.3}],[suggestion()],6);
 assert.equal(first.applied,1);assert.ok(first.deleted.has(2));assert.ok(first.extraCuts.some(c=>c.start===.1));
 assert.ok(timelineRangeRemoved(cutRanges(words,first.deleted,first.extraCuts,6),suggestion()));
 const again=applyAudioSuggestions(words,first.deleted,first.extraCuts,[suggestion()],6);
 assert.equal(again.applied,0);assert.deepEqual(again.extraCuts,first.extraCuts);
 const restored=toggleTimelineCut(words,first.deleted,first.extraCuts,suggestion(),6);
 assert.equal(restored.action,'restored');assert.ok(restored.deleted.has(2));
 assert.ok(!timelineRangeRemoved(cutRanges(words,restored.deleted,restored.extraCuts,6),suggestion()));
});
test('sugestao sem texto pode ser exibida mas nao cortada automaticamente',()=>{
 const candidate=suggestion({start:.4,end:.8,requiresReview:true});
 assert.equal(cleanAudioSuggestions([candidate],6).length,1);
 assert.equal(applyAudioSuggestions(words,new Set(),[],[candidate],6).applied,0);
});
test('nao aplica corte que invade tomada mantida nem que remove toda a fala restante',()=>{
 const bad=suggestion({start:3,end:3.4,keepStart:null,keepEnd:null});
 const result=applyAudioSuggestions(words,new Set(),[],[suggestion(),bad],6);
 assert.equal(result.applied,1);assert.ok(!timelineRangeRemoved(cutRanges(words,result.deleted,result.extraCuts,6),bad));
 assert.equal(applyAudioSuggestions(words,new Set([1,2]),[],[suggestion()],6).applied,0);
});
test('relatorio de projeto ignora intervalos invalidos e propriedades desconhecidas',()=>{
 const clean=cleanAudioSuggestions([suggestion({apiKey:'secret'}),suggestion({start:-1}),suggestion({end:NaN}),suggestion({origin:'other'})],6);
 assert.equal(clean.length,1);assert.ok(!('apiKey' in clean[0]));
});
test('nao corta a primeira tentativa se a tomada escolhida para manter ja esta cortada',()=>{
 const result=applyAudioSuggestions(words,new Set([1]),[],[suggestion()],6);
 assert.equal(result.applied,0);
});

test('analise posterior preserva tomada mantida pelo relatorio anterior inclusive apos reabrir JSON',()=>{
 const first=applyAudioSuggestions(words,new Set(),[],[suggestion()],6);
 const report=JSON.parse(JSON.stringify([suggestion()]));
 const next=suggestion({start:3,end:3.4,keepStart:null,keepEnd:null,category:'offtopic'});
 const second=applyAudioSuggestions(words,first.deleted,first.extraCuts,[next],6,report);
 assert.equal(second.applied,0);
 assert.ok(!timelineRangeRemoved(cutRanges(words,second.deleted,second.extraCuts,6),next));
});

test('relatorios preservam vetos anteriores ao mesclar e salvar analises sucessivas',()=>{
 const merged=mergeAudioReports([suggestion()],[suggestion({requiresReview:true,confidence:'revisar',keepStart:null,keepEnd:null})],6);
 assert.equal(merged.length,1);assert.equal(merged[0].keepStart,3);assert.equal(merged[0].keepEnd,3.4);
 const json=JSON.parse(JSON.stringify(merged));
 const next=suggestion({start:3,end:3.4,keepStart:null,keepEnd:null});
 assert.equal(applyAudioSuggestions(words,new Set(),[],[next],6,json).applied,0);
});
