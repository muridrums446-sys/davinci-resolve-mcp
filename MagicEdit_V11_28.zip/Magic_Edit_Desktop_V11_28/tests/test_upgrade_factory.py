import json
import tempfile
from pathlib import Path

import test_upgrade_v11_19 as base


class FactoryUpgradeTest(base.Upgrade19Test):
    def fixture(self, root, app):
        source, original = super().fixture(root, app)
        target = root/'Magicedit'/'MagicEdit_Desktop_V11_Atualizacao'/'MagicEdit_Desktop_V11'
        target.parent.mkdir(parents=True)
        original.rename(target)
        (target/'package.json').write_text('{"version":"0.11.14"}')
        return source, target

    def test_factory_path_accepts_existing_installation_and_preserves_old_backups(self):
        app = self.updater()
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source, target = self.fixture(root, app)
            for folder in ('src', 'Motion', 'Remotion', '_BACKUP_MagicEdit_Desktop_V11_preV11_14_antigo'):
                sibling = target.parent/folder
                sibling.mkdir()
                (sibling/'preservar.txt').write_text('intacto')
            before = app.inventory(target)
            siblings = {p.name: app.inventory(p) for p in target.parent.iterdir() if p != target}
            backup = app.install(source, target, verify=lambda *_: None)
            self.assertEqual(app.inventory(backup), before)
            manifest = json.loads(backup.with_suffix('.manifest.json').read_text('utf-8'))
            self.assertEqual(manifest['versionBefore'], '0.11.14')
            self.assertEqual(manifest['files'], before)
            self.assertEqual(json.loads((target/'package.json').read_text())['version'], app.VERSION)
            for rel in ('projeto.json', 'original.mp4', 'groq-settings.txt'):
                self.assertEqual(app.digest(target/rel), before[rel]['sha256'])
            for name, inventory in siblings.items():
                self.assertEqual(app.inventory(target.parent/name), inventory)

    def test_does_not_update_an_installation_inside_old_backup_or_protected_folder(self):
        app = self.updater()
        for ancestor in ('_BACKUP_instalacao_antiga', 'Motion', 'Remotion', 'src'):
            with self.subTest(ancestor=ancestor), tempfile.TemporaryDirectory() as tmp:
                source, target = self.fixture(Path(tmp), app)
                forbidden = target.parent/ancestor/target.name
                forbidden.parent.mkdir()
                target.rename(forbidden)
                before = app.inventory(forbidden)
                with self.assertRaises(RuntimeError):
                    app.install(source, forbidden, verify=lambda *_: None)
                self.assertEqual(app.inventory(forbidden), before)
