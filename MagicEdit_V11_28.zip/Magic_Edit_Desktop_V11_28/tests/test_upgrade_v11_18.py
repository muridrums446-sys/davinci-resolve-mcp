import hashlib
import importlib.util
import json
import shutil
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]

class Upgrade18Test(unittest.TestCase):
    def updater(self):
        path=ROOT/'update_desktop.py'
        self.assertTrue(path.is_file(),'Atualizador seguro V11.18 ausente')
        spec=importlib.util.spec_from_file_location('update18',path)
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        return module

    def fixture(self,root,app):
        source=root/'pacote';target=root/'Desktop_V10'
        for rel in app.FILES:
            dest=source/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/rel,dest)
        (target/'src').mkdir(parents=True)
        for rel in ['magicedit_server.py','src/main.js','INICIAR_MAGIC_EDIT.bat']:(target/rel).write_text('anterior')
        (target/'package.json').write_text('{"version":"0.11.17"}')
        (target/'projeto.json').write_bytes(b'{"schema":1}')
        (target/'original.mp4').write_bytes(b'original intocado')
        (target/'groq-settings.txt').write_bytes(b'configuracao local preservada')
        return source,target

    def test_complete_backup_verified_before_upgrade_preserves_user_files_and_siblings(self):
        app=self.updater()
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);source,target=self.fixture(root,app)
            (root/'Motion').mkdir();(root/'Motion'/'protegido').write_text('intacto')
            before={p.relative_to(target).as_posix():p.read_bytes() for p in target.rglob('*') if p.is_file()}
            backup=app.install(source,target,verify=lambda *_:None)
            self.assertEqual(json.loads((target/'package.json').read_text())['version'],app.VERSION)
            for rel,data in before.items():self.assertEqual((backup/rel).read_bytes(),data,rel)
            for rel in ['projeto.json','original.mp4','groq-settings.txt']:self.assertEqual((target/rel).read_bytes(),before[rel])
            self.assertEqual((root/'Motion'/'protegido').read_text(),'intacto')
            self.assertTrue(backup.with_suffix('.manifest.json').exists())

    def test_failed_copy_restores_all_modified_runtime_files(self):
        app=self.updater()
        with tempfile.TemporaryDirectory() as tmp:
            source,target=self.fixture(Path(tmp),app)
            before={p.relative_to(target).as_posix():p.read_bytes() for p in target.rglob('*') if p.is_file()}
            calls=0
            def fail(src,dst):
                nonlocal calls
                calls+=1
                if calls==4:raise OSError('falha simulada')
                return shutil.copy2(src,dst)
            with self.assertRaisesRegex(OSError,'simulada'):app.install(source,target,verify=lambda *_:None,copy=fail)
            after={p.relative_to(target).as_posix():p.read_bytes() for p in target.rglob('*') if p.is_file()}
            self.assertEqual(after,before)

    def test_corrupt_backup_prevents_any_installation_write(self):
        app=self.updater()
        with tempfile.TemporaryDirectory() as tmp:
            source,target=self.fixture(Path(tmp),app)
            original=app.shutil.copytree
            def corrupt(src,dst,*args,**kwargs):
                result=original(src,dst,*args,**kwargs)
                if (Path(dst)/'original.mp4').exists():(Path(dst)/'original.mp4').write_bytes(b'corrompido')
                return result
            with patch.object(app.shutil,'copytree',side_effect=corrupt):
                with self.assertRaisesRegex(RuntimeError,'backup'):app.install(source,target,verify=lambda *_:None)
            self.assertEqual((target/'magicedit_server.py').read_text(),'anterior')

    def test_rejects_source_inside_destination_and_unknown_version(self):
        app=self.updater()
        with tempfile.TemporaryDirectory() as tmp:
            source,target=self.fixture(Path(tmp),app)
            with self.assertRaises(RuntimeError):app.install(target,target,verify=lambda *_:None)
            (target/'package.json').write_text('{"version":"99.0.0"}')
            with self.assertRaisesRegex(RuntimeError,'Versao'):app.install(source,target,verify=lambda *_:None)

    def test_protected_motion_destination_is_rejected_even_if_it_contains_an_app(self):
        app=self.updater()
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);source,target=self.fixture(root,app)
            forbidden=root/'Motion';target.rename(forbidden)
            with self.assertRaisesRegex(RuntimeError,'Desktop_V10'):app.install(source,forbidden,verify=lambda *_:None)
            from INSTALAR_V11 import install as legacy_install, FILES as legacy_files
            for rel in legacy_files:
                dest=source/rel;dest.parent.mkdir(parents=True,exist_ok=True)
                if not dest.exists():shutil.copy2(ROOT/rel,dest)
            with self.assertRaisesRegex(RuntimeError,'Desktop_V10'):legacy_install(source,forbidden,verify=lambda *_:None)

    def test_postflight_failure_rolls_back_before_returning_error(self):
        app=self.updater()
        with tempfile.TemporaryDirectory() as tmp:
            source,target=self.fixture(Path(tmp),app)
            before=app.inventory(target)
            def verify(folder,_):
                if folder==target:raise RuntimeError('pos-instalacao falhou')
            with self.assertRaisesRegex(RuntimeError,'pos-instalacao'):app.install(source,target,verify=verify)
            self.assertEqual(app.inventory(target),before)
