import test from 'node:test';
import assert from 'node:assert/strict';
import {candidateWordTypes} from '../src/autoedit.js';

test('frase repetida e marcada para revisao sem apagar as palavras',()=>{
  const marks=candidateWordTypes([{type:'repeat',from:1,to:3,confidence:'média'}],6);
  assert.deepEqual([...marks.entries()],[[1,'repeat'],[2,'repeat'],[3,'repeat']]);
});

test('pausa sem palavras nao marca fala como erro',()=>{
  assert.equal(candidateWordTypes([{type:'silence',start:1,end:2}],4).size,0);
});
