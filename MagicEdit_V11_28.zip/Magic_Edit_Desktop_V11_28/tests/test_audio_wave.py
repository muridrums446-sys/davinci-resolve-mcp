import unittest
from array import array
from audio_wave import peaks_from_pcm
class WaveTest(unittest.TestCase):
    def test_wave_peaks(self):
        pcm=array('h',[0]*20+[1000]*20+[-32768]*20)
        out=peaks_from_pcm(pcm.tobytes())
        self.assertEqual(len(out),3)
        self.assertEqual(out[0],0)
        self.assertGreater(out[2],240)
    def test_empty(self):
        self.assertEqual(peaks_from_pcm(b''),[])
if __name__=='__main__':unittest.main()
