import test from 'node:test';
import assert from 'node:assert/strict';
test('arrasto padrao seleciona X-Y; Delete risca texto e tempo; Ctrl+Z restaura',async()=>{
 const nodes=new Map(),listeners={},requests=[];
 const ctx={setTransform(){},clearRect(){},fillRect(){},beginPath(){},moveTo(){},lineTo(){},stroke(){},fill(){},closePath(){},fillText(){},drawImage(){}};
 const wordList=[{word:'primeira',start:1,end:2},{word:'segunda',start:3,end:4},{word:'terceira',start:6,end:7}];
 function node(id){if(!nodes.has(id))nodes.set(id,{id,innerHTML:'',textContent:'',value:'',checked:id==='autoSilenceEnabled',hidden:false,disabled:false,scrollTop:0,style:{},dataset:{},classList:{add(){},remove(){},toggle(){}},listeners:{},contains(){return true;},setAttribute(k,v){this[k]=v;},addEventListener(k,v){this.listeners[k]=v;},querySelector(){return null;},querySelectorAll(){return [];},getBoundingClientRect(){return {left:0,top:0,width:800,height:80};},getContext(){return ctx;},setPointerCapture(){},releasePointerCapture(){},pause(){this.paused=true;},play(){this.paused=false;return Promise.resolve();},load(){},focus(){},currentTime:0,paused:true});return nodes.get(id);}
 globalThis.document={body:{classList:{add(){},remove(){}}},getElementById:node,querySelectorAll(){return [];}};
 globalThis.window={devicePixelRatio:1,addEventListener(k,v){listeners[k]=v;},getSelection(){return {isCollapsed:true,removeAllRanges(){}};}};
 globalThis.localStorage={getItem(){return null;},setItem(){}};globalThis.Image=class{};globalThis.requestAnimationFrame=()=>0;
 globalThis.fetch=async(url,opts={})=>{const route=url.split('/').pop();if(opts.body)requests.push({route,data:JSON.parse(opts.body)});return {ok:true,json:async()=>({recent:{items:[]},autosave:{project:null},choose:{path:'p.json',text:JSON.stringify({schema:1,path:'video.mp4',media:{},words:wordList,deletedIndices:[],extraCuts:[]})},set_video:{path:'video.mp4',media:{name:'video.mp4',duration:10,fpsNum:25,fpsDen:1}},waveform:{state:'done',peaks:[],rate:20},vad:{state:'done',speech:[]},save:{path:'salvo.json'}}[route]||{})};};
 await import('../src/main.js');await node('homeOpen').onclick();
 for(const surface of ['timeline','timelineRuler','filmstrip']){
  const handlers=node(surface).listeners;
  handlers.pointerdown({button:0,pointerId:1,clientX:80});
  handlers.pointermove({button:0,pointerId:1,clientX:400});
  handlers.pointerup({button:0,pointerId:1,clientX:400});
  assert.equal(node('deleteRange').disabled,false,`${surface}: seleciona sem ativar modo`);
  assert.equal(node('rangeSelection').hidden,false);
  listeners.keydown({key:'Delete',target:{tagName:'DIV'},ctrlKey:false,metaKey:false,preventDefault(){}});
  assert.match(node('transcript').innerHTML,/word deleted[^>]*data-idx="0"/);
  assert.match(node('transcript').innerHTML,/word deleted[^>]*data-idx="1"/);
  assert.doesNotMatch(node('transcript').innerHTML,/word deleted[^>]*data-idx="2"/);
  await node('saveProject').onclick();assert.deepEqual(JSON.parse(requests.findLast(x=>x.route==='save').data.contents).extraCuts,[{start:1,end:5}]);
  node('undo').onclick();assert.doesNotMatch(node('transcript').innerHTML,/word deleted/);
 }
 // O botao direito corta a selecao, mesmo clicando fora dela, em todas as faixas.
 for(const surface of ['timeline','timelineRuler','filmstrip']){
  const h=node(surface).listeners;
  h.pointerdown({button:0,pointerId:10,clientX:80});h.pointermove({pointerId:10,clientX:400});h.pointerup({pointerId:10,clientX:400});
  assert.equal(typeof h.contextmenu,'function',`${surface}: clique direito disponivel`);
  let prevented=false;h.contextmenu({clientX:600,preventDefault(){prevented=true;}});
  assert.ok(prevented,'nao abrir menu nativo quando ha acao');
  assert.match(node('transcript').innerHTML,/word deleted[^>]*data-idx="0"/);
  assert.match(node('transcript').innerHTML,/word deleted[^>]*data-idx="1"/);
  assert.equal(node('rangeSelection').hidden,false,'selecao permanece para alternar com o mesmo clique');
  assert.match(node('deleteRange').textContent,/Restaurar/);
  await node('saveProject').onclick();assert.deepEqual(JSON.parse(requests.findLast(x=>x.route==='save').data.contents).extraCuts,[{start:1,end:5}]);
  // Sem selecao, direito no corte restaura. Direito no vazio nao corta nada.
  h.contextmenu({clientX:240,preventDefault(){}});
  assert.doesNotMatch(node('transcript').innerHTML,/word deleted/);
  node('clearRange').onclick();h.contextmenu({clientX:600,preventDefault(){}});
  await node('saveProject').onclick();assert.deepEqual(JSON.parse(requests.findLast(x=>x.route==='save').data.contents).extraCuts,[]);
 }
 // Uma selecao nova tem prioridade sobre restaurar um corte antigo sob o mouse.
 const hp=node('timeline').listeners;
 for(const [first,last] of [[80,400],[480,640]]){
  hp.pointerdown({button:0,pointerId:11,clientX:first});hp.pointermove({pointerId:11,clientX:last});hp.pointerup({pointerId:11,clientX:last});
  hp.contextmenu({clientX:240,preventDefault(){}});
 }
 await node('saveProject').onclick();assert.deepEqual(JSON.parse(requests.findLast(x=>x.route==='save').data.contents).extraCuts,[{start:1,end:5},{start:6,end:8}]);
 node('undo').onclick();node('undo').onclick();
 // Espaco deve controlar o video apos clicar em botoes de edicao.
 node('player').currentTime=3;node('player').paused=true;
 const key=(target,repeat=false)=>({key:' ',code:'Space',target,repeat,preventDefault(){this.prevented=true;}});
 const button={tagName:'BUTTON',closest(){return this;}};
 let event=key(button);listeners.keydown(event);
 assert.equal(node('player').paused,false,'Espaco com foco no botao deve iniciar video');assert.ok(event.prevented);
 event=key(button,true);listeners.keydown(event);assert.equal(node('player').paused,false,'segurar Espaco nao alterna em repeticao');assert.ok(event.prevented);
 listeners.keydown(key(button));assert.equal(node('player').paused,true);
 listeners.keydown(key({tagName:'TEXTAREA'}));assert.equal(node('player').paused,true,'digitacao preservada');
 listeners.keydown(key({tagName:'INPUT',type:'range'}));assert.equal(node('player').paused,false,'Espaco apos rolar timeline tambem reproduz');
 listeners.keydown(key(button));assert.equal(node('player').paused,true);
 listeners.keydown(key({tagName:'INPUT',type:'checkbox'}));assert.equal(node('player').paused,true,'checkbox preserva acao nativa');
 // Pausar durante o salto deve cancelar a retomada pendente e restaurar o mute.
 node('player').currentTime=3;node('player').paused=false;
 const h0=node('timeline').listeners;
 h0.pointerdown({button:0,pointerId:20,clientX:160});h0.pointermove({pointerId:20,clientX:320});h0.pointerup({pointerId:20,clientX:320});
 h0.contextmenu({clientX:160,preventDefault(){}});
 node('player').currentTime=3;
 listeners.keydown(key({tagName:'DIV'}));assert.equal(node('player').muted,true,'busca silencia temporariamente');
 listeners.keydown(key({tagName:'DIV'}));
 node('player').listeners.seeked();
 assert.equal(node('player').paused,true,'Espaco durante busca deve pausar e impedir retomada tardia');
 assert.notEqual(node('player').muted,true,'mute restaurado apos cancelar busca');
 node('undo').onclick();
 const h=node('timeline').listeners;
 h.pointerdown({button:0,pointerId:2,clientX:400});h.pointermove({pointerId:2,clientX:80});h.pointerup({pointerId:2,clientX:80});
 assert.match(node('rangeStatus').textContent,/00:00:01:00 a 00:00:05:00/,'arrasto inverso normaliza limites');
 node('clearRange').onclick();h.pointerdown({button:0,pointerId:3,clientX:240});h.pointerup({pointerId:3,clientX:240});
 assert.equal(node('deleteRange').disabled,true,'clique simples nao seleciona nem corta');assert.equal(node('player').currentTime,3);
 h.pointerdown({button:0,pointerId:4,clientX:80});h.pointermove({pointerId:4,clientX:400});h.pointercancel({pointerId:4});
 assert.equal(node('deleteRange').disabled,true,'cancelar arrasto nao deixa selecao pendente');
});
