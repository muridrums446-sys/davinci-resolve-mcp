"""Catch broken launchers that reference a BAT absent from the shipped package.
This validates the distribution dependency graph; it is not Windows execution.
"""
import importlib.util,re,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
class DistributionLaunchersTest(unittest.TestCase):
 def test_every_relative_batch_call_has_a_shipped_target(self):
  spec=importlib.util.spec_from_file_location('updater_launchers',ROOT/'update_desktop.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
  for rel in module.FILES:
   if not rel.lower().endswith('.bat') or '/' in rel:continue
   text=(ROOT/rel).read_text('utf-8-sig')
   for target in re.findall(r'%~dp0([A-Za-z0-9_]+\.bat)',text,re.IGNORECASE):
    with self.subTest(launcher=rel,target=target):
     self.assertIn(target,module.FILES,'launcher calls a file absent from the distribution')
     self.assertTrue((ROOT/target).is_file())
if __name__=='__main__':unittest.main()
