@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Magic Edit - Atualizar fluxo V11.17
set "PY=py -3"
where py >nul 2>nul
if errorlevel 1 set "PY=python"
%PY% "%~dp0ATUALIZAR_V11_17.py"
set "RESULT=%ERRORLEVEL%"
echo.
if not "%RESULT%"=="0" echo Confira o erro acima. Se a copia comecou, o backup foi preservado.
pause
