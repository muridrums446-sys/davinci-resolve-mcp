"""Atualiza apenas o fluxo da V11, com backup integral e reversão em caso de falha."""
from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
from datetime import datetime
from pathlib import Path

FILES = (
    'src/main.js', 'src/style.css', 'src/preview_v11.js',
    'src/selection.js', 'src/autoedit.js', 'src/editor_v09.js',
    'src/engine.js', 'src/word_hit.js', 'index.html', 'package.json',
    'INICIAR_MAGIC_EDIT.bat', 'magicedit_server.py', 'review_takes.py', 'mp4_export.py',
    'audio_wave.py', 'vad_local.py', 'silero_vad.onnx', 'SILERO_LICENSE.txt',
)


def target_folder(here: Path) -> Path:
    if (here / 'magicedit_server.py').is_file():
        return here
    print('Selecione a pasta do Magic Edit que contem INICIAR_MAGIC_EDIT.bat.', flush=True)
    try:
        from tkinter import Tk, filedialog
        root = Tk()
        root.withdraw()
        root.attributes('-topmost', True)
        try:
            selected = filedialog.askdirectory(
                parent=root,
                title='Selecione a pasta que contem INICIAR_MAGIC_EDIT.bat',
                initialdir=str(here.parent),
                mustexist=True,
            )
        finally:
            root.destroy()
    except (ImportError, RuntimeError, OSError) as exc:
        raise RuntimeError('Nao foi possivel abrir o seletor de pastas. Execute o atualizador com '
                           'python ATUALIZAR_V11_17.py --target "CAMINHO_DA_PASTA_DO_MAGIC_EDIT".') from exc
    if not selected:
        raise RuntimeError('Nenhuma pasta selecionada. Nada foi alterado.')
    return Path(selected)


def verify(target: Path) -> None:
    subprocess.run([sys.executable, '-m', 'py_compile', str(target / 'magicedit_server.py')], check=True)
    subprocess.run([sys.executable, '-m', 'py_compile', str(target / 'review_takes.py')], check=True)
    subprocess.run([sys.executable, '-m', 'py_compile', str(target / 'mp4_export.py')], check=True)
    node = shutil.which('node')
    if node:
        subprocess.run([node, '--check', 'src/main.js'], cwd=target, check=True)


def install(source: Path, target: Path) -> Path:
    source, target = source.resolve(), target.resolve()
    if not (target / 'magicedit_server.py').is_file() or not (target / 'src/main.js').is_file():
        raise RuntimeError(f'Instalacao do Magic Edit nao encontrada em {target}. Nada foi alterado.')
    try:
        current = json.loads((target / 'package.json').read_text(encoding='utf-8'))['version']
    except (OSError, ValueError, KeyError, TypeError) as exc:
        raise RuntimeError('Versao da instalacao nao encontrada no package.json. Nada foi alterado.') from exc
    if current not in {f'0.11.{minor}' for minor in range(2, 18)}:
        raise RuntimeError(f'Versao {current} nao suportada: exige V11.2 a V11.17. Nada foi alterado.')
    missing = [rel for rel in FILES if not (source / rel).is_file()]
    if missing:
        raise RuntimeError(f'Atualizacao incompleta ({missing}). Nada foi alterado.')
    required = sum(p.stat().st_size for p in target.rglob('*') if p.is_file())
    required += sum((source / rel).stat().st_size for rel in FILES) + 20_000_000
    if shutil.disk_usage(target.parent).free < required:
        raise RuntimeError('Espaco insuficiente para backup integral. Nada foi alterado.')
    backup = target.parent / f'_BACKUP_{target.name}_preV11_17_{datetime.now():%Y%m%d_%H%M%S_%f}'
    print('Criando backup integral em:', backup, flush=True)
    shutil.copytree(target, backup, symlinks=True)
    installed = []
    try:
        for rel in FILES:
            dest = target / rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            pending = dest.with_name(dest.name + '.v1117-pending')
            try:
                shutil.copy2(source / rel, pending)
                os.replace(pending, dest)
            finally:
                pending.unlink(missing_ok=True)
            installed.append(rel)
        verify(target)
    except Exception:
        for rel in reversed(installed):
            dest = target / rel
            if (backup / rel).is_file():
                shutil.copy2(backup / rel, dest)
            else:
                dest.unlink(missing_ok=True)
        raise
    return backup


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--target', type=Path)
    args = parser.parse_args()
    here = Path(__file__).resolve().parent
    try:
        backup = install(here / 'arquivos', args.target or target_folder(here))
        print('Magic Edit V11.17 atualizado. Backup:', backup)
        print('Abra INICIAR_MAGIC_EDIT.bat na pasta do programa.')
    except Exception as exc:
        print('Falha ao atualizar:', exc, file=sys.stderr)
        sys.exit(1)
