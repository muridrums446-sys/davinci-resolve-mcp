// Operacoes puras para selecao de palavras e restauracao de trechos.
// Usadas tanto pelo clique direito quanto pelos botoes de acessibilidade.
export function normalizedSelection(a, b, length) {
  if (!Number.isInteger(a)||!Number.isInteger(b)||!Number.isInteger(length)||length<=0) return null;
  return {start:Math.max(0,Math.min(length-1,Math.min(a,b))), end:Math.max(0,Math.min(length-1,Math.max(a,b)))};
}
export function chooseRange(deleted, selection, index, length) {
  if (!Number.isInteger(index)||index<0||index>=length) return null;
  // Um segundo clique direito dentro da selecao restaura tudo de uma vez.
  if(selection && index>=selection.start && index<=selection.end) return {...selection};
  if (deleted.has(index)) {
    // Sem selecao: palavra em um bloco removido reverte o bloco inteiro.
    let start=index, end=index;
    while(start>0&&deleted.has(start-1))start--;
    while(end<length-1&&deleted.has(end+1))end++;
    return {start,end};
  }
  return {start:index,end:index};
}
export function toggleRange(deleted, range) {
  const next=new Set(deleted);
  if (!range || range.start>range.end) return {deleted:next, action:'noop'};
  let allDeleted=true;
  for(let i=range.start;i<=range.end;i++)if(!next.has(i)){allDeleted=false;break;}
  for(let i=range.start;i<=range.end;i++) {
    if(allDeleted)next.delete(i);else next.add(i);
  }
  return {deleted:next,action:allDeleted?'restored':'deleted'};
}

export function cutWordIndices(words,cuts){
  const covered=new Set(),byCut=new Map();
  for(let i=0;i<cuts.length;i++){
    const cut=cuts[i];if(!cut||!Number.isFinite(cut.start)||!Number.isFinite(cut.end)||cut.end<=cut.start)continue;
    const indices=[];
    for(let j=0;j<words.length;j++){
      const word=words[j],length=word.end-word.start;
      if(!Number.isFinite(length)||length<=0)continue;
      const overlap=Math.min(cut.end,word.end)-Math.max(cut.start,word.start);
      if(overlap>Math.min(.03,length*.1)){covered.add(j);indices.push(j);}
    }
    byCut.set(i,indices);
  }
  return {covered,byCut};
}

export function toggleTranscriptCut(words,deleted,extraCuts,range){
  if(!range||range.start>range.end)return {deleted:new Set(deleted),extraCuts:[...extraCuts],action:'noop'};
  const {covered,byCut}=cutWordIndices(words,extraCuts);
  const allRemoved=Array.from({length:range.end-range.start+1},(_,i)=>range.start+i)
    .every(i=>deleted.has(i)||covered.has(i));
  const next=new Set(deleted);
  if(!allRemoved){for(let i=range.start;i<=range.end;i++)next.add(i);return {deleted:next,extraCuts:[...extraCuts],action:'deleted'};}
  for(let i=range.start;i<=range.end;i++)next.delete(i);
  const remaining=extraCuts.filter((_,i)=>!(byCut.get(i)||[]).some(j=>j>=range.start&&j<=range.end));
  return {deleted:next,extraCuts:remaining,action:'restored'};
}
