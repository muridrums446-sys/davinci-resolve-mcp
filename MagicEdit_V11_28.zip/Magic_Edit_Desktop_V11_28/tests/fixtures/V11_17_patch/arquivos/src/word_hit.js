// Browser text selection stays native; this only resolves clicks that land on a space.
export function wordFromPoint(event, transcript, doc=document) {
  if (!transcript.contains(event.target)) return null;
  const direct=event.target?.closest?.('.word[data-idx]');
  if (direct) return direct;
  const textNode=doc.caretRangeFromPoint?.(event.clientX,event.clientY)?.startContainer
    || doc.caretPositionFromPoint?.(event.clientX,event.clientY)?.offsetNode;
  const fromCaret=textNode?.parentElement?.closest?.('.word[data-idx]');
  if (fromCaret && transcript.contains(fromCaret)) return fromCaret;
  return null;
}
