// Sugestoes conservadoras. Apenas repeticoes literais com confianca alta sao preeditadas.
import {suggestSilences,mergeIntervals} from './engine.js';
const normalize = word => String(word||'').toLocaleLowerCase('pt-BR').replace(/[^\p{L}\p{N}]/gu,'');
const FILLERS = new Set(['ahn','ah','hã','hãhã','hum','humm','hmmm','éé','ééé','ehh','eh','ãh','uhm','umm','aham']);
const STOP = new Set(['e','de','da','do','na','no','um','uma','o','a','os','as','que','eu','você','pra','para','é','se','com']);
const ranges=(a,b,words,type,reason,confidence='média')=>({type,start:words[a].start,end:words[b].end,from:a,to:b,reason,confidence});
const RESTARTS=[['pera','aí','errei'],['deixa','eu','falar','novamente'],['começa','de','novo'],['vou','falar','de','novo'],['errei'],['vamos','de','novo']];
const EMPHASIS=new Set(['repito','exemplo','novamente','ênfase','importante']);
export function candidateWordTypes(suggestions, wordCount) {
  const out=new Map();
  for(const item of suggestions){
    if(!['repeat','restart','filler'].includes(item.type)||!Number.isInteger(item.from)||!Number.isInteger(item.to))continue;
    for(let i=Math.max(0,item.from);i<=Math.min(wordCount-1,item.to);i++){
      if(!out.has(i)||item.type==='repeat')out.set(i,item.type);
    }
  }
  return out;
}
export function analyzeTranscript(words, duration, options={}) {
  if(!Array.isArray(words)||!words.length)return [];
  const safeWords=words.filter(w=>Number.isFinite(w.start)&&Number.isFinite(w.end)&&w.end>=w.start);
  if(safeWords.length!==words.length)return [];
  const normalized=words.map(w=>normalize(w.word));
  const suggestions=[];
  // Detectar gaps textuais; nao e VAD acustico: revisar antes de aplicar.
  for(const cut of suggestSilences(words,duration,options.minSilence??0.8,0.14))
    suggestions.push({...cut,type:'silence',reason:'Intervalo sem palavras na transcrição; confirmar pelo áudio'});
  for(let i=0;i<words.length;i++) {
    const t=normalized[i], prev=normalized[i-1], next=normalized[i+1];
    if(FILLERS.has(t)) {
      // "ah" pode ter valor semantico; revisar pelo contexto.
      suggestions.push(ranges(i,i,words,'filler',`Possível muleta de fala: “${words[i].word}”`));
    } else if(t==='é' && (prev==='é'||next==='é')) {
      // So sugere o "é" duplicado; NUNCA remove todo "é" isolado.
      if(prev==='é')suggestions.push(ranges(i,i,words,'filler','Possível repetição de “é”','média'));
    }
  }
  // Repeticao literal consecutiva de sequencias de duas ou mais palavras.
  // Exemplo: "hoje eu quero mostrar hoje eu quero mostrar" (remove 1a tentativa).
  const used=new Set();
  for(let i=0;i<words.length;i++) {
    if(used.has(i)||!normalized[i])continue;
    for(let size=Math.min(12,Math.floor((words.length-i)/2));size>=2;size--){
      const j=i+size;
      if(words[j].start-words[i+size-1].end>4.0)continue;
      if(words[j+size-1].end-words[i].start>22)continue;
      let equal=true,meaningful=0;
      for(let k=0;k<size;k++){
        if(!normalized[i+k]||normalized[i+k]!==normalized[j+k]){equal=false;break;}
        if(!STOP.has(normalized[i+k]))meaningful++;
      }
      if(!equal||meaningful<1)continue;
      // Eliminar somente tentativa anterior e manter segunda; revisar.
      if(normalized.slice(Math.max(0,i-4),i).some(w=>EMPHASIS.has(w)))continue;
      const gap=words[j].start-words[j-1].end;
      const confidence=gap<=1.4&&meaningful>=2?'alta':'média';
      suggestions.push(ranges(i,j-1,words,'repeat','Frase repetida literalmente; manter segunda versão',confidence));
      for(let k=i;k<j+size;k++)used.add(k);
      i=j-1;break;
    }
  }
  // Uma palavra repetida e ambigua (enfase, saudacao, erro): apenas revisar.
  for(let i=0;i+1<words.length;i++){
    if(used.has(i)||used.has(i+1)||!normalized[i]||STOP.has(normalized[i])||normalized[i]!==normalized[i+1])continue;
    if(words[i+1].start-words[i].end>1.4||normalized.slice(Math.max(0,i-4),i).some(w=>EMPHASIS.has(w)))continue;
    if(i+2<words.length&&!used.has(i+2)&&normalized[i]===normalized[i+2]&&words[i+2].start-words[i+1].end<=1.4){
      suggestions.push(ranges(i,i+1,words,'repeat','Palavra repetida três vezes; manter a última','alta'));
      used.add(i);used.add(i+1);used.add(i+2);i+=2;continue;
    }
    suggestions.push(ranges(i,i,words,'repeat','Palavra repetida; ouça para distinguir ênfase de erro','baixa'));
    used.add(i);used.add(i+1);i++;
  }
  // Uma tentativa terminada em reticencias e retomada com as mesmas palavras
  // pode ter palavras extras entre as duas versoes. Marcar apenas a tentativa
  // interrompida; a regravacao continua inteira e a pessoa pode restaurar.
  for(let end=4;end<words.length-4;end++){
    if(!/(?:\.\.\.|…)$/.test(words[end].word)||used.has(end))continue;
    let best=null;
    for(let i=Math.max(0,end-15);i<=end-4;i++){
      if(used.has(i)||!normalized[i]||
          normalized.slice(Math.max(0,i-4),i).some(w=>w==='repito'||w==='ênfase'))continue;
      for(let j=end+1;j<Math.min(words.length-4,end+15);j++){
        if(words[j].start-words[end].end>10||normalized[i]!==normalized[j]||used.has(j))continue;
        let matched=0,meaningful=0;
        while(matched<Math.min(8,end-i)&&j+matched<words.length&&normalized[i+matched]===normalized[j+matched]){
          if(!STOP.has(normalized[i+matched]))meaningful++;
          matched++;
        }
        if(matched>=4&&meaningful>=2&&(!best||matched>best.matched))best={i,j,matched};
      }
    }
    if(!best)continue;
    suggestions.push(ranges(best.i,end,words,'restart','Tentativa interrompida e recomeçada; confira antes de manter o corte','média'));
    for(let k=best.i;k<=end;k++)used.add(k);
  }
  // Correcoes em que a frase recomeça igual mas troca uma informacao logo
  // depois ("voce, tipo, daqui 50 anos, voce, tipo, daqui 10 anos").
  // A fala pode ser intencional: listar para revisao, nunca pre-cortar.
  for(let i=0;i+8<words.length;i++){
    if(used.has(i)||!normalized[i]||normalized.slice(Math.max(0,i-4),i).some(w=>EMPHASIS.has(w)))continue;
    for(let j=i+4;j<=Math.min(i+14,words.length-4);j++){
      if(words[j].start-words[i].start>12)break;
      if(used.has(j)||!/[,.!?…]$/.test(words[j-1].word)||words[j].start-words[j-1].end<.25)continue;
      if(normalized[i]!==normalized[j]||normalized[i+1]!==normalized[j+1]||normalized[i+2]!==normalized[j+2])continue;
      if(normalized[i+3]===normalized[j+3]||
         normalized.slice(i,j).filter(w=>w&&!STOP.has(w)).length<3||
         normalized.slice(i,i+3).filter(w=>w&&!STOP.has(w)).length<2)continue;
      const earlier=normalized.slice(i,j),later=normalized.slice(j,j+4);
      if(earlier.every(w=>STOP.has(w))||later.every(w=>STOP.has(w)))continue;
      suggestions.push({...ranges(i,j-1,words,'restart','Possível reformulação da frase; ouça antes de cortar','baixa'),requiresReview:true});
      for(let k=i;k<=j;k++)used.add(k);
      i=j-1;break;
    }
  }
  // Tentativa parcial: ate duas palavras mudadas numa frase maior, com recomeço proximo.
  for(let i=0;i<words.length;i++){
    if(used.has(i)||!normalized[i]||STOP.has(normalized[i])||normalized.slice(Math.max(0,i-4),i).some(w=>EMPHASIS.has(w)))continue;
    let found=false;
    for(let size=9;size>=5&&!found;size--){
      for(let gap=0;gap<=2&&!found;gap++){
        const j=i+size+gap;
        if(j+size>words.length||words[j].start-words[i+size-1].end>5||words[j+size-1].end-words[i].start>32)continue;
        let same=0,meaningful=0;
        for(let k=0;k<size;k++){
          if(normalized[i+k]===normalized[j+k]&&normalized[i+k])same++;
          if(!STOP.has(normalized[i+k]))meaningful++;
        }
        if(same<size-1||same===size||meaningful<3||used.has(j))continue;
        suggestions.push(ranges(i,i+size-1,words,'repeat','Possível recomeço com pequena mudança; ouça antes de cortar','baixa'));
        for(let k=i;k<j+size;k++)used.add(k);
        found=true;
      }
    }
  }
  for(let i=0;i<normalized.length;i++){
    for(const cue of RESTARTS){
      if(cue.every((token,k)=>normalized[i+k]===token)){
        suggestions.push(ranges(i,i+cue.length-1,words,'restart','Possível indicação de erro de gravação; revisar contexto','média'));
        i+=cue.length-1;break;
      }
    }
  }
  const typePriority={repeat:4,restart:3,filler:2,silence:1};
  suggestions.sort((a,b)=>a.start-b.start||(typePriority[b.type]||0)-(typePriority[a.type]||0));
  // Remover sugestoes de filler contidas nas frases repetidas.
  const repeats=suggestions.filter(s=>s.type==='repeat');
  return suggestions.filter(s=>s.type!=='filler'||!repeats.some(r=>s.start>=r.start&&s.end<=r.end));
}
export function selectionsToCuts(proposals,words){
 const extras=[];const indices=new Set();
 for(const s of proposals){
   if(s.type==='silence')extras.push({start:s.start,end:s.end});
   else if(Number.isInteger(s.from)&&Number.isInteger(s.to))for(let i=s.from;i<=s.to;i++)indices.add(i);
 }
 return {extraCuts:mergeIntervals(extras,Math.max(words.at(-1)?.end||0,...extras.map(x=>x.end),1)),deleted:indices};
}
export function automaticCuts(suggestions,words){
  return selectionsToCuts(suggestions.filter(s=>s.type==='repeat'&&s.confidence==='alta'),words);
}
export function reviewablePrecuts(suggestions,words,includeHigh=true){
  return selectionsToCuts(suggestions.filter(s=>!s.requiresReview&&['repeat','restart','filler'].includes(s.type)&&(includeHigh||s.confidence!=='alta')),words);
}
export function projectCutsOnOpen(doc,suggestions,words){
  const deleted=new Set((doc.deletedIndices||[]).filter(i=>Number.isInteger(i)&&i>=0&&i<words.length));
  if(doc.autoEditVersion!==2){
    const selected=reviewablePrecuts(suggestions,words,doc.autoEditVersion!==1);
    for(const i of selected.deleted)deleted.add(i);
  }
  return deleted;
}
