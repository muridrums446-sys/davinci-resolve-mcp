import test from 'node:test';
import assert from 'node:assert/strict';
import {automaticCuts,analyzeTranscript,projectCutsOnOpen} from '../src/autoedit.js';
import {cutRanges,keepRanges} from '../src/engine.js';
const words=text=>text.split(' ').map((word,i)=>({word,start:i*.4,end:i*.4+.32}));
test('legacy project opening never adds decisions to a saved edit',()=>{
 const w=words('hoje vamos explicar os dividendos hoje vamos explicar os dividendos');
 for(const version of [undefined,1,2,3])assert.deepEqual([...projectCutsOnOpen({autoEditVersion:version,deletedIndices:[9]},analyzeTranscript(w,5),w)],[9]);
});
test('automatic rough cut removes a complete duplicate take, preserving the later take',()=>{
 const w=words('hoje vamos explicar os dividendos hoje vamos explicar os dividendos');
 assert.deepEqual([...automaticCuts(analyzeTranscript(w,5),w).deleted],[0,1,2,3,4]);
});
test('short emphasis and explicitly didactic repetition remain in the edit',()=>{
 for(const text of ['muito muito muito importante','não não faça isso','muito muito','repito hoje vamos explicar os dividendos hoje vamos explicar os dividendos']){
  const w=words(text);assert.equal(automaticCuts(analyzeTranscript(w,10),w).deleted.size,0,text);
 }
});
test('deleted word cannot consume an overlapping preserved word',()=>{
 const w=[{word:'errei',start:1,end:1.5},{word:'continua',start:1.48,end:1.9}];
 assert.ok(cutRanges(w,new Set([0]),[],3).every(c=>c.end<=1.48));
});
test('a single preserved video frame survives export',()=>{
 assert.deepEqual(keepRanges(1,[{start:0,end:.4},{start:.44,end:1}],25),[{in:10,out:11}]);
});
