import test from 'node:test';
import assert from 'node:assert/strict';
import {analyzeTranscript,automaticCuts} from '../src/autoedit.js';
const build=text=>text.split(' ').map((word,i)=>({word,start:i*.3,end:i*.3+.24}));
const removed=words=>[...automaticCuts(analyzeTranscript(words,words.at(-1).end+.1),words).deleted];
test('exemplo do usuario preserva somente a ultima frase com quatro palavras',()=>{
 assert.deepEqual(removed(build('No vídeo de hoje, no vídeo de hoje.')),[0,1,2,3]);
});
test('exatamente tres palavras iguais contam, inclusive palavras funcionais',()=>{
 assert.deepEqual(removed(build('vamos começar agora vamos começar agora')),[0,1,2]);
 assert.deepEqual(removed(build('é o que é o que')),[0,1,2]);
});
test('uma ou duas palavras repetidas nao sao mais cortadas automaticamente',()=>{
 for(const text of ['claro claro','claro claro claro','de boa de boa','de boa de boa de boa'])assert.deepEqual(removed(build(text)),[],text);
});
test('repeticao curta dentro da tomada nao esconde a frase duplicada completa',()=>{
 assert.deepEqual(removed(build('claro claro vamos começar claro claro vamos começar')),[0,1,2,3]);
 assert.deepEqual(removed(build('claro claro vamos começar claro vamos começar')),[1,2,3]);
 assert.deepEqual(removed(build('claro claro vamos começar errei claro claro vamos começar')),[0,1,2,3,4]);
 assert.deepEqual(removed(build('claro claro vamos começar... claro claro vamos começar')),[0,1,2,3]);
});
test('retomadas distantes e frases diferentes com mesmo comeco ficam mantidas',()=>{
 const w=build('no vídeo de hoje no vídeo de hoje');for(let i=4;i<w.length;i++){w[i].start+=15;w[i].end+=15;}
 assert.deepEqual(removed(w),[]);
 assert.deepEqual(removed(build('eu quero investir em ações eu quero investir em fundos')),[]);
});
test('tres palavras retomadas apos erro ou interrupcao preservam a ultima',()=>{
 assert.deepEqual(removed(build('vamos começar agora errei vamos começar agora')),[0,1,2,3]);
 assert.deepEqual(removed(build('vamos começar agora... vamos começar agora com calma')),[0,1,2]);
});
