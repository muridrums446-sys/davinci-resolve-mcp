import unittest
from review_takes import validate_suggestions

def words(text):
    return [dict(word=t,start=i*.4,end=i*.4+.3) for i,t in enumerate(text.split())]

class AutomaticContextTest(unittest.TestCase):
    def test_duplicate_three_words_is_automatic_but_short_distant_or_common_prefix_is_reviewed(self):
        def requires(text,a,b,c,d):
            w=words(text)
            item={'from':a,'to':b,'reason':'Tomada anterior repetida na retomada','category':'duplicate','score':.99,'keepFrom':c,'keepTo':d}
            return validate_suggestions({'suggestions':[item]},w,(0,len(w),0,len(w)))[0]['requiresReview']
        self.assertFalse(requires('vamos começar agora vamos começar agora',0,2,3,5))
        self.assertTrue(requires('de boa de boa',0,1,2,3))
        self.assertTrue(requires('eu quero investir em ações eu quero investir em fundos',0,2,5,7))
        w=words('no vídeo de hoje no vídeo de hoje')
        for word in w[4:]:word['start']+=30;word['end']+=30
        item={'from':0,'to':3,'reason':'Tomada anterior repetida na retomada','category':'duplicate','score':.99,'keepFrom':4,'keepTo':7}
        self.assertTrue(validate_suggestions({'suggestions':[item]},w,(0,len(w),0,len(w)))[0]['requiresReview'])

    def test_interrupted_two_word_repeat_cannot_bypass_minimum_as_restart(self):
        w=words('de boa... de boa')
        item={'from':0,'to':1,'reason':'Primeira tentativa interrompida','category':'restart','score':.99,'keepFrom':None,'keepTo':None}
        self.assertTrue(validate_suggestions({'suggestions':[item]},w,(0,len(w),0,len(w)))[0]['requiresReview'])

    def test_pause_does_not_turn_shared_prefix_of_different_sentences_into_duplicate(self):
        w=words('no vídeo de hoje, vamos falar de ações. no vídeo de hoje, vamos falar de fundos.')
        for word in w[4:]:word['start']+=.6;word['end']+=.6
        item={'from':0,'to':3,'reason':'Comeco repetido de duas frases','category':'duplicate','score':.99,'keepFrom':8,'keepTo':11}
        self.assertTrue(validate_suggestions({'suggestions':[item]},w,(0,len(w),0,len(w)))[0]['requiresReview'])

    def test_model_duplicate_needs_a_matching_later_take_before_automatic_cut(self):
        w=words('hoje vamos explicar os dividendos hoje vamos explicar os dividendos')
        item={'from':0,'to':4,'reason':'A primeira tomada se repete na segunda','category':'duplicate','score':.99,'keepFrom':5,'keepTo':9}
        result=validate_suggestions({'suggestions':[item]},w,(0,10,0,10))
        self.assertFalse(result[0]['requiresReview'])
        self.assertEqual(result[0]['category'],'duplicate')
        item['keepFrom']=999
        self.assertTrue(validate_suggestions({'suggestions':[item]},w,(0,10,0,10))[0]['requiresReview'])

    def test_different_numbers_are_not_a_literal_duplicate(self):
        w=words('daqui a cinquenta anos teremos daqui a dez anos teremos')
        item={'from':0,'to':4,'reason':'Duas falas parecidas','category':'duplicate','score':.99,'keepFrom':5,'keepTo':9}
        self.assertTrue(validate_suggestions({'suggestions':[item]},w,(0,10,0,10))[0]['requiresReview'])

    def test_low_confidence_or_invalid_score_cannot_apply_a_context_cut(self):
        w=words('a bolsa representa empresas fecha aquela janela agora continuamos o investimento')
        for score in [.5,True,float('nan'),1.5]:
            item={'from':4,'to':7,'reason':'Conversa sobre o ambiente da gravacao','category':'offtopic','score':score,'keepFrom':None,'keepTo':None}
            self.assertTrue(validate_suggestions({'suggestions':[item]},w,(0,len(w),0,len(w)))[0]['requiresReview'])

    def test_high_confidence_context_cut_is_auditable_and_not_a_file_mutation(self):
        w=words('a bolsa representa empresas fecha aquela janela agora continuamos o investimento')
        item={'from':4,'to':7,'reason':'Conversa sobre o ambiente da gravacao','category':'offtopic','score':.99,'keepFrom':None,'keepTo':None}
        before=[dict(x) for x in w]
        result=validate_suggestions({'suggestions':[item]},w,(0,len(w),0,len(w)))
        self.assertFalse(result[0]['requiresReview'])
        self.assertEqual(w,before)
