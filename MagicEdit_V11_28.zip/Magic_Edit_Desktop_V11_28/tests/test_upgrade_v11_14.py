import importlib.util
import json
import tempfile
import unittest
from pathlib import Path

PACKAGE = Path(__file__).resolve().parents[2] / 'V11_14_patch'
if not (PACKAGE / 'ATUALIZAR_V11_14.py').is_file():
    raise unittest.SkipTest('Atualizador historico V11.14 nao fornecido no pacote; teste nao executado.')
SPEC = importlib.util.spec_from_file_location('updater_v1114', PACKAGE / 'ATUALIZAR_V11_14.py')
UPDATER = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(UPDATER)


class UpgradeTest(unittest.TestCase):
    def test_existing_installation_backup_and_user_files(self):
        with tempfile.TemporaryDirectory() as tmp:
            destination = Path(tmp) / 'Desktop_V10'
            (destination / 'src').mkdir(parents=True)
            (destination / 'package.json').write_text('{"version":"0.11.9"}')
            (destination / 'magicedit_server.py').write_text('print("old")')
            (destination / 'src/main.js').write_text('console.log("old")')
            (destination / 'gravacao.mp4').write_bytes(b'original intacto')
            (destination / 'edicao.json').write_text('{"schema":1}')
            backup = UPDATER.install(PACKAGE / 'arquivos', destination)
            self.assertEqual(json.loads((destination / 'package.json').read_text())['version'], '0.11.14')
            self.assertEqual((backup / 'magicedit_server.py').read_text(), 'print("old")')
            for name in ('gravacao.mp4', 'edicao.json'):
                self.assertEqual((destination / name).read_bytes(), (backup / name).read_bytes())
            self.assertTrue((destination / 'mp4_export.py').is_file())
            self.assertTrue((destination / 'src/preview_v11.js').is_file())
            self.assertTrue((destination / 'src/selection.js').is_file())
