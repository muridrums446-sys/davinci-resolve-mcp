import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {analyzeTranscript,automaticCuts,projectCutsOnOpen} from '../src/autoedit.js';
import {detectTakeRestarts} from '../src/take_restarts.js';

const cases=JSON.parse(fs.readFileSync(new URL('./fixtures/retakes_v23.json',import.meta.url))).cases;
const removed=words=>[...automaticCuts(analyzeTranscript(words,words.at(-1).end+.2),words).deleted].sort((a,b)=>a-b);
const words=text=>text.split(' ').map((word,i)=>({word,start:i*.3,end:i*.3+.24}));
for(const item of cases)test(`caso real ${item.name}: primeira tentativa sai inteira e a ultima fica`,()=>{
  const before=structuredClone(item.words);
  assert.deepEqual(removed(item.words),item.remove);
  assert.deepEqual(item.words,before);
});
test('perguntas retomadas com introducoes diferentes mantem a ultima versao completa',()=>{
  assert.deepEqual(removed(words('Você ganha dinheiro no mercado? Então, como que você ganha? Próximo passo, como você ganha dinheiro no mercado?')),Array.from({length:10},(_,i)=>i));
});
test('exemplos completos com valores diferentes permanecem',()=>{
  assert.deepEqual(removed(words('Você comprou uma ação a 10 reais. Então, você comprou uma ação a 100 reais.')),[]);
  assert.deepEqual(removed(words('Ao comprar ações você participa. Ao comprar fundos você diversifica.')),[]);
  assert.deepEqual(removed(words('Você comprou uma ação a 10 reais... Então, você comprou uma ação a 100 reais para comparar.')),[]);
});
test('perguntas respondidas, repeticao didatica e fragmentos isolados ficam',()=>{
  for(const text of ['Você ganha dinheiro no mercado? Sim, você ganha dinheiro no mercado quando investe.',
    'Repito, você ganha dinheiro no mercado? Próximo passo, como você ganha dinheiro no mercado?',
    'Ao comprar, você precisa analisar a empresa.', 'de boa... de boa',
    'Por exemplo, você comprou uma ação... Então, exemplo que você comprou uma ação cara.'])
    assert.deepEqual(removed(words(text)),[],text);
});
test('negacao, informacao exclusiva e retomada distante nao sao eliminadas',()=>{
  assert.deepEqual(removed(words('Você não ganha dinheiro no mercado? Próximo passo, como você ganha dinheiro no mercado?')),[]);
  assert.deepEqual(removed(words('Você ganha dinheiro no mercado americano? Próximo passo, como você ganha dinheiro no mercado?')),[]);
  assert.deepEqual(removed(words('Você ganha dinheiro no mercado? Então, como você ganha dinheiro no mercado sem investir?')),[]);
  assert.deepEqual(detectTakeRestarts(words('Ao comprar, então, ao comprar, então quando você não compra ações perde direitos.')),[]);
  const w=words('Você ganha dinheiro no mercado? Próximo passo, como você ganha dinheiro no mercado?');
  for(const word of w.slice(5)){word.start+=20;word.end+=20;}
  assert.deepEqual(removed(w),[]);
});
test('reformulacao interrompida nao apaga negacao ou informacao substantiva exclusiva',()=>{
  for(const text of [
    'Então um exemplo de você comprou uma ação e não vendeu e você... Então exemplo que você comprou uma ação e vendeu com lucro.',
    'Então um exemplo de você comprou uma ação americana e você... Então exemplo que você comprou uma ação brasileira e essa subiu.',
    'Você comprou uma ação e não vendeu e você... Então você comprou uma ação e vendeu com lucro.',
    'Você comprou uma ação americana e você... Então você comprou uma ação brasileira e essa subiu.'
  ])assert.deepEqual(removed(words(text)),[],text);
});
test('reformulacao conserva o sujeito e distingue frase completa de interrupcao',()=>{
  for(const text of [
    'Então um exemplo de você comprou uma ação e ele vendeu... Então exemplo que você comprou uma ação e você vendeu.',
    'Então um exemplo de você comprou uma ação e ele vendeu e você... Então exemplo que você comprou uma ação e você vendeu com lucro.',
    'Então um exemplo de você comprou uma ação e você vendeu e você... Então exemplo que você comprou uma ação e ele vendeu com lucro.'
  ])assert.deepEqual(removed(words(text)),[],text);
});
test('abrir JSON nunca aplica a nova deteccao automaticamente',()=>{
  const w=cases[1].words;
  assert.deepEqual([...projectCutsOnOpen({schema:1,deletedIndices:[0]},analyzeTranscript(w,200),w)],[0]);
});
