import http.client, json, threading, unittest
from http.server import ThreadingHTTPServer
from unittest.mock import patch
import magicedit_server as app
KEY='AIza_dummy_key_for_tests_only_123456789'
class GeminiRoutesTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.http=ThreadingHTTPServer(('127.0.0.1',0),app.Handler)
        threading.Thread(target=cls.http.serve_forever,daemon=True).start()
    @classmethod
    def tearDownClass(cls):cls.http.shutdown();cls.http.server_close()
    def post(self,path,payload):
        connection=http.client.HTTPConnection('127.0.0.1',self.http.server_port,timeout=5)
        connection.request('POST','/api/'+path,json.dumps(payload),{'Content-Type':'application/json'})
        response=connection.getresponse();body=json.loads(response.read());connection.close();return response.status,body
    def setUp(self):
        self.old=dict(app.STATE)
        app.STATE.update(file='/tmp/fictional.mp4',media={'duration':10},job={'state':'idle'})
    def tearDown(self):app.STATE.clear();app.STATE.update(self.old)
    def test_models_returns_account_list_without_saving_credentials(self):
        with patch.object(app,'gemini_list_models',return_value=[{'id':'gemini-test','name':'Test'}]):
            status,body=self.post('gemini_models',{'apiKey':KEY})
        self.assertEqual(status,200);self.assertEqual(body['models'][0]['id'],'gemini-test');self.assertNotIn(KEY,json.dumps(app.STATE))
    def test_model_route_accepts_opaque_clipboard_key_without_returning_secret(self):
        secret='fake.token:with/symbols+and=padding_-';observed=[]
        def models(key):
            observed.append(key);return [{'id':'gemini-test','name':'Test'}]
        with patch.object(app,'gemini_list_models',side_effect=models):
            status,body=self.post('gemini_models',{'apiKey':'\ufeff\u200b'+secret+'\r\n'})
        self.assertEqual(status,200);self.assertEqual(observed,[secret]);self.assertNotIn(secret,json.dumps(body))
    def test_audio_route_passes_normalized_key_to_worker(self):
        secret='fake.token:with/symbols+and=padding_-';observed=[];called=threading.Event()
        def worker(*args):observed.append(args[3]);called.set()
        payload={'apiKey':'\ufeff\u200b'+secret+'\r\n','model':'gemini-test','words':[],'consent':True}
        with patch.object(app,'background_review_audio',side_effect=worker):
            status,body=self.post('review_audio',payload);self.assertTrue(called.wait(2))
        self.assertEqual(status,202);self.assertEqual(observed,[secret]);self.assertNotIn(secret,json.dumps(app.STATE))
    def test_audio_requires_explicit_consent_and_valid_selection_before_job(self):
        base={'apiKey':KEY,'model':'gemini-test','words':[],'context':''}
        for changes in [{},{'consent':False},{'consent':True,'selection':{'start':-1,'end':3}},{'consent':True,'model':'../evil'}]:
            status,_=self.post('review_audio',{**base,**changes});self.assertEqual(status,400)
            self.assertEqual(app.STATE['job']['state'],'idle')
    def test_only_server_selected_media_is_used_and_busy_jobs_are_rejected(self):
        payload={'apiKey':KEY,'model':'gemini-test','words':[],'consent':True,'path':'/tmp/evil.mp4'}
        called=threading.Event();calls=[]
        def worker(*args):calls.append(args);called.set()
        with patch.object(app,'background_review_audio',side_effect=worker):
            status,body=self.post('review_audio',payload)
            self.assertTrue(called.wait(2))
        self.assertEqual(status,202);self.assertTrue(body['started']);self.assertEqual(calls[0][0],'/tmp/fictional.mp4')
        status,_=self.post('review_audio',payload);self.assertEqual(status,400)
    def test_worker_error_never_echoes_sdk_or_key(self):
        with patch.object(app,'gemini_review_audio',side_effect=Exception(KEY)):
            app.background_review_audio('/tmp/fictional.mp4',{'duration':10},[],KEY,'gemini-test','',None)
        self.assertEqual(app.STATE['job']['state'],'error');self.assertNotIn(KEY,json.dumps(app.STATE['job']))
