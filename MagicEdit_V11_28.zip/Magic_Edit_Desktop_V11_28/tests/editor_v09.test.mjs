import test from 'node:test';
import assert from 'node:assert/strict';
import {groupParagraphs,transcriptCutMarkers,detectVerifiedSilences,reviewableAudioGaps,timeAtClientX,findUntranscribedGaps} from '../src/editor_v09.js';
import {exportFcp7Xml,summarizeTimeline} from '../src/engine.js';
const words=[{word:'Oi',start:0,end:.2},{word:'pessoal.',start:.23,end:.55},{word:'Vamos',start:4,end:4.3},{word:'falar',start:4.35,end:4.65}];
test('sinal audivel sem palavras e sinalizado para revisao, nunca cortado',()=>{
 const peaks=new Array(110).fill(2);
 for(let i=23;i<58;i++)peaks[i]=70;
 const gaps=findUntranscribedGaps(words,5.5,peaks,20,{norm:100});
 assert.ok(gaps.some(x=>x.start>=.55&&x.start<1.5&&x.end>=2.9&&x.end<=4),JSON.stringify(gaps));
 assert.ok(!detectVerifiedSilences(words,5.5,peaks,20,{norm:100}).some(x=>x.start<2.9&&x.end>1.5));
});
test('Silencio real entre frases deve ser removido, mantendo bordas das palavras',()=>{
 const audio=new Array(110).fill(2); // 5.5 segundos 20 bins/s
 for(let i=0;i<=12;i++)audio[i]=140;
 for(let i=79;i<=95;i++)audio[i]=150;
 const s=detectVerifiedSilences(words,5.5,audio,20,{norm:150,speech:[{start:0,end:.7},{start:3.9,end:4.8}]});
 assert.ok(s.length>=1,JSON.stringify(s));
 assert.ok(s[0].start>=.55+.18);assert.ok(s[0].end<=4-.18);
 const timeline=summarizeTimeline({duration:5.5,fpsNum:30,fpsDen:1},words,new Set(),s);
 assert.ok(timeline.removed>2);
 const xml=exportFcp7Xml({path:'C:\\video.mp4',media:{name:'video.mp4',duration:5.5,width:1920,height:1080,fpsNum:30,fpsDen:1},words,deletedIndices:new Set(),extraCuts:s});
 assert.match(xml,/<clipitem id="v_2">/);assert.match(xml,/<clipitem id="a_2">/);
});
test('Nao remover pausa textual com musica ou outra fala nao reconhecida',()=>{
 const audio=new Array(110).fill(100);
 const s=detectVerifiedSilences(words,5.5,audio,20,{norm:100,speech:[{start:0,end:.7},{start:3.9,end:4.8}]});
 assert.deepEqual(s,[]);
});
test('Ruido constante acima do silencio absoluto permite corte com VAD e sem palavras',()=>{
 const w=[{word:'antes',start:0,end:.5},{word:'depois',start:7.5,end:8}];
 const audio=new Array(160).fill(12);
 for(let i=0;i<15;i++)audio[i]=125;
 for(let i=145;i<160;i++)audio[i]=125;
 const speech=[{start:0,end:.7},{start:7.3,end:8}];
 const cuts=detectVerifiedSilences(w,8,audio,20,{norm:127,speech});
 assert.ok(cuts.some(c=>c.start>=.8&&c.end<=7.2&&c.end-c.start>5),JSON.stringify(cuts));
 assert.deepEqual(detectVerifiedSilences(w,8,audio,20,{norm:127}),[],'sem VAD não há corte');
});
test('Fala sem texto, ruido oscilante e picos prolongados ficam para revisao',()=>{
 const w=[{word:'antes',start:0,end:.5},{word:'depois',start:9.5,end:10}];
 const audio=new Array(200).fill(12);
 for(let i=40;i<150;i++)audio[i]=i%4===0?45:25;
 const speech=[{start:0,end:.7},{start:4,end:5},{start:9.3,end:10}];
 const cuts=detectVerifiedSilences(w,10,audio,20,{norm:127,speech});
 assert.ok(cuts.every(c=>c.end<=4||c.start>=5),JSON.stringify(cuts));
 assert.ok(!cuts.some(c=>c.start<7&&c.end>6),'som sustentado deve continuar para revisao');
});
test('Tosse breve dentro de pausa longa sem voz pode ser pre-cortada',()=>{
 const w=[{word:'antes',start:0,end:.5},{word:'depois',start:9.5,end:10}];
 const audio=new Array(220).fill(2);
 for(let i=60;i<72;i++)audio[i]=160; // tosse de 0,6 s
 const cuts=detectVerifiedSilences(w,11,audio,20,{norm:150,speech:[{start:0,end:.7},{start:9.3,end:10.2}]});
 assert.ok(cuts.some(c=>c.start>=.5&&c.start<3&&c.end>8&&c.end<=9.5),JSON.stringify(cuts));
});
test('Fala sem legenda protegida pelo Silero mesmo com pausa ao redor',()=>{
 const w=[{word:'antes',start:0,end:.5},{word:'depois',start:9.5,end:10}];
 const audio=new Array(220).fill(2);
 for(let i=60;i<72;i++)audio[i]=160;
 const cuts=detectVerifiedSilences(w,11,audio,20,{norm:150,speech:[{start:0,end:.7},{start:2.9,end:3.7},{start:9.3,end:10.2}]});
 assert.ok(cuts.every(c=>c.end<=2.9||c.start>=3.7),JSON.stringify(cuts));
});
test('Controle de intensidade preserva cortes cautelosos e revisa tosse com voz detectada',()=>{
 const w=[{word:'inicio',start:0,end:.5},{word:'final',start:11.5,end:12}];
 const audio=new Array(240).fill(12);
 for(let i=66;i<77;i++)audio[i]=90; // breve ruido no silencio
 for(let i=132;i<160;i++)audio[i]=85; // voz sem texto, protegida pelo VAD
 const speech=[{start:0,end:.7},{start:6.5,end:8.1},{start:11.3,end:12}];
 const options={norm:127,speech};
 const calm=detectVerifiedSilences(w,12,audio,20,{...options,strength:0});
 const balanced=detectVerifiedSilences(w,12,audio,20,{...options,strength:50});
 const strong=detectVerifiedSilences(w,12,audio,20,{...options,strength:100});
 const total=cuts=>cuts.reduce((n,x)=>n+x.end-x.start,0);
 assert.ok(total(calm)<=total(balanced)&&total(balanced)<=total(strong));
 assert.ok(strong.every(c=>c.end<=6.38||c.start>=8.22),'voz Silero continua fora dos cortes');
 assert.ok(strong.some(c=>c.start<3&&c.end>4),'ruido breve entra na pausa com intensidade forte');
 const review=reviewableAudioGaps(w,12,audio,20,options);
 assert.ok(review.some(g=>g.reason.includes('voz')&&g.start<7&&g.end>7));
});
test('Som sustentado sem legenda nao vira corte automatico',()=>{
 const w=[{word:'antes',start:0,end:.5},{word:'depois',start:9.5,end:10}];
 const audio=new Array(220).fill(2);
 for(let i=50;i<165;i++)audio[i]=80;
 assert.deepEqual(detectVerifiedSilences(w,11,audio,20,{norm:100,speech:[{start:0,end:.7},{start:9.3,end:10.2}]}),[]);
});
test('Nao inventa silencios caso audio esteja indisponivel',()=>{
 assert.deepEqual(detectVerifiedSilences(words,5.5,[],20),[]);
});
test('Paragrafos preservam ordem, nenhuma palavra perdida em trechos longos',()=>{
 const many=Array.from({length:6114},(_,i)=>({word:i%25===24?'palavra.':'palavra',start:i*.4,end:i*.4+.3}));
 const out=groupParagraphs(many);
 assert.ok(out.length>100);assert.equal(out[0].start,0);assert.equal(out.at(-1).end,6113);
 for(let i=1;i<out.length;i++)assert.equal(out[i].start,out[i-1].end+1);
});
test('Pausa longa cria paragrafo independente',()=>{
 assert.deepEqual(groupParagraphs(words),[{start:0,end:1},{start:2,end:3}]);
});
test('Marcador de mouse mostra timecode correto respeitando zoom',()=>{
 const view={start:60,span:30,duration:120};const rect={left:200,width:1000};
 assert.equal(timeAtClientX(200,rect,view),60);
 assert.equal(timeAtClientX(700,rect,view),75);
 assert.equal(timeAtClientX(1200,rect,view),90);
});

test('Silero protege fala que nao entrou na transcricao', () => {
  const words=[{word:'um',start:1,end:1.3},{word:'fim',start:7,end:7.3}];
  const peaks=Array(200).fill(0);
  const speech=[{start:.8,end:1.5},{start:3,end:5},{start:6.8,end:7.5}];
  const cuts=detectVerifiedSilences(words,10,peaks,20,{norm:100,speech});
  assert.ok(cuts.length>0);
  assert.ok(cuts.every(c=>c.end<=3||c.start>=5));
  assert.deepEqual(detectVerifiedSilences(words,10,peaks,20,{norm:100}),[]);
});
test('cada intervalo cortado aparece no texto e pode ser restaurado por indice',()=>{
 const cuts=[{start:.6,end:3.6},{start:4.7,end:5.4},{start:0,end:.12}];
 const {markers,covered}=transcriptCutMarkers(words,cuts);
 assert.equal(markers.get(2)[0].index,0);
 assert.equal(markers.get(words.length)[0].index,1);
 assert.equal(markers.has(0),false,'palavra cortada aparece riscada, sem caixa genérica');
 assert.deepEqual([...covered],[0]);
 const inside=transcriptCutMarkers(words,[{start:3.9,end:4.7}]);
 assert.ok(inside.covered.has(2));
});
