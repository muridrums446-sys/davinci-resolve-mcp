import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import vad_local

class VadTest(unittest.TestCase):
    def test_speech_hysteresis_keeps_syllables_and_silence(self):
        scores = [0] * 20 + [.85] * 32 + [0] * 25
        result = vad_local.speech_intervals(scores, len(scores) * .032)
        self.assertEqual(len(result), 1)
        self.assertLessEqual(result[0]['start'], 20 * .032)
        self.assertGreaterEqual(result[0]['end'], 52 * .032)

    def test_cache_reuses_same_media_and_invalidates_change(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'recording.mp4'
            path.write_bytes(b'original')
            with patch.object(vad_local, 'CACHE', Path(folder) / 'cache'):
                vad_local.write_cache(path, {'model': vad_local.MODEL_SHA256, 'speech': [{'start': 1, 'end': 2}]})
                self.assertEqual(len(vad_local.read_cache(path)['speech']), 1)
                self.assertEqual(vad_local.analyze(str(path),'nao-usado',3)['speechPadding'],.22)
                path.write_bytes(b'original edited')
                self.assertIsNone(vad_local.read_cache(path))

    def test_onnx_model_runs_without_torch(self):
        import numpy as np
        import onnxruntime as ort
        sess = ort.InferenceSession(str(vad_local.MODEL), providers=['CPUExecutionProvider'])
        scores = list(vad_local.probabilities([b'\0' * 1024 for _ in range(5)], sess))
        self.assertEqual(len(scores), 5)
        self.assertTrue(all(0 <= score <= 1 for score, _ in scores))

if __name__ == '__main__': unittest.main()
