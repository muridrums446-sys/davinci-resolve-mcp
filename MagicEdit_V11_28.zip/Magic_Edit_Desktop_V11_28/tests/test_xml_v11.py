"""Valida estrutura e alinhamento FCP7 XML sem depender do DaVinci instalado."""
import subprocess
import unittest
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


class XmlV11Test(unittest.TestCase):
    def test_audio_video_and_source_ranges_match(self):
        script = """import {exportFcp7Xml} from './src/engine.js';
const media={name:'Vídeo teste.mp4',duration:5,width:640,height:360,fpsNum:25,fpsDen:1};
console.log(exportFcp7Xml({path:'C:\\\\Vídeos\\\\Vídeo teste.mp4',media,
 words:[{word:'a',start:2,end:3}],deletedIndices:new Set([0]),extraCuts:[]}));"""
        xml = subprocess.check_output(['node', '--input-type=module', '-e', script], cwd=ROOT, text=True)
        root = ET.fromstring(xml)
        video = root.findall('./sequence/media/video/track/clipitem')
        audio = root.findall('./sequence/media/audio/track/clipitem')
        self.assertEqual(len(video), 2)
        self.assertEqual(len(audio), 2)
        for v, a in zip(video, audio):
            self.assertEqual([v.findtext(x) for x in ('start', 'end', 'in', 'out')],
                             [a.findtext(x) for x in ('start', 'end', 'in', 'out')])
            self.assertLess(int(v.findtext('in')), int(v.findtext('out')))
        self.assertEqual(video[0].findtext('start'), '0')
        self.assertEqual(video[1].findtext('start'), video[0].findtext('end'))
        self.assertIn('V%C3%ADdeo%20teste.mp4', xml)
        self.assertIsNotNone(video[0].find('./file/pathurl'))


if __name__ == '__main__':
    unittest.main()
