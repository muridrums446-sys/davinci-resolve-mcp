import test from 'node:test';
import assert from 'node:assert/strict';
import {fileUrl,mergeIntervals,cutRanges,keepRanges,suggestSilences,exportFcp7Xml,fpsRate,summarizeTimeline,xmlEscape,findWordAtTime} from '../src/engine.js';
const media={fpsNum:30000,fpsDen:1001,duration:10,width:1920,height:1080,name:'Vídeo #1 & vendas.mp4'};
const words=[{start:1,end:1.5,word:'Fala'},{start:1.6,end:2,word:'patrão'},{start:3.5,end:4,word:'hoje'},{start:4.1,end:4.4,word:'tem'}];
test('FCP XML escape path Unicode & special chars',()=>{assert.equal(fileUrl('C:\\Vídeos\\João #1?.mp4'),'file:///C:/V%C3%ADdeos/Jo%C3%A3o%20%231%3F.mp4');assert.equal(xmlEscape('A&B<"'),'A&amp;B&lt;&quot;')});
test('Remove intervalos e calcula trechos remanescentes',()=>{const s=keepRanges(10,[{start:2,end:4}],30); assert.deepEqual(s,[{in:0,out:60},{in:120,out:300}]);assert.equal(mergeIntervals([{start:1,end:2},{start:1.5,end:3}],10).length,1)});
test('Detecta pausas entre palavras e evita silenciar palavras',()=>{const x=suggestSilences(words,10,.7,.14);assert.ok(x.some(v=>v.start>2&&v.end<3.5)); assert.ok(x.every(v=>v.end>v.start))});
test('FPS NTSC e edicao retornam dados coerentes',()=>{assert.deepEqual(fpsRate(30000,1001).timebase,30);const x=summarizeTimeline(media,words,new Set([0,1]),[]);assert.ok(x.edited<media.duration);assert.ok(x.edited>0)});
test('Exporta XML xmeml com trilhas de audio e video sincronizadas',()=>{const xml=exportFcp7Xml({path:'C:\\Vídeos\\Vídeo #1 & vendas.mp4',media,words,deletedIndices:new Set([1]),extraCuts:[{start:5,end:6}]});assert.ok(xml.startsWith('<?xml'));assert.match(xml,/<xmeml version="5">/);assert.match(xml,/<timebase>30<\/timebase><ntsc>TRUE<\/ntsc>/);assert.match(xml,/<clipitem id="v_1">/);assert.match(xml,/<clipitem id="a_1">/);assert.match(xml,/file:\/\/\/C:\/V%C3%ADdeos\/V%C3%ADdeo%20%231%20%26%20vendas.mp4/);assert.ok((xml.match(/<linkclipref>/g)||[]).length>=4)});
test('Nao exporta quando todos os trechos foram removidos',()=>assert.throws(()=>exportFcp7Xml({path:'C:\\a.mp4',media,words,deletedIndices:new Set([]),extraCuts:[{start:0,end:10}]}),/excluidos/));
test('Cortes em palavras nao saem fora do video',()=>{const x=cutRanges([{start:0.01,end:0.3},{start:9.8,end:10}],new Set([0,1]),[],10);assert.ok(x[0].start>=0);assert.ok(x.at(-1).end<=10)});

test('Palavra ativa acompanha o tempo do video (inicio, meio, fim)',()=>{
  assert.equal(findWordAtTime(words,1.2),0);
  assert.equal(findWordAtTime(words,1.75),1);
  assert.equal(findWordAtTime(words,3.7),2);
  assert.equal(findWordAtTime(words,4.25),3);
});
test('Nao acende palavra antiga no silencio',()=>{
  assert.equal(findWordAtTime(words,2.7),-1);
  assert.equal(findWordAtTime(words,8),-1);
});
test('Busca binaria funciona em transcricoes de 6000 palavras',()=>{
  const big=Array.from({length:6114},(_,i)=>({start:i*.4,end:i*.4+.32,word:'fala'}));
  assert.equal(findWordAtTime(big,2000.12),5000);
  assert.equal(findWordAtTime(big,2445.2),6113);
  assert.equal(findWordAtTime(big,2500),-1);
});
