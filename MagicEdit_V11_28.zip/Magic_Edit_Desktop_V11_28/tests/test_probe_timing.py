import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import magicedit_server as app

class ProbeTimingTest(unittest.TestCase):
    def test_nominal_supported_rate_is_used_when_average_has_container_rounding(self):
        with tempfile.TemporaryDirectory() as tmp:
            video=Path(tmp)/'video.mov';video.write_bytes(b'placeholder')
            data={'format':{'duration':'124.405'},'streams':[
                {'codec_type':'video','width':1920,'height':1080,'avg_frame_rate':'746600/24881','r_frame_rate':'30/1'},
                {'codec_type':'audio'}]}
            with patch.object(app,'run_process',return_value=json.dumps(data).encode()),patch.object(app,'executable',return_value='ffprobe'):
                media=app.probe_video(str(video))
            self.assertEqual((media['fpsNum'],media['fpsDen']),(30,1))
