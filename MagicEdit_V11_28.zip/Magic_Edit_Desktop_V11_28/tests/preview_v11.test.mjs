import test from 'node:test';
import assert from 'node:assert/strict';
import {playbackTarget,filmstripSamples,manualCutRange,splitFrameAt,segmentAtTime} from '../src/preview_v11.js';

test('reproducao iniciada dentro de um corte salta ao proximo trecho',()=>{
  assert.deepEqual(playbackTarget(2.5,[{start:2,end:3}],10),{time:3,ended:false});
  assert.deepEqual(playbackTarget(2,[{start:2,end:3}],10),{time:3,ended:false});
});
test('corte final encerra em vez de reproduzir o trecho removido',()=>{
  assert.deepEqual(playbackTarget(9.5,[{start:9,end:10}],10),{time:9,ended:true});
  assert.deepEqual(playbackTarget(0,[{start:0,end:10}],10),{time:0,ended:true});
});
test('trecho valido preserva tempo da fonte para XML e transcricao',()=>{
  assert.deepEqual(playbackTarget(1.5,[{start:2,end:3}],10),{time:1.5,ended:false});
});
test('amostras de miniaturas acompanham zoom e limites do video',()=>{
  assert.deepEqual(filmstripSamples({start:2,span:4,duration:8},400,100),[2.5,3.5,4.5,5.5]);
  assert.deepEqual(filmstripSamples({start:0,span:2,duration:2},400,100),[0.25,0.75,1.25,1.75]);
});
test('corte manual entre dois pontos funciona inclusive sem palavras',()=>{
  assert.deepEqual(manualCutRange(4.5,2,10),{start:2,end:4.5});
  assert.equal(manualCutRange(2,2.01,10),null);
  assert.equal(manualCutRange(9,20,10),null);
});
test('C marca limites em frames e clique seleciona o clipe inteiro sem apagar',()=>{
  const fps=30000/1001, frames=300;
  const first=splitFrameAt(2.002,frames,fps),second=splitFrameAt(4.004,frames,fps);
  assert.deepEqual([first,second],[60,120]);
  assert.deepEqual(segmentAtTime(3,[first,second],frames,fps),{start:60/fps,end:120/fps});
  assert.deepEqual(segmentAtTime(2.002,[first,second],frames,fps),{start:60/fps,end:120/fps});
  assert.equal(splitFrameAt(0,frames,fps),null);
  assert.equal(splitFrameAt(300/fps,frames,fps),null);
});
