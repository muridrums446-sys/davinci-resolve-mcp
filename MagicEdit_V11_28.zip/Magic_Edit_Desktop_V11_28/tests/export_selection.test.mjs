import test from 'node:test';
import assert from 'node:assert/strict';
import { sourceSelectionSegments } from '../src/selection.js';
import { segmentAtTime } from '../src/preview_v11.js';

const media={duration:10,fpsNum:25,fpsDen:1};
test('exporta o intervalo continuo da fonte em frames, mesmo arrastando ao contrario',()=>{
  assert.deepEqual(sourceSelectionSegments({start:2,end:5},media),[{in:50,out:125}]);
  assert.deepEqual(sourceSelectionSegments({start:5,end:2},media),[{in:50,out:125}]);
});
test('inclui frames de borda e suporta selecao de um frame e fim do video',()=>{
  assert.deepEqual(sourceSelectionSegments({start:2.01,end:2.05},media),[{in:50,out:52}]);
  assert.deepEqual(sourceSelectionSegments({start:0,end:.04},media),[{in:0,out:1}]);
  assert.deepEqual(sourceSelectionSegments({start:9.96,end:10},media),[{in:249,out:250}]);
});
test('intervalo NTSC usa a fracao real do fps',()=>{
  assert.deepEqual(sourceSelectionSegments({start:1001/30000,end:1001*4/30000},
    {duration:10,fpsNum:30000,fpsDen:1001}),[{in:1,out:4}]);
});
test('ultimo trecho de divisao NTSC aceita o endpoint do ultimo frame arredondado',()=>{
  const ntsc={duration:10,fpsNum:30000,fpsDen:1001};
  const range=segmentAtTime(9,[150],300,30000/1001);
  assert.deepEqual(sourceSelectionSegments(range,ntsc),[{in:150,out:300}]);
  assert.deepEqual(sourceSelectionSegments({start:5.005,end:10.02},ntsc),[]);
});
test('selecao inexistente, fora da fonte ou midia invalida nao inicia exportacao',()=>{
  for(const range of [null,{}, {start:1,end:1},{start:-1,end:2},{start:1,end:11},{start:NaN,end:2}])
    assert.deepEqual(sourceSelectionSegments(range,media),[]);
  for(const invalid of [null,{}, {...media,fpsDen:0},{...media,duration:Infinity},{...media,fpsNum:0}])
    assert.deepEqual(sourceSelectionSegments({start:1,end:2},invalid),[]);
});
