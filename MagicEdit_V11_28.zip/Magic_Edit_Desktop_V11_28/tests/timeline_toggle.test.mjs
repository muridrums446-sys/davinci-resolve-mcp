import test from 'node:test';
import assert from 'node:assert/strict';
import * as selection from '../src/selection.js';
import {cutRanges} from '../src/engine.js';
const run=(...args)=>{assert.equal(typeof selection.toggleTimelineCut,'function','alternancia temporal disponivel');return selection.toggleTimelineCut(...args);};
test('mesma selecao corta e restaura sem alterar entradas',()=>{
 const deleted=new Set(),extra=[{start:7,end:8}],range={start:1,end:3};
 const cut=run([],deleted,extra,range,10);assert.equal(cut.action,'deleted');
 assert.deepEqual(cut.extraCuts,[...extra,range]);
 const restored=run([],cut.deleted,cut.extraCuts,range,10);
 assert.equal(restored.action,'restored');assert.deepEqual(restored.extraCuts,extra);
 assert.deepEqual(extra,[{start:7,end:8}]);assert.equal(deleted.size,0);
});
test('restaurar parte de silencio conserva cortes a esquerda e a direita',()=>{
 const result=run([],new Set(),[{start:1,end:6},{start:8,end:9}],{start:2,end:4},10);
 assert.deepEqual(cutRanges([],result.deleted,result.extraCuts,10),[{start:1,end:2},{start:4,end:6},{start:8,end:9}]);
});
test('selecao parcialmente cortada corta tudo e nao restaura por engano',()=>{
 const result=run([],new Set(),[{start:1,end:2},{start:3,end:4}],{start:1,end:4},10);
 assert.equal(result.action,'deleted');assert.deepEqual(cutRanges([],result.deleted,result.extraCuts,10),[{start:1,end:4}]);
});
test('restaurar parte de corte textual inclui os espacos entre palavras',()=>{
 const words=[{word:'um',start:1,end:1.5},{word:'dois',start:2,end:2.5},{word:'tres',start:3,end:3.5},{word:'fim',start:8,end:8.5}];
 const deleted=new Set([0,1,2,3]);
 const original=cutRanges(words,deleted,[],10);
 const result=run(words,deleted,[],{start:1.6,end:2.8},10);
 assert.equal(result.action,'restored');
 assert.deepEqual(cutRanges(words,result.deleted,result.extraCuts,10),[{start:original[0].start,end:1.6},{start:2.8,end:original[1]?.end??original[0].end}]);
 assert.deepEqual([...deleted],[0,1,2,3]);
});
test('palavra restaurada fica ativa e cortes externos permanecem',()=>{
 const words=[{word:'antes',start:1,end:2},{word:'volta',start:3,end:4},{word:'apos',start:6,end:7}];
 const result=run(words,new Set([1]),[{start:8,end:9}],{start:2.982,end:4.018},10);
 assert.equal(result.action,'restored');assert.equal(result.deleted.has(1),false);
 assert.deepEqual(result.extraCuts,[{start:8,end:9}]);
});
