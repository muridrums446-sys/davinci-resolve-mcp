"""Teste offline da camada Groq: nao usa API key, nao faz requisicoes."""
import sys
import tempfile
import types
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import magicedit_server as app

class AuthenticationError(Exception): pass
class PermissionDeniedError(Exception): pass
class RateLimitError(Exception): pass
class APIConnectionError(Exception): pass
class APIStatusError(Exception): pass

class SDKTests(unittest.TestCase):
    def test_short_chunks_cover_long_recording_without_tiny_tail(self):
        chunks=app.transcription_chunks(96)
        self.assertEqual([(c['lo'],c['hi']) for c in chunks],[(0,30),(30,60),(60,96)])
        self.assertEqual((chunks[1]['origin'],chunks[1]['stop']),(28,62))
        self.assertTrue(all(c['stop']-c['origin']>=10 for c in chunks))

    def test_short_recording_is_one_chunk(self):
        self.assertEqual(len(app.transcription_chunks(8)),1)

    def test_free_tier_request_spacing(self):
        self.assertGreaterEqual(app.transcription_wait_seconds(10.0,12.0),1.1)
        self.assertEqual(app.transcription_wait_seconds(10.0,14.0),0)

    def test_boundary_word_from_neighbor_is_not_discarded(self):
        parts=[{'lo':0,'hi':540,'origin':0,'stop':542,'words':[{'word':'vou','start':539.1,'end':539.4}]},
               {'lo':540,'hi':1080,'origin':538,'stop':1080,'words':[{'word':'voltar','start':1.7,'end':2.1}]}]
        self.assertEqual([w['word'] for w in app.trim_and_offset_words(parts)],['vou','voltar'])

    def test_overlapping_word_transcribed_twice_appears_once(self):
        parts=[{'lo':0,'hi':540,'origin':0,'stop':542,'words':[{'word':'agora','start':539.8,'end':540.2}]},
               {'lo':540,'hi':1080,'origin':538,'stop':1080,'words':[{'word':'agora','start':1.83,'end':2.23}]}]
        self.assertEqual(len(app.trim_and_offset_words(parts)),1)

    def test_repeated_word_with_overlapping_timestamps_in_same_take_is_kept(self):
        parts=[{'lo':0,'hi':30,'origin':0,'stop':30,'words':[
            {'word':'não','start':8.0,'end':8.3},
            {'word':'não','start':8.1,'end':8.4},
            {'word':'quero','start':8.4,'end':8.8}]}]
        self.assertEqual([w['word'] for w in app.trim_and_offset_words(parts)],['não','não','quero'])

    def test_word_order_is_not_rearranged_by_inaccurate_whisper_timestamps(self):
        parts=[{'lo':0,'hi':30,'origin':0,'stop':30,'words':[
            {'word':'pode','start':1,'end':1.2},
            {'word':'sim','start':1.4,'end':1.65},
            {'word':'aí','start':1.22,'end':1.45}]}]
        result=app.trim_and_offset_words(parts)
        self.assertEqual([w['word'] for w in result],['pode','sim','aí'])
        self.assertEqual([w['start'] for w in result],sorted(w['start'] for w in result))

    def _run_with_fake(self, error=None):
        calls=[]
        class Client:
            def __init__(self, **kw):
                self.audio = types.SimpleNamespace(transcriptions=types.SimpleNamespace(create=self.create))
            def create(self, **kw):
                calls.append(kw)
                if error:
                    raise error
                return types.SimpleNamespace(model_dump=lambda: {'words':[{'word':'Teste','start':0.2,'end':0.7}]})
        fake=types.ModuleType('groq')
        for name,val in {'Groq':Client,'AuthenticationError':AuthenticationError,'PermissionDeniedError':PermissionDeniedError,'RateLimitError':RateLimitError,'APIConnectionError':APIConnectionError,'APIStatusError':APIStatusError}.items(): setattr(fake,name,val)
        with tempfile.TemporaryDirectory() as tmp:
            f=Path(tmp)/'sample.flac'
            f.write_bytes(b'test_data')
            with patch.dict(sys.modules,{'groq':fake}):
                words=app.groq_transcribe(f,'gsk_TEST_FAKE','whisper-large-v3')
        return words,calls
    def test_words_from_official_sdk(self):
        words,calls=self._run_with_fake()
        self.assertEqual(words,[{'word':'Teste','start':0.2,'end':0.7}])
        self.assertEqual(calls[0]['language'],'pt')
        self.assertEqual(calls[0]['timestamp_granularities'],['word'])
        self.assertEqual(calls[0]['response_format'],'verbose_json')
        self.assertNotIn('prompt',calls[0], 'Contexto fixo de outro assunto pode contaminar e substituir falas reais')
        self.assertEqual(calls[0]['file'][2],'audio/flac')
    def test_401(self):
        with self.assertRaisesRegex(RuntimeError,'401'):
            self._run_with_fake(AuthenticationError())
    def test_429(self):
        with self.assertRaisesRegex(RuntimeError,'429'):
            self._run_with_fake(RateLimitError())
    def test_429_retry_after_is_available_without_exposing_key(self):
        error=RateLimitError()
        error.response=types.SimpleNamespace(headers={'retry-after':'3660'})
        with self.assertRaises(app.GroqRateLimit) as caught:
            self._run_with_fake(error)
        self.assertEqual(caught.exception.retry_after,3660)
        self.assertNotIn('gsk_',str(caught.exception))
    def test_resume_after_long_rate_limit_reuses_completed_chunks(self):
        with tempfile.TemporaryDirectory() as tmp:
            file=Path(tmp)/'gravacao.mp4';file.write_bytes(b'original')
            media={'duration':90}
            cache=Path(tmp)/'config'/'recent.json'
            attempts=[]
            def ffmpeg(args,timeout=240):
                Path(args[-1]).write_bytes(b'flac')
                return b''
            def groq(audio,key,model):
                attempts.append(audio.name)
                if len(attempts)==3:
                    raise app.GroqRateLimit(3600)
                return [{'word':f'palavra{len(attempts)}','start':.2,'end':.5}]
            with patch.object(app,'RECENT_PATH',cache),patch.object(app,'run_process',side_effect=ffmpeg),patch.object(app,'executable',return_value='ffmpeg'),patch.object(app,'groq_transcribe',side_effect=groq),patch.object(app.time,'sleep',return_value=None):
                app.background_transcribe(str(file),media,'gsk_FAKE','whisper-large-v3')
                self.assertEqual(app.STATE['job']['state'],'error')
                self.assertIn('2/3 partes salvas',app.STATE['job']['message'])
                saved=app.transcript_cache_path(str(file),'whisper-large-v3')
                self.assertTrue(saved.exists())
                self.assertNotIn('gsk_FAKE',saved.read_text())
                attempts.clear()
                app.background_transcribe(str(file),media,'gsk_FAKE','whisper-large-v3')
                self.assertEqual(app.STATE['job']['state'],'done')
                self.assertEqual(len(attempts),1,'apenas a parte pendente volta para Groq')
                self.assertEqual(len(app.STATE['job']['result']['words']),3)
                file.write_bytes(b'outro video')
                self.assertNotEqual(saved,app.transcript_cache_path(str(file),'whisper-large-v3'))
    def test_short_429_waits_then_retries_same_chunk(self):
        with tempfile.TemporaryDirectory() as tmp:
            file=Path(tmp)/'curto.mp4';file.write_bytes(b'original')
            calls=[]
            def ffmpeg(args,timeout=240):
                Path(args[-1]).write_bytes(b'flac')
                return b''
            def groq(audio,key,model):
                calls.append(1)
                if len(calls)==1: raise app.GroqRateLimit(2)
                return [{'word':'teste','start':.2,'end':.5}]
            with patch.object(app,'RECENT_PATH',Path(tmp)/'recent.json'),patch.object(app,'run_process',side_effect=ffmpeg),patch.object(app,'executable',return_value='ffmpeg'),patch.object(app,'groq_transcribe',side_effect=groq),patch.object(app.time,'sleep',return_value=None) as sleep:
                app.background_transcribe(str(file),{'duration':8},'gsk_FAKE','whisper-large-v3')
            self.assertEqual(app.STATE['job']['state'],'done')
            self.assertEqual(len(calls),2)
            self.assertGreaterEqual(sleep.call_count,3)
    def test_403_cf1010(self):
        e=PermissionDeniedError()
        e.response=types.SimpleNamespace(text='Cloudflare Error 1010')
        with self.assertRaisesRegex(RuntimeError,'1010'):
            self._run_with_fake(e)

if __name__=='__main__': unittest.main()
