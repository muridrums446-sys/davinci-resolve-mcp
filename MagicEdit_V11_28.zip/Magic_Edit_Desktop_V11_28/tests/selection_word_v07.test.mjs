import test from 'node:test';
import assert from 'node:assert/strict';
import {chooseRange, normalizedSelection, toggleRange} from '../src/selection.js';
test('Native text selection yields inclusive word range',()=>assert.deepEqual(normalizedSelection(6,2,10),{start:2,end:6}));
test('Right click toggles cut and restore in selected range',()=>{const range={start:1,end:4};const a=toggleRange(new Set(),range);assert.equal(a.deleted.size,4);const b=toggleRange(a.deleted,chooseRange(a.deleted,range,3,6));assert.equal(b.deleted.size,0);});
