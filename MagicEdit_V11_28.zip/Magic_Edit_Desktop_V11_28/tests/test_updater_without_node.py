import contextlib
import importlib.util
import io
import shutil
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]


class NoNodeVerificationTest(unittest.TestCase):
    def updater(self):
        spec = importlib.util.spec_from_file_location('updater_no_node', ROOT/'update_desktop.py')
        app = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(app)
        return app

    def test_real_preflight_passes_without_node_and_without_modifying_source(self):
        app = self.updater()
        before = app.inventory(ROOT)
        # Only simulate Node being absent. Python imports/model and FFmpeg checks run.
        real_which = shutil.which
        with patch.object(app.shutil, 'which', side_effect=lambda name, **kw: None if name == 'node' else real_which(name, **kw)):
            with contextlib.redirect_stdout(io.StringIO()) as output:
                app.verify_project(ROOT, ROOT)
        self.assertIn('Node.js opcional', output.getvalue())
        self.assertEqual(app.inventory(ROOT), before)

    def test_modified_javascript_is_rejected_even_without_node(self):
        app = self.updater()
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            for rel in app.FILES:
                dest = folder/rel
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(ROOT/rel, dest)
            (folder/'src/main.js').write_text('invalid release contents')
            before = app.inventory(folder)
            with patch.object(app.shutil, 'which', return_value=None):
                with self.assertRaisesRegex(RuntimeError, 'JavaScript.*src/main.js'):
                    app.verify_project(folder, folder)
            self.assertEqual(app.inventory(folder), before)
