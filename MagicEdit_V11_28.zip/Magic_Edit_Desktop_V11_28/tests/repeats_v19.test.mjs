import test from 'node:test';
import assert from 'node:assert/strict';
import {analyzeTranscript,automaticCuts,projectCutsOnOpen} from '../src/autoedit.js';
const build=text=>text.split(' ').map((word,i)=>({word,start:i*.3,end:i*.3+.24}));
const deleted=text=>{const w=build(text);return [...automaticCuts(analyzeTranscript(w,w.at(-1).end+.2),w).deleted];};
test('frase de duas palavras fica preservada pelo minimo V11.21',()=>assert.deepEqual(deleted('de boa de boa fim'),[]));
test('repeticao de uma palavra fica preservada pelo minimo V11.21',()=>assert.deepEqual(deleted('claro claro vamos'),[]));
test('frase longa repetida remove a tentativa anterior inteira',()=>{
 const phrase='hoje vamos mostrar como uma empresa pode distribuir parte dos seus lucros para todos os investidores que possuem suas ações';
 assert.deepEqual(deleted(`${phrase} ${phrase}`),Array.from({length:phrase.split(' ').length},(_,i)=>i));
});
test('tres tomadas iguais preservam somente a ultima',()=>assert.deepEqual(deleted('vamos começar agora vamos começar agora vamos começar agora'),[0,1,2,3,4,5]));
test('erro falado entre duas tomadas retira a primeira e a indicacao de erro',()=>{
 assert.deepEqual(deleted('hoje vamos mostrar os dividendos pera aí errei hoje vamos mostrar os dividendos'),[0,1,2,3,4,5,6,7]);
});
test('enfase, negacao e repeticao didatica sinalizada continuam protegidas',()=>{
 for(const text of ['muito muito importante','não não faça isso','sim sim','repito vamos começar agora vamos começar agora'])assert.deepEqual(deleted(text),[],text);
});
test('numero alterado sem indicacao de erro nao e duplicata automatica',()=>assert.deepEqual(deleted('daqui a cinquenta anos teremos daqui a dez anos teremos'),[]));
test('abrir projeto nao reaplica um corte que a pessoa restaurou',()=>{
 const w=build('de boa de boa fim');assert.deepEqual([...projectCutsOnOpen({deletedIndices:[]},analyzeTranscript(w,5),w)],[]);
});
