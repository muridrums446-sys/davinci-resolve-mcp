import tempfile
import unittest
from pathlib import Path

from review_takes import cache_key, review_windows, run_review, validate_suggestions


def words(count):
    return [{'word': f'palavra{i}', 'start': i * .32, 'end': i * .32 + .2}
            for i in range(count)]


class ReviewTakesTest(unittest.TestCase):
    def test_untrusted_model_ranges_are_discarded_and_nothing_is_cut(self):
        source = words(12)
        original = [dict(w) for w in source]
        def fake_request(_instructions, _transcript):
            return {'suggestions': [
                {'from': 2, 'to': 4, 'reason': 'primeira tentativa interrompida'},
                {'from': 999, 'to': 1000, 'reason': 'indices fabricados'},
                {'from': True, 'to': 4, 'reason': 'bool nao e indice'},
                {'from': 6, 'to': 2, 'reason': 'ordem invertida'},
            ]}
        with tempfile.TemporaryDirectory() as tmp:
            cache = Path(tmp) / 'review.json'
            suggestions = run_review(source, fake_request, cache)
            self.assertEqual([(s['from'], s['to']) for s in suggestions], [(2, 4)])
            self.assertTrue(suggestions[0]['requiresReview'])
            self.assertEqual(source, original)
            self.assertEqual(run_review(source, lambda *_: self.fail('nao deveria usar Groq novamente'), cache), suggestions)

    def test_many_words_use_overlapping_windows_with_unique_core(self):
        source = words(685)
        windows = review_windows(source)
        self.assertEqual(sum(core_hi-core_lo for _, _, core_lo, core_hi in windows), len(source))
        self.assertTrue(all(lo<=core_lo<core_hi<=hi for lo,hi,core_lo,core_hi in windows))
        self.assertEqual(len(cache_key(source)), 64)
        self.assertEqual(validate_suggestions({'suggestions': [{'from': -1, 'to': 0, 'reason': 'invalido'}]},
                                               source, windows[0]), [])


if __name__ == '__main__':
    unittest.main()
