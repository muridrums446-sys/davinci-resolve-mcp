import test from 'node:test';
import assert from 'node:assert/strict';
import { normalizeSilenceMinimum,detectVerifiedSilences } from '../src/editor_v09.js';

test('novo padrao 0,9 e migracao do padrao antigo preservam valores personalizados',()=>{
  assert.equal(normalizeSilenceMinimum(null),.9);
  assert.equal(normalizeSilenceMinimum(undefined),.9);
  assert.equal(normalizeSilenceMinimum('invalido'),.9);
  assert.equal(normalizeSilenceMinimum(.7,true),.9);
  assert.equal(normalizeSilenceMinimum('.7',true),.9);
  assert.equal(normalizeSilenceMinimum(.7),.7,'controle continua permitindo ajuste manual');
  assert.equal(normalizeSilenceMinimum(.8,true),.8);
  assert.equal(normalizeSilenceMinimum(1.2,true),1.2);
});
test('padrao corta so pausas acima de 0,9 s sem invadir as falas',()=>{
  for(const gap of [.7,.8,.9,1,1.2]){
    const duration=1+gap;
    const words=[{word:'antes',start:0,end:.5},{word:'depois',start:.5+gap,end:duration}];
    const cuts=detectVerifiedSilences(words,duration,Array(Math.ceil(duration*100)).fill(1),100,
      {norm:100,speech:words.map(({start,end})=>({start,end})),strength:50,minSilenceSeconds:normalizeSilenceMinimum(null)});
    if(gap<=.9)assert.deepEqual(cuts,[],`preservar ${gap} s`);
    else {assert.equal(cuts.length,1);assert.ok(cuts[0].start>.5&&cuts[0].end<.5+gap);}
  }
});
