import sys
import tempfile
import types
import unittest
from pathlib import Path
from unittest.mock import patch

import magicedit_server as server


class ReviewGroqMockTest(unittest.TestCase):
    def test_optional_review_uses_structured_text_and_caches_without_key(self):
        calls = []
        def create(**kwargs):
            calls.append(kwargs)
            return types.SimpleNamespace(choices=[types.SimpleNamespace(
                message=types.SimpleNamespace(content='{"suggestions":[{"from":1,"to":2,"reason":"fala interrompida e refeita"}]}'))])
        fake = types.ModuleType('groq')
        fake.Groq = lambda **_kwargs: types.SimpleNamespace(
            chat=types.SimpleNamespace(completions=types.SimpleNamespace(create=create)))
        for name in ('RateLimitError', 'AuthenticationError', 'APIStatusError'):
            setattr(fake, name, type(name, (Exception,), {}))
        words = [{'word': token, 'start': i*.5, 'end': i*.5+.3}
                 for i, token in enumerate(['primeira', 'tentativa', 'ruim', 'segunda', 'versao'])]
        states = []
        with tempfile.TemporaryDirectory() as temp, \
                patch.dict(sys.modules, {'groq': fake}), \
                patch.object(server, 'RECENT_PATH', Path(temp) / 'recent.json'), \
                patch.object(server, 'set_job', side_effect=lambda **s: states.append(s)):
            server.background_review_takes(words, 'gsk_dummy-not-real')
            self.assertEqual(len(calls), 1)
            self.assertEqual(calls[0]['model'], 'openai/gpt-oss-20b')
            self.assertTrue(calls[0]['response_format']['json_schema']['strict'])
            self.assertTrue(states[-1]['result']['suggestions'][0]['requiresReview'])
            cache = list((Path(temp) / 'review_cache').glob('*.json'))
            self.assertEqual(len(cache), 1)
            self.assertNotIn('gsk_', cache[0].read_text())
            server.background_review_takes(words, 'gsk_dummy-not-real')
            self.assertEqual(len(calls), 1, 'segunda revisao reutiliza cache')


if __name__ == '__main__':
    unittest.main()
