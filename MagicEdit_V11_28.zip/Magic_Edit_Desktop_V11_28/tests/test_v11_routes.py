import http.client
import json
import subprocess
import sys
import tempfile
import threading
import unittest
from unittest.mock import patch
from http.server import ThreadingHTTPServer
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import magicedit_server as app


class TestV11Routes(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = ThreadingHTTPServer(('127.0.0.1', 0), app.Handler)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()

    def request(self, method, route, data=None):
        conn = http.client.HTTPConnection('127.0.0.1', self.server.server_address[1], timeout=15)
        body = json.dumps(data).encode() if data is not None else None
        conn.request(method, route, body=body, headers={'Content-Type': 'application/json'} if body else {})
        response = conn.getresponse()
        result = response.status, response.getheader('Content-Type'), response.read()
        conn.close()
        return result

    def test_mp4_route_uses_original_media_and_validates_ranges(self):
        media = {'name':'teste.mp4','duration':4,'fpsNum':25,'fpsDen':1}
        with app.LOCK:
            old_file, old_media, old_job = app.STATE['file'], app.STATE['media'], app.STATE['job']
            app.STATE['file'], app.STATE['media'] = '/tmp/original.mp4', media
            app.STATE['job'] = {'state':'done','message':'','done':1,'total':1}
        try:
            with patch.object(app, 'native_file_dialog', return_value='/tmp/resultado.mp4') as dialog, \
                 patch.object(app, 'background_export_mp4') as worker:
                status, _, raw = self.request('POST', '/api/export_mp4', {
                    'segments':[{'in':0,'out':25},{'in':50,'out':75}], 'default':'teste.mp4'})
                self.assertEqual(status, 202)
                self.assertTrue(json.loads(raw)['started'])
                dialog.assert_called_once()
                # A thread despachada recebe o arquivo original e os tempos da edição.
                for _ in range(100):
                    if worker.called: break
                    threading.Event().wait(.001)
                worker.assert_called_once_with('/tmp/original.mp4', media,
                                               [{'in':0,'out':25},{'in':50,'out':75}], '/tmp/resultado.mp4', False)
            with app.LOCK: app.STATE['job'] = {'state':'done','message':'','done':1,'total':1}
            status, _, _ = self.request('POST', '/api/export_mp4', {
                'segments':[{'in':20,'out':25},{'in':22,'out':50}]})
            self.assertEqual(status, 400)
        finally:
            with app.LOCK:
                app.STATE['file'], app.STATE['media'], app.STATE['job'] = old_file, old_media, old_job

    def test_resolve_export_cancel_invalid_ranges_and_busy_guard(self):
        with app.LOCK:
            previous=(app.STATE['file'],app.STATE['media'],app.STATE['job'])
            app.STATE['file']='/tmp/original.mkv'
            app.STATE['media']={'duration':4,'fpsNum':25,'fpsDen':1}
            app.STATE['job']={'state':'idle'}
        try:
            with patch.object(app,'native_file_dialog',return_value=None) as dialog:
                status,_,raw=self.request('POST','/api/export_resolve',{'segments':[{'in':1,'out':25}], 'compatible':True,'default':'a.fcpxml'})
                self.assertEqual(status,200)
                self.assertEqual(json.loads(raw),{'cancelled':True})
                dialog.assert_called_once_with('fcpxml','a.fcpxml')
            with patch.object(app,'native_file_dialog') as dialog:
                for payload in [{'segments':[],'compatible':True},
                                {'segments':[{'in':0,'out':25}],'compatible':'false'}]:
                    self.assertEqual(self.request('POST','/api/export_resolve',payload)[0],400)
                with app.LOCK:app.STATE['job']={'state':'running'}
                self.assertEqual(self.request('POST','/api/export_resolve',{'segments':[{'in':0,'out':25}],'compatible':True})[0],400)
                dialog.assert_not_called()
        finally:
            with app.LOCK:app.STATE['file'],app.STATE['media'],app.STATE['job']=previous

    def test_thumbnail_is_real_jpeg_frame_and_invalid_time_is_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            video = Path(tmp) / 'sample.mp4'
            subprocess.run(['ffmpeg', '-v', 'error', '-f', 'lavfi', '-i', 'color=c=red:s=160x90:r=25:d=2',
                            '-f', 'lavfi', '-i', 'sine=frequency=440:duration=2', '-shortest',
                            '-c:v', 'libx264', '-c:a', 'aac', '-y', str(video)], check=True)
            with app.LOCK:
                app.STATE['file'] = str(video)
                app.STATE['media'] = app.probe_video(str(video))
            status, mime, data = self.request('GET', '/api/thumbnail?t=0.5')
            self.assertEqual(status, 200)
            self.assertEqual(mime, 'image/jpeg')
            self.assertTrue(data.startswith(b'\xff\xd8'))
            self.assertEqual(self.request('GET', '/api/thumbnail?t=999')[0], 400)

    def test_old_schema_one_project_opens_without_transcribing(self):
        with tempfile.TemporaryDirectory() as tmp:
            project = Path(tmp) / 'old.json'
            original = {'schema': 1, 'path': 'C:\\Video\\original.mp4', 'words': [{'word': 'oi', 'start': 0, 'end': 1}], 'deletedIndices': [0]}
            project.write_text(json.dumps(original), encoding='utf-8')
            status, mime, data = self.request('POST', '/api/open_project', {'path': str(project)})
            self.assertEqual(status, 200)
            self.assertEqual(json.loads(data)['text'], project.read_text(encoding='utf-8'))

    def test_recent_projects_persist_in_local_settings(self):
        with tempfile.TemporaryDirectory() as tmp:
            original = app.RECENT_PATH
            app.RECENT_PATH = Path(tmp) / 'recent.json'
            try:
                items = [{'kind': 'project', 'path': '/tmp/existing.json', 'name': 'Edição de ontem'}]
                status, _, _ = self.request('POST', '/api/recent', {'items': items})
                self.assertEqual(status, 200)
                status, _, data = self.request('GET', '/api/recent')
                self.assertEqual(status, 200)
                self.assertEqual(json.loads(data)['items'], items)
                self.assertTrue(app.RECENT_PATH.exists())
            finally:
                app.RECENT_PATH = original

    def test_recent_thumbnail_from_video_or_project_and_remove_history_only(self):
        with tempfile.TemporaryDirectory() as tmp:
            original = app.RECENT_PATH
            app.RECENT_PATH = Path(tmp) / 'recent.json'
            video = Path(tmp) / 'original.mp4'
            project = Path(tmp) / 'editado.json'
            subprocess.run(['ffmpeg', '-v', 'error', '-f', 'lavfi', '-i', 'color=c=blue:s=160x90:r=25:d=2',
                            '-f', 'lavfi', '-i', 'sine=frequency=440:duration=2', '-shortest',
                            '-c:v', 'libx264', '-c:a', 'aac', '-y', str(video)], check=True)
            project.write_text(json.dumps({'schema':1,'path':str(video),'words':[]}),encoding='utf-8')
            items=[{'kind':'video','path':str(video),'name':'original'},
                   {'kind':'project','path':str(project),'name':'editado'}]
            from urllib.parse import quote
            try:
                self.assertEqual(self.request('POST','/api/recent',{'items':items})[0],200)
                for path in (video,project):
                    status,mime,body=self.request('GET','/api/recent_thumbnail?path='+quote(str(path),safe=''))
                    self.assertEqual((status,mime),(200,'image/jpeg'))
                    self.assertTrue(body.startswith(b'\xff\xd8'))
                self.assertEqual(self.request('POST','/api/recent',{'items':[]})[0],200)
                self.assertEqual(self.request('GET','/api/recent_thumbnail?path='+quote(str(video),safe=''))[0],404)
                self.assertTrue(video.is_file())
                self.assertTrue(project.is_file())
            finally:
                app.RECENT_PATH=original


if __name__ == '__main__':
    unittest.main()
