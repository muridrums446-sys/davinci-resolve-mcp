"""Real browser/server/FFmpeg, simulated Gemini; verify expanded cut and restore."""
import argparse,json,os,subprocess,sys,threading
from http.server import ThreadingHTTPServer
from pathlib import Path
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1]
def main():
 p=argparse.ArgumentParser();p.add_argument('--output',required=True,type=Path);out=p.parse_args().output.resolve();out.mkdir(parents=True,exist_ok=True)
 os.environ['APPDATA']=str(out/'settings');sys.path.insert(0,str(ROOT))
 import magicedit_server as app
 import gemini_audio as ga
 from playwright.sync_api import sync_playwright
 video=out/'original.mp4'
 subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i','color=c=blue:s=320x180:r=30:d=7','-f','lavfi','-i','sine=frequency=400:sample_rate=16000:duration=7','-shortest','-c:v','libx264','-preset','ultrafast','-c:a','aac','-y',str(video)],check=True)
 words=[{'word':'anterior.','start':.4,'end':.8}]
 words.extend({'word':w,'start':a,'end':b} for w,a,b in [('vamos',1,1.3),('começar',1.5,1.8),('agora.',2,2.3),('vamos',4.5,4.8),('começar',5,5.3),('agora.',5.5,5.8)])
 doc={'schema':1,'path':str(video),'media':app.probe_video(str(video)),'words':words,'deletedIndices':[],'extraCuts':[{'start':.05,'end':.1}]}
 project=out/'projeto.json';project.write_text(json.dumps(doc));key='fake-comparison-key';errors=[];checks=[]
 def google(api_key,resource,payload=None):
  assert api_key==key
  if resource.startswith('models?'):return {'models':[{'name':'models/gemini-test-flash','supportedGenerationMethods':['generateContent']}]}
  response={'suggestions':[{'start':1,'end':2.3,'kind':'duplicate','spokenText':'vamos começar agora.','reason':'Primeira tentativa repetida na segunda','clear':True,'keepStart':4.5,'keepEnd':5.8,'keepText':'vamos começar agora.'}]}
  return {'candidates':[{'finishReason':'STOP','content':{'parts':[{'text':json.dumps(response)}]}}]}
 def dialog(kind,default=''):
  return str(project if kind=='project' else out/'salvo.json')
 server=ThreadingHTTPServer(('127.0.0.1',0),app.Handler);threading.Thread(target=server.serve_forever,daemon=True).start()
 try:
  with patch.object(app,'native_file_dialog',side_effect=dialog),patch.object(ga,'google_json',side_effect=google),sync_playwright() as pw:
   browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox']);page=browser.new_page(viewport={'width':1366,'height':900});page.on('pageerror',lambda e:errors.append(str(e)))
   page.goto(f'http://127.0.0.1:{server.server_port}/');page.locator('#homeOpen').click();page.wait_for_selector('.word')
   page.locator('#toolsMenu > summary').click();page.locator('#geminiPanel > summary').click();page.locator('#geminiKey').fill(key);page.locator('#geminiModels').click()
   page.wait_for_function('document.querySelectorAll("#geminiModel option").length>1');page.locator('#geminiModel').select_option('gemini-test-flash');page.locator('#geminiConsent').check();page.locator('#geminiAnalyze').click()
   page.wait_for_function('!document.getElementById("geminiAnalyze").disabled',timeout=30000)
   assert '1 novo' in page.locator('#geminiStatus').inner_text()
   page.locator('#toolsMenu > summary').click()
   def save():
    with page.expect_response(lambda r:r.url.endswith('/api/save')):page.locator('#saveProject').click()
    return json.loads((out/'salvo.json').read_text())
   result=save();clean=result['extraCuts'][-1];assert abs(clean['start']-.92)<1e-8 and abs(clean['end']-4.4)<1e-8
   assert 'deleted' not in page.locator('.word[data-idx="0"]').get_attribute('class')
   assert 'deleted' not in page.locator('.word[data-idx="4"]').get_attribute('class')
   assert 'deleted' in page.locator('.word[data-idx="1"]').get_attribute('class')
   checks.append('Expanded cut includes short untranscribed gap; preceding word and retained take remain active')
   page.locator('#loadProject').click();page.wait_for_selector('.word');assert save()['extraCuts']==doc['extraCuts']
   checks.append('Opening the original project does not recalculate or apply a Gemini cut')
   # Reload the saved expanded project and restore its full candidate range.
   project.write_text(json.dumps(result));page.locator('#loadProject').click();page.wait_for_selector('.word')
   page.locator('#toolsMenu > summary').click()
   if not page.locator('#geminiPanel').evaluate('(e)=>e.open'):page.locator('#geminiPanel > summary').click()
   button=page.locator('[data-gemini-toggle]').first;button.click()
   page.locator('#toolsMenu > summary').click();assert save()['extraCuts']==doc['extraCuts']
   checks.append('Restoring the suggestion removes the entire expanded range and preserves a manual cut')
   assert not errors and key not in json.dumps(result)
   (out/'resultado.json').write_text(json.dumps({'checks':checks,'errors':errors,'realBrowser':True,'realFFmpeg':True,'googleTransportSimulated':True,'liveGemini':False},indent=2));browser.close()
 finally:server.shutdown();server.server_close();app.WORKDIR.cleanup()
 print(json.dumps({'checks':len(checks),'errors':errors}))
if __name__=='__main__':main()
