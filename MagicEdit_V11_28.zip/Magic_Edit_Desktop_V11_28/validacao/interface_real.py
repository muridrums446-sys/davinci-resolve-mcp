"""Chromium real + servidor HTTP real. Apenas respostas Groq sao simuladas.
Uso: python validacao/interface_real.py --output PASTA --chromium CAMINHO
Nenhuma chave real, nenhuma chamada de API, nenhuma midia do usuario alterada.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import threading
import time
import types
import xml.etree.ElementTree as ET
from fractions import Fraction
from urllib.parse import unquote, urlparse
from http.server import ThreadingHTTPServer
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--chromium',default=shutil.which('chromium') or shutil.which('chrome'))
    args=parser.parse_args();out=args.output.resolve();out.mkdir(parents=True,exist_ok=True)
    os.environ['APPDATA']=str(out/'settings')
    sys.path.insert(0,str(ROOT))
    import magicedit_server as app
    from playwright.sync_api import sync_playwright
    video=out/'sintetico.mp4'
    subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i','testsrc2=size=320x180:rate=25:duration=16',
                    '-f','lavfi','-i','sine=frequency=440:sample_rate=48000:duration=16','-shortest',
                    '-c:v','libx264','-preset','ultrafast','-c:a','aac','-y',str(video)],check=True)
    video_hash=hashlib.sha256(video.read_bytes()).hexdigest()
    words=[dict(word=t,start=round(1+i*.3,3),end=round(1+i*.3+.23,3)) for i,t in enumerate(
        'hoje vamos explicar os dividendos hoje vamos explicar os dividendos fecha aquela janela agora continuamos nosso investimento aqui'.split())]
    def transcribe(*_):
        app.set_job(state='done',done=1,total=1,message='Transcricao simulada para teste de interface',
                    result={'words':words,'model':'mock-whisper','chunks':1})
    calls=[]
    def completion(**kwargs):
        calls.append(kwargs['model'])
        result={'suggestions':[{'from':10,'to':13,'reason':'Fala lateral sobre o ambiente da gravacao','category':'offtopic','score':.99,'keepFrom':None,'keepTo':None}]}
        return types.SimpleNamespace(choices=[types.SimpleNamespace(message=types.SimpleNamespace(content=json.dumps(result)))])
    import groq
    fake=types.SimpleNamespace(chat=types.SimpleNamespace(completions=types.SimpleNamespace(create=completion)))
    project=out/'antigo.json'
    initial={'schema':1,'autoEditVersion':1,'path':str(video),'projectName':'Projeto antigo preservado',
             'media':app.probe_video(str(video)),'words':words,'deletedIndices':[17],
             'extraCuts':[{'start':7,'end':8}],'playhead':6,'splitFrames':[]}
    project.write_text(json.dumps(initial),'utf-8');project_hash=hashlib.sha256(project.read_bytes()).hexdigest()
    current_project=project
    resolve_exports=0
    def dialog(kind,default=''):
        nonlocal resolve_exports
        if kind=='fcpxml':
            resolve_exports+=1
            return str(out/('original-ref.fcpxml' if resolve_exports==1 else 'timeline.fcpxml'))
        return str(current_project if kind=='project' else video if kind=='video' else
                   out/'editado.mp4' if kind=='mp4' else out/'timeline.fcpxml' if kind=='fcpxml' else out/'timeline.xml' if kind=='xml' else out/'salvo.json')
    srv=ThreadingHTTPServer(('127.0.0.1',0),app.Handler)
    threading.Thread(target=srv.serve_forever,daemon=True).start()
    checks=[];errors=[]
    try:
        with patch.object(app,'native_file_dialog',side_effect=dialog),patch.object(app,'background_transcribe',side_effect=transcribe),patch.object(groq,'Groq',return_value=fake),sync_playwright() as p:
            browser=p.chromium.launch(executable_path=args.chromium,headless=True,args=['--no-sandbox'])
            page=browser.new_page(viewport={'width':1366,'height':768})
            page.on('pageerror',lambda error:errors.append(str(error)))
            page.on('dialog',lambda d:d.accept())
            page.goto(f'http://127.0.0.1:{srv.server_port}/')
            page.locator('#homeOpen').click();page.wait_for_selector('.word[data-idx="0"]')
            for button in ['#exportXml','#exportMp4','#toolsMenu']:
                rect=page.locator(button).bounding_box()
                assert rect['x']>=0 and rect['x']+rect['width']<=1366,('Botao fora da tela',button,rect)
            page.locator('#saveProject').click();page.wait_for_function('document.getElementById("autosaveStatus").textContent.length>0')
            saved=json.loads((out/'salvo.json').read_text('utf-8'))
            assert saved['deletedIndices']==[17] and saved['extraCuts']==initial['extraCuts']
            assert saved['words']==initial['words'] and calls==[]
            assert saved['silenceMinSeconds']==.9,'limite padrao acordado deve acompanhar o projeto'
            checks.append('Projeto antigo: texto e cortes preservados, sem Groq')
            page.locator('#toolsMenu > summary').click()
            assert page.locator('#silenceMinSeconds').input_value()=='0.9'
            page.locator('#silenceMinSeconds').fill('1.1')
            with page.expect_response(lambda r:r.url.endswith('/api/save')):page.locator('#saveProject').click()
            changed_limit=json.loads((out/'salvo.json').read_text('utf-8'))
            assert changed_limit['silenceMinSeconds']==1.1
            assert changed_limit['extraCuts']==initial['extraCuts'] and changed_limit['deletedIndices']==[17]
            page.locator('#silenceMinSeconds').fill('0.9')
            page.locator('#toolsMenu > summary').click()
            checks.append('Campo de limite editado pela interface e salvo no JSON, sem mudar cortes existentes')
            page.locator('#toolsMenu > summary').click();page.locator('#autoRoughCut').click()
            page.locator('#toolsMenu > summary').click();page.locator('#saveProject').click();page.wait_for_timeout(100)
            edited_old=json.loads((out/'salvo.json').read_text('utf-8'))
            assert set(edited_old['deletedIndices'])==set(range(5))|{17}
            assert calls==[]
            page.keyboard.press('Control+z')
            checks.append('Reeditar JSON existente aplica duplicata e preserva corte manual, sem retranscrever')
            page.locator('#backHome').click();page.locator('#homeImport').click()
            page.locator('#homeApiKey').fill('gsk_offline-test-not-a-real-key')
            page.locator('#homeStart').click()
            page.wait_for_function('!document.body.classList.contains("home-open")',timeout=30000)
            page.locator('#saveProject').click()
            page.wait_for_timeout(150)
            saved=json.loads((out/'salvo.json').read_text('utf-8'))
            assert set(saved['deletedIndices'])==set(range(5))|set(range(10,14)),saved['deletedIndices']
            assert len(calls)==1,calls
            assert 'gsk_' not in (out/'salvo.json').read_text('utf-8')
            checks.append('Importacao edita duplicata e contexto automaticamente; Groq simulado e chave nao persistida')
            page.locator('.word[data-idx="14"]').click()
            assert page.locator('#player').evaluate('(p)=>p.paused')
            assert abs(page.locator('#player').evaluate('(p)=>p.currentTime')-words[14]['start'])<.04
            checks.append('Clique na palavra posiciona e pausa')
            page.locator('.word[data-idx="0"]').click(button='right')
            assert page.locator('.word.deleted').count()==4
            page.keyboard.press('Control+z')
            assert page.locator('.word.deleted').count()==9
            checks.append('Restauracao por clique direito e Ctrl+Z')
            page.locator('#player').evaluate('(p)=>{p.currentTime=.8;p.play()}')
            page.wait_for_timeout(700)
            assert page.locator('#player').evaluate('(p)=>p.currentTime')>2.5
            assert not page.locator('#player').evaluate('(p)=>p.muted')
            page.locator('#player').evaluate('(p)=>p.pause()')
            checks.append('Reproducao salta o corte e restaura o audio')
            page.screenshot(path=str(out/'editor.png'),full_page=True)
            page.locator('#toolsMenu > summary').click()
            page.locator('#toolsMenu details.tool-section').filter(has=page.locator('#autoSuggestions')).locator(':scope > summary').click()
            page.screenshot(path=str(out/'cortes-auditaveis.png'),full_page=True)
            page.locator('#toolsMenu > summary').click()
            # Atalho depois de clicar em botoes; Enter permanece disponivel para acoes.
            page.locator('#player').evaluate('(p)=>{p.pause();p.currentTime=10;}')
            for selector in ['#zoomFit','#followSpeech','.speeds button[data-speed="1"]']:
                page.locator(selector).click();page.keyboard.press('Space')
                page.wait_for_function('!document.getElementById("player").paused')
                page.keyboard.press('Space');page.wait_for_timeout(100)
                assert page.locator('#player').evaluate('(p)=>p.paused'),selector
            page.locator('#player').focus();page.keyboard.press('Space')
            page.wait_for_function('!document.getElementById("player").paused')
            page.keyboard.press('Space');page.wait_for_timeout(100)
            assert page.locator('#player').evaluate('(p)=>p.paused')
            page.locator('#zoomIn').click();page.locator('#timelinePan').focus()
            page.keyboard.press('Space');page.wait_for_function('!document.getElementById("player").paused')
            page.keyboard.press('Space');page.wait_for_timeout(100)
            assert page.locator('#player').evaluate('(p)=>p.paused')
            page.locator('#zoomFit').click()
            page.locator('#zoomFit').focus();page.keyboard.down('Space');page.keyboard.down('Space')
            page.wait_for_function('!document.getElementById("player").paused')
            page.keyboard.up('Space');page.keyboard.press('Space')
            assert page.locator('#player').evaluate('(p)=>p.paused')
            page.locator('#projectNameInput').focus();page.keyboard.press('Space')
            assert page.locator('#player').evaluate('(p)=>p.paused')
            page.locator('#player').evaluate('''(p)=>{p.currentTime=1.2;
              window.dispatchEvent(new KeyboardEvent('keydown',{key:' ',code:'Space',bubbles:true}));
              window.dispatchEvent(new KeyboardEvent('keydown',{key:' ',code:'Space',bubbles:true}));}''')
            page.wait_for_timeout(200)
            assert page.locator('#player').evaluate('(p)=>p.paused&&!p.muted')
            checks.append('Espaco inicia/pausa apos botoes, ignora repeticao, preserva digitacao e cancela retomada durante salto')
            # Padrao usa o bruto original completo, como o Gling.
            page.locator('#exportXml').click()
            page.wait_for_function('document.getElementById("mp4ProgressTrack").getAttribute("aria-valuenow")==="100"',timeout=60000)
            original_xml=ET.parse(out/'original-ref.fcpxml')
            assert original_xml.find('./resources/asset/media-rep').get('src')==video.as_uri()
            assert not (out/'original-ref.media.mp4').exists()
            checks.append('FCPXML padrao aponta ao original completo, sem converter nem concatenar o video')
            # Opcao de compatibilidade tambem usa a fonte completa, nunca o MP4 cortado.
            page.locator('#toolsMenu > summary').click()
            page.locator('#toolsMenu details.tool-section').filter(has=page.locator('#resolveCompatible')).locator(':scope > summary').click()
            page.locator('#resolveCompatible').check()
            page.locator('#exportXml').click()
            page.wait_for_function('document.getElementById("mp4ProgressTrack").getAttribute("aria-valuenow")==="100"',timeout=60000)
            xml=ET.parse(out/'timeline.fcpxml')
            assert xml.getroot().get('version')=='1.9'
            clips=xml.findall('.//spine/asset-clip');assert len(clips)>1
            asset=xml.find('./resources/asset');assert asset.get('hasAudio')==asset.get('hasVideo')=='1'
            uri=asset.find('media-rep').get('src')
            assert Path(unquote(urlparse(uri).path))==out/'timeline.media.mp4'
            cursor=Fraction(0)
            for clip in clips:
                assert Fraction(clip.get('offset')[:-1])==cursor
                cursor+=Fraction(clip.get('duration')[:-1])
            expected=float(cursor)
            master_probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-of','json',str(out/'timeline.media.mp4')]))
            assert next(s for s in master_probe['streams'] if s['codec_type']=='video')['nb_frames']=='400'
            assert str(out/'timeline.fcpxml') in page.locator('#mp4FinalPath').inner_text()
            checks.append('FCPXML 1.9 via interface: clipes contiguos, offsets exatos, master completo com 400 frames')
            page.screenshot(path=str(out/'resolve-exportado.png'),full_page=True)
            page.locator('#exportMp4').click()
            page.wait_for_function('document.getElementById("mp4ProgressTrack").getAttribute("aria-valuenow")==="100"',timeout=60000)
            probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(out/'editado.mp4')]))
            assert {s['codec_type'] for s in probe['streams']}=={'audio','video'}
            assert abs(float(probe['format']['duration'])-expected)<.15
            checks.append('MP4 unico renderizado por FFmpeg via interface; duracao concorda com XML')
            page.screenshot(path=str(out/'mp4-concluido.png'),full_page=True)
            # Arrasto direto em cada faixa, em ambas as direcoes: sem ativar modo.
            for surface in ['timeline','timelineRuler','filmstrip']:
                for first,last in [(5.18,6.08),(6.08,5.18)]:
                    rect=page.locator('#'+surface).bounding_box()
                    y=rect['y']+rect['height']/2
                    page.mouse.move(rect['x']+rect['width']*first/16,y);page.mouse.down()
                    page.mouse.move(rect['x']+rect['width']*last/16,y,steps=12);page.mouse.up()
                    assert page.locator('#deleteRange').is_enabled(),surface
                    page.mouse.click(rect['x']+rect['width']*10/16,y,button='right')
                    for idx in [14,15,16]:assert 'deleted' in page.locator(f'.word[data-idx="{idx}"]').get_attribute('class'),(surface,idx)
                    assert 'deleted' not in page.locator('.word[data-idx="17"]').get_attribute('class')
                    assert page.locator('#rangeSelection').is_visible()
                    assert 'Restaurar' in page.locator('#deleteRange').inner_text()
                    page.mouse.click(rect['x']+rect['width']*10/16,y,button='right')
                    assert 'deleted' not in page.locator('.word[data-idx="14"]').get_attribute('class')
                    page.mouse.click(rect['x']+rect['width']*10/16,y,button='right')
                    assert 'deleted' in page.locator('.word[data-idx="14"]').get_attribute('class')
                    page.keyboard.press('Control+z')
                    assert 'deleted' not in page.locator('.word[data-idx="14"]').get_attribute('class')
            checks.append('Arrasto X-Y e Y-X: direito corta/restaura/corta a mesma selecao nas tres faixas; Ctrl+Z restaura')
            # Um intervalo sem palavra cria marcador restauravel na transcricao.
            rect=page.locator('#timeline').bounding_box();y=rect['y']+rect['height']/2
            page.mouse.move(rect['x']+rect['width']*8/16,y);page.mouse.down()
            page.mouse.move(rect['x']+rect['width']*9.5/16,y,steps=10);page.mouse.up();page.keyboard.press('Delete')
            page.locator('.cut-marker').first.click()
            assert page.locator('.cut-marker').count()==0
            checks.append('Intervalo sem texto cortado manualmente e restaurado pelo marcador na transcricao')
            page.screenshot(path=str(out/'selecao-manual.png'),full_page=True)
            # Documento longo: exercitar rolagem e selecao nativa, nao DOM simulado.
            long_words=[dict(word=f'palavra{i}',start=i*.002,end=i*.002+.0015) for i in range(6848)]
            long_project={**initial,'autoEditVersion':2,'words':long_words,'deletedIndices':[],'extraCuts':[],'playhead':0}
            current_project=out/'longo.json';current_project.write_text(json.dumps(long_project),'utf-8')
            page.locator('#loadProject').click();page.wait_for_function('document.querySelectorAll(".word").length===6848')
            target=page.locator('.word[data-idx="6000"]');target.click()
            assert abs(page.locator('#player').evaluate('(p)=>p.currentTime')-12)<.04
            page.locator('#player').evaluate('(p)=>p.play()');page.wait_for_timeout(200)
            assert page.locator('#followSpeech').get_attribute('aria-pressed')=='true'
            page.locator('#transcript').hover();page.mouse.wheel(0,-350);page.wait_for_timeout(100)
            assert page.locator('#followSpeech').get_attribute('aria-pressed')=='false'
            page.locator('#player').evaluate('(p)=>p.pause()')
            checks.append('6848 palavras: clique distante, acompanhamento e pausa ao rolar manualmente')
            assert not errors,errors
            assert hashlib.sha256(video.read_bytes()).hexdigest()==video_hash
            assert hashlib.sha256(project.read_bytes()).hexdigest()==project_hash
            checks.append('Midia sintetica e JSON de entrada intactos; nenhum erro JavaScript')
            # Minimo de tres palavras no fluxo real, preservando a ultima tomada.
            short_words=[dict(word=w,start=1+i*.4,end=1+i*.4+.3) for i,w in enumerate('vamos começar agora vamos começar agora fim'.split())]
            current_project=out/'regra-tres.json'
            current_project.write_text(json.dumps({**initial,'words':short_words,'deletedIndices':[],'extraCuts':[],'playhead':0,'silenceMinSeconds':.7}),'utf-8')
            page.locator('#backHome').click();page.locator('#fullAutoEdit').uncheck();page.locator('#homeOpen').click()
            page.wait_for_function('document.querySelectorAll(".word").length===7')
            assert page.locator('.word.deleted').count()==0
            page.locator('#toolsMenu > summary').click();page.locator('#autoRoughCut').click()
            for idx in range(3):assert 'deleted' in page.locator(f'.word[data-idx="{idx}"]').get_attribute('class')
            for idx in range(3,7):assert 'deleted' not in page.locator(f'.word[data-idx="{idx}"]').get_attribute('class')
            page.locator('#toolsMenu > summary').click()
            page.locator('.word[data-idx="0"]').click(button='right')
            assert page.locator('.word.deleted').count()==0
            assert not errors,errors
            checks.append('Tres palavras iguais: primeira tentativa riscada, ultima ativa e clique direito restaura')
            browser.close()
        result={'environment':'Linux cloud / Chromium real / FFmpeg real','groq':'mocked; no live API calls',
                'checks':checks,'javascript_errors':errors,'mp4_duration':float(probe['format']['duration']),
                'xml_duration':expected,'windows_tested':False,'davinci_import_tested':False}
        (out/'resultado-interface.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),'utf-8')
        print(json.dumps(result,ensure_ascii=False,indent=2))
    finally:srv.shutdown();srv.server_close();app.WORKDIR.cleanup()

if __name__=='__main__':main()
