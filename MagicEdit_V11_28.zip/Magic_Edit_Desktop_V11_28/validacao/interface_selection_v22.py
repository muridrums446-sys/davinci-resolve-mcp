"""Chromium + HTTP + FFmpeg reais; somente os seletores nativos de arquivo simulados."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import threading
from http.server import ThreadingHTTPServer
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();out=args.output.resolve();out.mkdir(parents=True,exist_ok=True)
    os.environ['APPDATA']=str(out/'settings');sys.path.insert(0,str(ROOT))
    import magicedit_server as app
    from playwright.sync_api import sync_playwright
    source=out/'original.mp4'
    pattern="color=c=red:s=1280x720:r=25:d=6,drawbox=c=green:t=fill:enable='between(t,1.5,3)',drawbox=c=blue:t=fill:enable='gte(t,3)'"
    subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i',pattern,'-f','lavfi','-i',
        'sine=frequency=440:sample_rate=48000:duration=6','-shortest','-c:v','libx264',
        '-preset','ultrafast','-c:a','aac','-y',str(source)],check=True)
    source_hash=hashlib.sha256(source.read_bytes()).hexdigest()
    initial={'schema':1,'path':str(source),'media':app.probe_video(str(source)),
        'projectName':'Trecho para analisar','words':[{'word':'tentativa','start':2.2,'end':2.8},
        {'word':'retomada','start':3.2,'end':3.8}],'deletedIndices':[0],
        'extraCuts':[{'start':2,'end':4}],'silenceMinSeconds':.7}
    project=out/'antigo.json';project.write_text(json.dumps(initial),'utf-8')
    project_hash=hashlib.sha256(project.read_bytes()).hexdigest()
    current_project=project;next_output=out/'selecao-leve.mp4';cancel_next=False;dialog_calls=[]
    def dialog(kind,default=''):
        nonlocal cancel_next
        dialog_calls.append((kind,default))
        if kind=='project':return str(current_project)
        if kind=='json':return str(out/'salvo.json')
        if kind=='mp4':
            if cancel_next:cancel_next=False;return None
            return str(next_output)
        raise AssertionError(kind)
    def probe(path):
        return json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(path)]))
    def rgb(path,time):
        return list(subprocess.check_output(['ffmpeg','-v','error','-ss',str(time),'-i',str(path),
            '-frames:v','1','-vf','scale=1:1','-pix_fmt','rgb24','-f','rawvideo','-']))
    server=ThreadingHTTPServer(('127.0.0.1',0),app.Handler)
    threading.Thread(target=server.serve_forever,daemon=True).start()
    checks=[];errors=[];payloads=[]
    try:
        with patch.object(app,'native_file_dialog',side_effect=dialog),sync_playwright() as p:
            browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
            page=browser.new_page(viewport={'width':1366,'height':900})
            page.add_init_script("localStorage.setItem('magicedit.silenceMin.v11','0.7')")
            page.on('pageerror',lambda e:errors.append(str(e)))
            page.on('request',lambda r:payloads.append(r.post_data_json) if r.url.endswith('/api/export_mp4') else None)
            page.goto(f'http://127.0.0.1:{server.server_port}/')
            assert page.locator('#exportSelection').is_disabled()
            page.locator('#homeOpen').click();page.wait_for_selector('.word')
            assert page.locator('#silenceMinSeconds').input_value()=='0.9'
            assert page.locator('#exportSelection').is_disabled()
            checks.append('Preferencia antiga 0,7 e JSON antigo migram campo para 0,9 sem recalcular cortes')
            def save():
                with page.expect_response(lambda r:r.url.endswith('/api/save')):page.locator('#saveProject').click()
                return json.loads((out/'salvo.json').read_text())
            saved=save();assert saved['deletedIndices']==[0] and saved['extraCuts']==initial['extraCuts']
            def select(start,end,selector='#timeline'):
                page.locator(selector).scroll_into_view_if_needed();box=page.locator(selector).bounding_box()
                page.mouse.move(box['x']+box['width']*start/6,box['y']+box['height']/2)
                page.mouse.down();page.mouse.move(box['x']+box['width']*end/6,box['y']+box['height']/2,steps=12);page.mouse.up()
                assert not page.locator('#exportSelection').is_disabled()
            select(2,4)
            before=save()
            page.locator('#exportSelection').click()
            assert page.locator('#exportSelection').is_disabled()
            page.wait_for_function('!document.getElementById("exportSelection").disabled',timeout=30000)
            assert next_output.is_file(),page.locator('#mp4Progress').inner_text()
            request=payloads[-1];assert request['analysisClip'] is True
            segment,=request['segments'];assert abs(segment['in']-50)<=1 and abs(segment['out']-100)<=1,segment
            data=probe(next_output);video=next(s for s in data['streams'] if s['codec_type']=='video')
            audio=next(s for s in data['streams'] if s['codec_type']=='audio')
            expected=(segment['out']-segment['in'])/25
            assert abs(float(data['format']['duration'])-expected)<.15
            assert video['width']<=854 and video['height']<=480 and audio['channels']==1
            assert int(audio['sample_rate'])==16000
            assert abs(float(video['start_time'])-float(audio['start_time']))<.1
            # Verde na primeira metade e azul na segunda: fonte correta, incluindo corte.
            first,last=rgb(next_output,.3),rgb(next_output,1.6)
            assert first[1]>first[0]+50 and first[1]>first[2]+50,first
            assert last[2]>last[0]+50 and last[2]>last[1]+50,last
            pcm=subprocess.check_output(['ffmpeg','-v','error','-i',str(next_output),'-vn','-f','s16le','-'])
            assert any(pcm),'audio nao pode estar vazio'
            assert save()==before
            assert page.locator('#rangeSelection').is_visible()
            assert str(next_output)==page.locator('#mp4FinalPath').inner_text()
            checks.append('Exportacao real do intervalo do original inclui partes riscadas; fonte verde/azul correta, audio presente, A/V sincronizados e projeto/seleção preservados')
            page.screenshot(path=str(out/'exportacao-selecao.png'),full_page=True)
            clip_bytes=next_output.stat().st_size
            # Cancelar nao inicia job nem perde selecao; original exportado continua preservado.
            cancel_next=True
            with page.expect_response(lambda r:r.url.endswith('/api/export_mp4')) as response:page.locator('#exportSelection').click()
            assert response.value.json().get('cancelled') is True
            page.wait_for_function('!document.getElementById("exportSelection").disabled')
            assert save()==before
            checks.append('Cancelar destino preserva selecao/projeto e reabilita o botao')
            # Exportar novamente para o mesmo nome informa erro, preservando o MP4 anterior.
            previous_hash=hashlib.sha256(next_output.read_bytes()).hexdigest()
            page.locator('#exportSelection').click()
            page.wait_for_function('!document.getElementById("exportSelection").disabled',timeout=30000)
            assert 'existe' in page.locator('#mp4Progress').inner_text()
            assert hashlib.sha256(next_output.read_bytes()).hexdigest()==previous_hash
            checks.append('Arquivo exportado existente nao e sobrescrito e erro permite tentar outro destino')
            # O clique direito continua alternando cortar/restaurar apos exportar.
            page.locator('#timeline').click(button='right')
            assert page.locator('#deleteRange').inner_text().find('Cortar')>=0
            page.locator('#timeline').click(button='right')
            assert page.locator('#deleteRange').inner_text().find('Restaurar')>=0
            page.locator('#clearRange').click();assert page.locator('#exportSelection').is_disabled()
            checks.append('Direito continua restaurando/cortando; limpar selecao desabilita exportacao')
            # Arrasto reverso na regua funciona sem palavras/transcricao.
            blank={**initial,'words':[],'deletedIndices':[],'extraCuts':[],'silenceMinSeconds':1.2}
            current_project=out/'sem-transcricao.json';current_project.write_text(json.dumps(blank))
            page.locator('#loadProject').click();page.wait_for_function('document.getElementById("silenceMinSeconds").value==="1.2"')
            assert page.locator('#exportSelection').is_disabled()
            select(4,2,'#timelineRuler');next_output=out/'sem-texto-leve.mp4'
            page.locator('#exportSelection').click()
            page.wait_for_function('!document.getElementById("exportSelection").disabled',timeout=30000)
            assert next_output.is_file() and 1.9<float(probe(next_output)['format']['duration'])<2.2
            checks.append('Arrasto reverso na regua exporta sem palavras; limite personalizado 1,2 preservado')
            # Um unico frame via arrasto tambem exporta A/V.
            page.locator('#clearRange').click();select(0,.04);next_output=out/'um-frame-leve.mp4'
            page.locator('#exportSelection').click()
            page.wait_for_function('!document.getElementById("exportSelection").disabled',timeout=30000)
            assert next_output.is_file(),page.locator('#mp4Progress').inner_text()
            assert float(probe(next_output)['format']['duration'])<.2
            checks.append('Selecao de aproximadamente um frame gera MP4 valido')
            calls_before=len(dialog_calls)
            bad=page.request.post(f'http://127.0.0.1:{server.server_port}/api/export_mp4',data={'segments':[{'in':0,'out':25}],'analysisClip':'yes'})
            assert bad.status>=400 and len(dialog_calls)==calls_before
            checks.append('API rejeita perfil invalido antes de abrir destino')
            # Ajuste manual novo 0,7 deve sobreviver a salvar/reabrir; apenas o padrao antigo migra.
            current_project=project;page.locator('#loadProject').click();page.wait_for_selector('.word')
            page.locator('#toolsMenu > summary').click()
            page.locator('#silenceMinSeconds').fill('0.7')
            page.locator('#toolsMenu > summary').click()
            custom=save();assert custom['silenceMinSeconds']==.7 and custom['silenceSettingsVersion']==22
            current_project=out/'salvo.json';page.locator('#loadProject').click()
            page.wait_for_function('document.getElementById("silenceMinSeconds").value==="0.7"')
            checks.append('Limite ajustado manualmente na V11.22 persiste apos salvar e reabrir, inclusive 0,7 s')
            for width in (1366,1024):
                page.set_viewport_size({'width':width,'height':900});page.wait_for_timeout(100)
                rect=page.locator('#exportSelection').bounding_box()
                assert rect['x']>=0 and rect['x']+rect['width']<=width,(width,rect)
                assert page.evaluate('document.documentElement.scrollWidth')<=width
            assert not errors,errors
            assert hashlib.sha256(source.read_bytes()).hexdigest()==source_hash
            assert hashlib.sha256(project.read_bytes()).hexdigest()==project_hash
            checks.append('Botao acessivel em 1366 e 1024 px; nenhum erro JS; original e JSON de entrada intactos')
            (out/'resultado.json').write_text(json.dumps({'checks':checks,'clipBytes':clip_bytes,'clipDuration':expected,
                'javascriptErrors':errors,'realChromium':True,'realFFmpeg':True,'nativeDialogsMocked':True,
                'realGroqCalls':False,'windowsValidated':False,'davinciValidated':False},ensure_ascii=False,indent=2))
            browser.close()
    finally:
        server.shutdown();server.server_close();app.WORKDIR.cleanup()
    print(json.dumps({'checks':len(checks),'clipBytes':clip_bytes,'clipDuration':expected,'errors':errors}))

if __name__=='__main__':main()
