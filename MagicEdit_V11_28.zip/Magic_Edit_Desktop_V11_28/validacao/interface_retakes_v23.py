"""Retomadas: Chromium/HTTP/FFmpeg reais, texto original com tempos rebaseados e midia sintetica."""
import argparse,hashlib,json,os,subprocess,sys,threading
from pathlib import Path
from http.server import ThreadingHTTPServer
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1]
def main():
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);args=p.parse_args()
 out=args.output.resolve();out.mkdir(parents=True,exist_ok=True);os.environ['APPDATA']=str(out/'settings');sys.path.insert(0,str(ROOT))
 import magicedit_server as app
 from playwright.sync_api import sync_playwright
 video=out/'sintetico.mp4'
 subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i','color=c=blue:s=320x180:r=25:d=40','-f','lavfi','-i',
  'sine=frequency=440:sample_rate=48000:duration=40','-shortest','-c:v','libx264','-preset','ultrafast','-c:a','aac','-y',str(video)],check=True)
 original_hash=hashlib.sha256(video.read_bytes()).hexdigest()
 cases=json.loads((ROOT/'tests/fixtures/retakes_v23.json').read_text())['cases'];current=None;errors=[];checks=[];inputs={}
 def dialog(kind,default=''):
  if kind=='project':return str(current)
  if kind=='json':return str(out/'salvo.json')
  if kind=='fcpxml':return str(out/'retomadas.fcpxml')
  raise AssertionError(kind)
 server=ThreadingHTTPServer(('127.0.0.1',0),app.Handler);threading.Thread(target=server.serve_forever,daemon=True).start()
 try:
  with patch.object(app,'native_file_dialog',side_effect=dialog),sync_playwright() as pw:
   browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
   page=browser.new_page(viewport={'width':1366,'height':900});page.on('pageerror',lambda e:errors.append(str(e)))
   page.goto(f'http://127.0.0.1:{server.server_port}/')
   def save():
    with page.expect_response(lambda r:r.url.endswith('/api/save')):page.locator('#saveProject').click()
    return json.loads((out/'salvo.json').read_text())
   for k,case in enumerate(cases):
    offset=case['words'][0]['start']-1
    words=[{**w,'start':round(w['start']-offset,4),'end':round(w['end']-offset,4)} for w in case['words']]
    doc={'schema':1,'autoEditVersion':4,'path':str(video),'media':app.probe_video(str(video)),
     'projectName':case['name'],'words':words,'deletedIndices':[],'extraCuts':[{'start':.1,'end':.2}],
     'silenceMinSeconds':.9,'silenceSettingsVersion':22}
    current=out/(case['name']+'.json');current.write_text(json.dumps(doc));inputs[current]=hashlib.sha256(current.read_bytes()).hexdigest()
    page.locator('#homeOpen' if k==0 else '#loadProject').click();page.wait_for_selector('.word')
    opened=save();assert opened['deletedIndices']==[] and opened['extraCuts']==doc['extraCuts']
    page.locator('#toolsMenu > summary').click();page.locator('#autoRoughCut').click();page.locator('#toolsMenu > summary').click()
    edited=save();assert edited['deletedIndices']==case['remove'],(case['name'],edited['deletedIndices'])
    assert all(i not in edited['deletedIndices'] for i in case['keep'])
    assert all(page.locator(f'.word[data-idx="{i}"]').get_attribute('class').find('deleted')>=0 for i in case['remove'])
    assert all(page.locator(f'.word[data-idx="{i}"]').get_attribute('class').find('deleted')<0 for i in case['keep'])
    assert {'start':.1,'end':.2} in edited['extraCuts']
    assert edited['autoEditVersion']==5
    checks.append(case['name']+': abre preservado, reeditando risca toda tentativa e mantem ultima fala/corte manual')
    page.locator(f'.word[data-idx="{case["remove"][0]}"]').click(button='right')
    assert save()['deletedIndices']==[]
    page.keyboard.press('Control+z');assert save()['deletedIndices']==case['remove']
    checks.append(case['name']+': clique direito restaura e Ctrl+Z retorna corte completo')
   page.screenshot(path=str(out/'retomadas.png'),full_page=True)
   page.locator('#exportXml').click();page.wait_for_function('!document.getElementById("exportXml").disabled',timeout=30000)
   text=(out/'retomadas.fcpxml').read_text();assert '<fcpxml version="1.9"' in text and 'sintetico.mp4' in text
   checks.append('FCPXML continua exportando cortes editaveis com referencia ao bruto completo')
   assert not errors,errors
   assert hashlib.sha256(video.read_bytes()).hexdigest()==original_hash
   for path,value in inputs.items():assert hashlib.sha256(path.read_bytes()).hexdigest()==value
   checks.append('Projetos de entrada e midia sintetica intactos, nenhum erro JS ou chamada real Groq')
   (out/'resultado.json').write_text(json.dumps({'checks':checks,'errors':errors,'realChromium':True,'realFFmpeg':True,
    'source':'palavras/tempos do JSON original, rebaseados para midia sintetica; nao e o MP4 recebido',
    'nativeFileDialogsMocked':True,'realGroqCalls':False,'windowsValidated':False,'davinciValidated':False},ensure_ascii=False,indent=2))
   browser.close()
 finally:server.shutdown();server.server_close();app.WORKDIR.cleanup()
 print(json.dumps({'checks':len(checks),'errors':errors}))
if __name__=='__main__':main()
