"""Real Chromium/HTTP/FFmpeg; only native dialog and Google transport simulated."""
import argparse,base64,hashlib,io,json,os,subprocess,sys,threading
from pathlib import Path
from http.server import ThreadingHTTPServer
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1]
def main():
 parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
 out=args.output.resolve();out.mkdir(parents=True,exist_ok=True);os.environ['APPDATA']=str(out/'settings');sys.path.insert(0,str(ROOT))
 import magicedit_server as app
 import gemini_audio as ga
 from urllib.error import HTTPError
 original_google=ga.google_json
 from playwright.sync_api import sync_playwright
 video=out/'original.mp4';subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i','color=c=blue:s=320x180:r=25:d=10',
  '-f','lavfi','-i','sine=frequency=440:sample_rate=16000:duration=10','-shortest','-c:v','libx264','-preset','ultrafast','-c:a','aac','-y',str(video)],check=True)
 media=app.probe_video(str(video));original=hashlib.sha256(video.read_bytes()).hexdigest()
 words=[{'word':w,'start':1+i*.5,'end':1.3+i*.5} for i,w in enumerate('vamos começar agora vamos começar agora continuamos falando de investimentos'.split())]
 doc={'schema':1,'path':str(video),'media':media,'words':words,'deletedIndices':[],'extraCuts':[{'start':.1,'end':.2}],'projectName':'Teste de audio','silenceMinSeconds':.9,'silenceSettingsVersion':22}
 project=out/'entrada.json';project.write_text(json.dumps(doc));sourcehash=hashlib.sha256(project.read_bytes()).hexdigest()
 key='fake.token:with/symbols+and=padding_-';calls=[];checks=[];errors=[];failure=False;retained_attempt=False
 def google(api_key,resource,payload=None):
  nonlocal failure
  assert api_key==key
  if resource.startswith('models?'):return {'models':[{'name':'models/gemini-test-flash','displayName':'Gemini teste','supportedGenerationMethods':['generateContent']}]}
  calls.append(payload)
  if failure in {'timeout','503','reset'}:
   class Fail:
    def open(self,*a,**kw):
     if failure=='timeout':raise TimeoutError(key)
     if failure=='reset':raise ConnectionResetError(key)
     raise HTTPError('https://x',503,key,{},io.BytesIO(key.encode()))
   with patch.object(ga,'build_opener',return_value=Fail()):
    return original_google(api_key,resource,payload)
  if failure:raise RuntimeError('Limite de cota Gemini atingido; tente depois.')
  assert base64.b64decode(payload['contents'][0]['parts'][1]['inlineData']['data']).startswith(b'fLaC')
  result={'suggestions':[{'start':1,'end':2.3,'kind':'duplicate','spokenText':'vamos começar agora','reason':'Primeira tentativa repetida na segunda','clear':True,'keepStart':2.5,'keepEnd':3.8,'keepText':'vamos começar agora'},
                        {'start':.3,'end':.7,'kind':'offtopic','spokenText':'fala sem texto','reason':'Conversa lateral sem palavras reconhecidas','clear':True,'keepStart':None,'keepEnd':None,'keepText':''}]}
  if retained_attempt:result={'suggestions':[{'start':2.5,'end':3.8,'kind':'offtopic','spokenText':'vamos começar agora','reason':'Sugestao posterior invade a tomada antes mantida','clear':True,'keepStart':None,'keepEnd':None,'keepText':''}]}
  return {'candidates':[{'finishReason':'STOP','content':{'parts':[{'text':json.dumps(result)}]}}]}
 current=project
 def dialog(kind,default=''):
  if kind=='project':return str(current)
  if kind=='json':return str(out/'salvo.json')
  if kind=='fcpxml':return str(out/'saida.fcpxml')
  if kind=='mp4':return str(out/'saida.mp4')
  raise AssertionError(kind)
 server=ThreadingHTTPServer(('127.0.0.1',0),app.Handler);threading.Thread(target=server.serve_forever,daemon=True).start()
 try:
  with patch.object(app,'native_file_dialog',side_effect=dialog),patch.object(ga,'google_json',side_effect=google),sync_playwright() as pw:
   browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox']);page=browser.new_page(viewport={'width':1366,'height':900});page.on('pageerror',lambda e:errors.append(str(e)))
   page.goto(f'http://127.0.0.1:{server.server_port}/');page.locator('#homeOpen').click();page.wait_for_selector('.word')
   assert page.locator('#geminiKey').count()==1,'Gemini controls missing'
   def save():
    with page.expect_response(lambda r:r.url.endswith('/api/save')):page.locator('#saveProject').click()
    return json.loads((out/'salvo.json').read_text())
   assert save()['extraCuts']==doc['extraCuts'];assert not calls
   checks.append('Abrir projeto preserva cortes e nao envia audio')
   page.locator('#toolsMenu > summary').click();page.locator('#geminiPanel > summary').click()
   page.locator('#geminiKey').fill(key);page.locator('#geminiModels').click()
   page.wait_for_function('document.querySelectorAll("#geminiModel option").length>1');page.locator('#geminiModel').select_option('gemini-test-flash')
   page.locator('#geminiAnalyze').click();assert not calls
   checks.append('Lista modelos; sem consentimento nao envia audio')
   page.locator('#geminiConsent').check();page.locator('#geminiAnalyze').click()
   page.wait_for_function('!document.getElementById("geminiAnalyze").disabled',timeout=30000)
   assert len(calls)==1
   assert 'deleted' in page.locator('.word[data-idx="0"]').get_attribute('class')
   assert 'deleted' not in page.locator('.word[data-idx="3"]').get_attribute('class')
   page.locator('#geminiStatus').scroll_into_view_if_needed();page.screenshot(path=str(out/'gemini-audio.png'),full_page=True)
   page.locator('#toolsMenu > summary').click();edited=save()
   assert {'start':1,'end':2.3} in edited['extraCuts'];assert len(edited['audioEditingReport'])==2
   assert key not in json.dumps(edited);assert key not in page.evaluate('JSON.stringify({...localStorage})')
   checks.append('FLAC real enviado ao transporte simulado; risca primeira tomada e conserva ultima; fala sem texto fica para revisao')
   page.locator('.word[data-idx="0"]').click(button='right');restored=save()
   assert not any(c['start']==1 for c in restored['extraCuts']);assert {'start':.1,'end':.2} in restored['extraCuts']
   page.keyboard.press('Control+z');assert {'start':1,'end':2.3} in save()['extraCuts']
   checks.append('Clique direito restaura audio e Ctrl+Z refaz; corte manual preservado')
   current=out/'salvo.json';page.locator('#loadProject').click();page.wait_for_selector('.word');assert len(calls)==1
   assert len(save()['audioEditingReport'])==2
   checks.append('Salvar/reabrir preserva relatorio e cortes sem analisar novamente; nenhuma chave no projeto/storage')
   page.locator('#toolsMenu > summary').click();page.locator('#geminiPanel > summary').click() if not page.locator('#geminiPanel').evaluate('(e)=>e.open') else None
   page.locator('#geminiAnalyze').click();page.wait_for_function('!document.getElementById("geminiAnalyze").disabled',timeout=30000);assert len(calls)==1
   checks.append('Segunda analise reaproveita cache sem novo envio nem restaurar cortes')
   # Select a region in the real timeline: Gemini may hear surrounding context,
   # but returned cuts outside this selection must not change the project.
   page.locator('#toolsMenu > summary').click()
   box=page.locator('#timeline').bounding_box();page.mouse.move(box['x']+box['width']*.25,box['y']+20);page.mouse.down()
   page.mouse.move(box['x']+box['width']*.39,box['y']+20,steps=8);page.mouse.up()
   page.locator('#toolsMenu > summary').click();page.locator('#geminiScope').select_option('selection')
   retained_attempt=True
   page.locator('#geminiAnalyze').click();page.wait_for_function('!document.getElementById("geminiAnalyze").disabled',timeout=30000)
   retained_attempt=False
   assert len(calls)==2
   page.locator('#toolsMenu > summary').click();assert save()['extraCuts']==edited['extraCuts']
   assert 'deleted' not in page.locator('.word[data-idx="3"]').get_attribute('class')
   checks.append('Selecao real respeita tomada mantida pelo relatorio anterior, mesmo apos reabrir projeto')
   page.locator('#toolsMenu > summary').click();page.locator('#geminiScope').select_option('video')
   page.locator('#geminiAuto').check();page.locator('#fullAutoEdit').uncheck() if page.locator('#fullAutoEdit').is_visible() else page.evaluate('document.getElementById("fullAutoEdit").checked=false')
   page.locator('#autoRoughCut').click();page.wait_for_function('!document.getElementById("autoRoughCut").disabled',timeout=30000)
   assert len(calls)==2
   checks.append('Opcao de edicao automatica chama Gemini com cache, sem depender da revisao textual Groq')
   page.wait_for_function('document.getElementById("autosaveStatus").textContent.includes("salva automaticamente")',timeout=10000)
   assert len(app.read_autosave()['audioEditingReport'])==3
   checks.append('Salvamento automatico inclui relatorio de audio sem chave')
   page.locator('#toolsMenu > summary').click();before_failure=save();page.locator('#toolsMenu > summary').click()
   failure=True;page.locator('#editorialContext').fill('outro contexto para testar cota');page.locator('#geminiAnalyze').click()
   page.wait_for_function('!document.getElementById("geminiAnalyze").disabled',timeout=30000);assert 'cota' in page.locator('#geminiStatus').inner_text()
   page.locator('#toolsMenu > summary').click();assert save()['extraCuts']==before_failure['extraCuts']
   checks.append('Falha de cota visivel, sem corte parcial ou perda de edicao')
   for failure,want in [('timeout','GEMINI_TIMEOUT'),('503','HTTP 503'),('reset','GEMINI_CONNECTION_LOST')]:
    page.locator('#toolsMenu > summary').click()
    page.locator('#geminiAnalyze').click()
    page.wait_for_function('!document.getElementById("geminiAnalyze").disabled',timeout=30000)
    status=page.locator('#geminiStatus').inner_text()
    assert want in status,status
    assert key not in status
    page.locator('#geminiStatus').scroll_into_view_if_needed()
    page.screenshot(path=str(out/('gemini-'+failure+'.png')),full_page=True)
    page.locator('#toolsMenu > summary').click()
    assert save()['extraCuts']==before_failure['extraCuts']
    checks.append(want+' atravessa transporte, worker, polling e aviso visivel; cortes e chave preservados')
   page.locator('#exportXml').click();page.wait_for_function('!document.getElementById("exportXml").disabled',timeout=30000)
   assert '<fcpxml version="1.9"' in (out/'saida.fcpxml').read_text()
   checks.append('FCPXML continua referenciando bruto e cortes editaveis')
   assert not errors,errors;assert hashlib.sha256(video.read_bytes()).hexdigest()==original;assert hashlib.sha256(project.read_bytes()).hexdigest()==sourcehash
   assert not list(Path(app.WORKDIR.name).glob('gemini-*.flac'))
   report={'checks':checks,'errors':errors,'realChromium':True,'realFFmpeg':True,'googleTransportSimulated':True,'liveGemini':False,'windowsValidated':False,'davinciValidated':False}
   (out/'resultado.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));browser.close()
 finally:server.shutdown();server.server_close();app.WORKDIR.cleanup()
 print(json.dumps({'checks':len(checks),'errors':errors}))
if __name__=='__main__':main()
