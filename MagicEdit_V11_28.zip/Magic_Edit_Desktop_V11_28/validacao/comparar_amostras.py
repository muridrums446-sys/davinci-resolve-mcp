"""Compara decisoes salvas; nao importa cortes Gling no Magic Edit.
Tempos de corte usam a regra V11.17 (+/-18ms), para reproduzir o comparativo original.
"""
import argparse
import json
from fractions import Fraction
from pathlib import Path
import xml.etree.ElementTree as ET

def union(xs):
    out=[]
    for a,b in sorted(xs):
        if b<=a:continue
        if out and a<=out[-1][1]+.02:out[-1][1]=max(b,out[-1][1])
        else:out.append([a,b])
    return out

def cuts(doc):
    indices=sorted(doc['deletedIndices']);out=[];i=0
    while i<len(indices):
        j=i
        while j+1<len(indices) and indices[j+1]==indices[j]+1:j+=1
        out.append([max(0,doc['words'][indices[i]]['start']-.018),min(doc['media']['duration'],doc['words'][indices[j]]['end']+.018)])
        i=j+1
    return union(out+[[x['start'],x['end']] for x in doc['extraCuts']])

def seconds(xs):return sum(b-a for a,b in xs)

def compare(root):
    docs=[json.loads(p.read_text('utf-8-sig')) for p in sorted(root.glob('01*.json'),key=lambda p:'editado' in p.name)]
    before,after=docs
    xml=ET.parse(next(root.glob('*.fcpxml')))
    clips=xml.findall('.//spine/asset-clip');keeps=[]
    for c in clips:
        a=float(Fraction(c.attrib['start'][:-1]));b=a+float(Fraction(c.attrib['duration'][:-1]));keeps.append([a,b])
    cursor=0;gling=[]
    for a,b in union(keeps):
        if a>cursor:gling.append([cursor,a])
        cursor=max(cursor,b)
    if cursor<before['media']['duration']:gling.append([cursor,before['media']['duration']])
    window=lambda xs:union([[max(0,a),min(502,b)] for a,b in xs])
    a,b,g=map(window,[cuts(before),cuts(after),gling])
    overlap=union([[max(x,z),min(y,w)] for x,y in b for z,w in g if min(y,w)>max(x,z)])
    return {'method':'V11.17 cuts; source time window 0..502 seconds; Gling includes manual adjustments',
            'source_duration':before['media']['duration'],'words':len(before['words']),
            'transcripts_identical':before['words']==after['words'],
            'removed_before':round(seconds(a),3),'removed_after':round(seconds(b),3),
            'removed_gling':round(seconds(g),3),'intersection_magic_gling':round(seconds(overlap),3),
            'only_gling':round(seconds(g)-seconds(overlap),3),'only_magic':round(seconds(b)-seconds(overlap),3),
            'gling_asset_clips':len(clips),'gling_removed_full':round(seconds(gling),3),
            'gling_cuts_first502':len(g),'gling_long_cuts_first502':len([x for x in g if x[1]-x[0]>10]),
            'copied_gling_cuts_into_application':False}

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('samples',type=Path);args=parser.parse_args()
    print(json.dumps(compare(args.samples),ensure_ascii=False,indent=2))
