"""Entrada compativel V11; todas as atualizacoes usam o mesmo backup verificado."""
import sys
from update_desktop import FILES, install, verify_project, main

if __name__ == '__main__':
    try:main()
    except Exception as exc:
        print('ATUALIZACAO INTERROMPIDA:',exc,file=sys.stderr)
        sys.exit(1)
