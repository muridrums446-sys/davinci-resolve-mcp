"""Exportacao MP4 local, sequencial e reversivel a partir dos trechos mantidos."""
from __future__ import annotations

import os
import json
import subprocess
import tempfile
import uuid
from pathlib import Path


def validate_segments(segments: list[dict], media: dict) -> list[tuple[int, int]]:
    fps = media['fpsNum'] / media['fpsDen']
    total = round(media['duration'] * fps)
    if not (1 <= fps <= 120) or not isinstance(segments, list) or not 1 <= len(segments) <= 1500:
        raise ValueError('Lista de trechos invalida ou longa demais para exportar.')
    out = []
    previous = 0
    for item in segments:
        if not isinstance(item, dict) or type(item.get('in')) is not int or type(item.get('out')) is not int:
            raise ValueError('Trecho sem frames validos.')
        start, end = item['in'], item['out']
        if start < previous or end - start < 1 or end > total:
            raise ValueError('Trechos fora de ordem, sobrepostos ou vazios.')
        out.append((start, end))
        previous = end
    return out


def _run(args: list[str], duration: float, progress) -> None:
    flags = subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0
    proc = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                            stdin=subprocess.DEVNULL, text=True, creationflags=flags)
    try:
        for line in proc.stdout:
            key, _, value = line.strip().partition('=')
            if key in ('out_time_us', 'out_time_ms'):
                try: progress(min(1.0, max(0.0, int(value) / 1_000_000 / duration)))
                except ValueError: pass
        error = proc.stderr.read()
        if proc.wait() != 0:
            raise RuntimeError('FFmpeg nao conseguiu gerar o MP4: ' + error[-600:])
    finally:
        if proc.poll() is None:
            proc.kill()
            proc.wait()
        proc.stdout.close()
        proc.stderr.close()


def _verify_video(path: Path, expected: float, ffprobe: str) -> None:
    flags = subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0
    probe = subprocess.run([ffprobe, '-v', 'error', '-show_streams', '-show_format',
                            '-of', 'json', str(path)], capture_output=True, text=True,
                           creationflags=flags, check=True)
    data = json.loads(probe.stdout)
    kinds = {stream.get('codec_type') for stream in data.get('streams', [])}
    duration = float(data.get('format', {}).get('duration', 0))
    if not {'video', 'audio'} <= kinds or abs(duration - expected) > max(.35, expected * .02):
        raise RuntimeError('O MP4 gerado nao passou na verificacao de audio, video e duracao.')


def _publish_video(rendered: Path, destination: Path, progress) -> None:
    """Only expose the final filename after its entire content is in place."""
    pending = destination.with_name(f'.magicedit_{uuid.uuid4().hex}.partial.mp4')
    try:
        try:
            os.replace(rendered, pending)
            progress(99, 100)
        except OSError:
            # System temp and the chosen folder can be on different disks.
            total = rendered.stat().st_size
            copied = 0
            with rendered.open('rb') as src, pending.open('xb') as out:
                while block := src.read(4 * 1024 * 1024):
                    out.write(block)
                    copied += len(block)
                    progress(97 + 2 * copied / total, 100)
                out.flush()
                os.fsync(out.fileno())
        if destination.exists():
            raise ValueError('Ja existe um arquivo com esse nome. Escolha outro para preservar o video anterior.')
        os.rename(pending, destination)
    finally:
        pending.unlink(missing_ok=True)


def export_mp4(source: str, media: dict, segments: list[dict], target: str, ffmpeg: str, progress=lambda done,total: None, ffprobe: str = 'ffprobe', *, analysis_clip: bool = False) -> dict:
    if type(analysis_clip) is not bool:
        raise ValueError('Perfil de exportacao invalido.')
    ranges = validate_segments(segments, media)
    original, destination = Path(source).resolve(), Path(target).resolve()
    if destination.suffix.lower() != '.mp4' or destination == original:
        raise ValueError('Escolha outro nome de arquivo MP4; o video original nao pode ser substituido.')
    if destination.exists():
        raise ValueError('Ja existe um arquivo com esse nome. Escolha outro para preservar o video anterior.')
    destination.parent.mkdir(parents=True, exist_ok=True)
    fps = media['fpsNum'] / media['fpsDen']
    rate = f"{media['fpsNum']}/{media['fpsDen']}"
    if analysis_clip and fps>30:rate='30'
    video_options=['-preset','ultrafast','-crf','23']
    if analysis_clip:
        video_options=['-vf',"scale=w='min(854,iw)':h='min(480,ih)':force_original_aspect_ratio=decrease:force_divisible_by=2,setsar=1",
                       '-preset','veryfast','-crf','32','-maxrate','600k','-bufsize','1200k']
    audio_rate='16000' if analysis_clip else '48000'
    channels='1' if analysis_clip else '2'
    expected = sum(end - start for start, end in ranges) / fps
    progress(0, 100)
    with tempfile.TemporaryDirectory(prefix='magicedit_mp4_') as folder:
        work = Path(folder)
        files = []
        for index, (start, end) in enumerate(ranges):
            clip = work / f'{index:05d}.mkv'
            length = (end - start) / fps
            progress(90 * index / len(ranges), 100)
            _run([ffmpeg, '-hide_banner', '-loglevel', 'error', '-nostdin', '-nostats',
                  '-progress', 'pipe:1', '-ss', f'{start/fps:.9f}', '-i', str(original),
                  '-t', f'{length:.9f}', '-map', '0:v:0', '-map', '0:a:0',
                  '-r', rate, '-c:v', 'libx264', *video_options,
                  '-pix_fmt', 'yuv420p', '-c:a', 'pcm_s16le', '-ar', audio_rate, '-ac', channels,
                  str(clip)], length, lambda fraction: progress(90 * (index + fraction) / len(ranges), 100))
            files.append(clip)
        playlist = work / 'clips.txt'
        playlist.write_text(''.join(f"file '{clip.name}'\n" for clip in files), encoding='utf-8')
        pending = work / 'resultado.mp4'
        progress(90, 100)
        _run([ffmpeg, '-hide_banner', '-loglevel', 'error', '-nostdin', '-nostats',
              '-progress', 'pipe:1', '-f', 'concat', '-safe', '0', '-i', str(playlist),
              '-map', '0:v:0', '-map', '0:a:0', '-c:v', 'copy', '-c:a', 'aac', '-b:a', '64k' if analysis_clip else '160k',
              '-movflags', '+faststart', str(pending)], expected,
             lambda fraction: progress(90 + 6 * fraction, 100))
        if not pending.is_file() or pending.stat().st_size == 0:
            raise RuntimeError('Exportacao MP4 incompleta.')
        progress(96, 100)
        _verify_video(pending, expected, ffprobe)
        progress(97, 100)
        _publish_video(pending, destination, progress)
    progress(100, 100)
    return {'path': str(destination), 'duration': expected, 'segments': len(ranges), 'bytes': destination.stat().st_size}
