@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Magic Edit Desktop - Atualizar V11.28 - Fabrica
set "PY=py -3"
where py >nul 2>nul
if errorlevel 1 set "PY=python"
echo Feche o Magic Edit e a janela do servidor antes de continuar.
set "DESTINO=C:\Magicedit\MagicEdit_Desktop_V11_Atualizacao\MagicEdit_Desktop_V11"
echo Destino: %DESTINO%
echo O backup integral sera verificado antes de substituir arquivos.
echo.
%PY% update_desktop.py --target "%DESTINO%"
set "RESULT=%ERRORLEVEL%"
echo.
if not "%RESULT%"=="0" echo Atualizacao interrompida. Leia o erro acima; nao apague o backup.
pause
exit /b %RESULT%
