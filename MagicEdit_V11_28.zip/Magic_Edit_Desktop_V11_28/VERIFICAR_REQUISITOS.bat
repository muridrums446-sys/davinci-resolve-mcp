@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Magic Edit Desktop - Verificar requisitos
echo =====================================================
echo             MAGIC EDIT - REQUISITOS
echo =====================================================
echo.
where py >nul 2>nul
if not errorlevel 1 (
  py -3 --version
) else (
  where python >nul 2>nul
  if errorlevel 1 (
    echo [FALTA] Python 3.10 ou superior
    echo Baixe: https://www.python.org/downloads/windows/
  ) else (
    python --version
  )
)
echo.
if exist "%~dp0ffmpeg.exe" (
 echo [OK] FFmpeg na pasta do programa
) else (
 where ffmpeg >nul 2>nul
 if errorlevel 1 (
  echo [FALTA] FFmpeg
  echo Coloque ffmpeg.exe e ffprobe.exe nesta pasta ou instale FFmpeg no Windows PATH.
  echo Site: https://ffmpeg.org/download.html
 ) else (
  ffmpeg -version | findstr /i "ffmpeg version"
 )
)
echo.
if exist "%~dp0ffprobe.exe" (
 echo [OK] FFprobe na pasta do programa
) else (
 where ffprobe >nul 2>nul
 if errorlevel 1 (
  echo [FALTA] FFprobe
  echo Ele vem junto do FFmpeg. Coloque ffprobe.exe nesta pasta.
 ) else (
  ffprobe -version | findstr /i "ffprobe version"
 )
)
echo.
echo Primeiro teste recomendado: video de 2 a 5 minutos.
echo.
pause
