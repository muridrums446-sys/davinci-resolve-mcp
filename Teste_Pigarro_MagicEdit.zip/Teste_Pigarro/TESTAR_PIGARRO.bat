@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Magic Edit - Teste local de repeticao e pigarro
set "PY=py -3"
where py >nul 2>nul
if errorlevel 1 set "PY=python"
echo Salve o projeto no Magic Edit antes de selecionar o JSON.
echo Este teste cria uma copia; nao instala nem atualiza o programa.
%PY% testar_pigarro.py
pause
