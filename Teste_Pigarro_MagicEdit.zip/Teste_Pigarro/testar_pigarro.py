"""One-project reversible comparison. Standard library, no network or installer."""
from pathlib import Path
import json
import sys


def create_comparison(source):
    source=Path(source)
    if source.suffix.lower()!='.json' or source.stat().st_size>20_000_000:
        raise ValueError('Escolha o JSON salvo pelo Magic Edit para este teste.')
    doc=json.loads(source.read_text(encoding='utf-8-sig'))
    if not isinstance(doc,dict) or doc.get('schema')!=1:
        raise ValueError('Formato de projeto inesperado. Nenhum arquivo foi alterado.')
    words=doc.get('words');cuts=doc.get('extraCuts');report=doc.get('audioEditingReport')
    if not all(isinstance(x,list) for x in (words,cuts,report)):
        raise ValueError('Faltam dados do projeto. Nenhum arquivo foi alterado.')
    def at(value,expected):
        return type(value) in (int,float) and abs(value-expected)<.0001
    matched=[s for s in report if isinstance(s,dict) and s.get('origin')=='gemini-audio'
             and s.get('requiresReview') is False and at(s.get('start'),92.54)
             and at(s.get('end'),93.56) and at(s.get('keepStart'),95.7) and at(s.get('keepEnd'),97.14)]
    if not matched or not any(isinstance(c,dict) and at(c.get('start'),92.54) and at(c.get('end'),93.56) for c in cuts):
        raise ValueError('Este JSON nao tem a marcacao esperada do teste. Salve e escolha o projeto que foi analisado pelo Gemini.')
    additions=[{'start':2774/30,'end':92.54},{'start':93.56,'end':95.6}]
    for w in words:
        if (not isinstance(w,dict) or not isinstance(w.get('word'),str)
            or type(w.get('start')) not in (int,float) or type(w.get('end')) not in (int,float)
            or not 0<=w['start']<w['end']):
            raise ValueError('Tempos de palavras invalidos. Nenhum arquivo foi alterado.')
        if any(w['start']<c['end'] and w['end']>c['start'] for c in additions):
            raise ValueError('O ajuste invadiria uma palavra desta transcricao. Nenhum arquivo foi alterado.')
    # Verify the neighboring words as well as the model annotation; this utility
    # is a comparison for a known example, not a universal noise-removal rule.
    if not any(at(w['end'],92.4) for w in words) or not any(at(w['start'],95.7) for w in words):
        raise ValueError('Os limites do trecho sao diferentes. Nenhum arquivo foi alterado.')
    if any(c in cuts for c in additions):
        raise ValueError('Esta copia ja contem o ajuste de teste. Abra-a no Magic Edit.')
    result={**doc,'extraCuts':cuts+additions}
    destination=source.with_name(source.stem+'_TESTE_PIGARRO.json')
    # Exclusive creation: neither the chosen project nor an earlier comparison
    # can be replaced. Preserve every other field and the original AI report.
    text=json.dumps(result,ensure_ascii=False,indent=2)
    handle=destination.open('x',encoding='utf-8')
    try:
        with handle:handle.write(text)
    except OSError:
        destination.unlink(missing_ok=True)
        raise
    return destination


def main():
    root=None
    try:
        if len(sys.argv)>1:
            selected=sys.argv[1]
        else:
            import tkinter as tk
            from tkinter import filedialog,messagebox
            root=tk.Tk();root.withdraw()
            selected=filedialog.askopenfilename(title='Escolha o JSON salvo do Magic Edit',filetypes=[('Projeto Magic Edit','*.json')])
        if not selected:
            print('Cancelado. Nenhum arquivo foi alterado.');return 0
        output=create_comparison(selected)
        message='Copia de teste criada:\n'+str(output)+'\n\nAbra essa copia em Abrir projeto no Magic Edit.\nO projeto original foi preservado. Este utilitario nao atualiza o aplicativo.'
        print(message)
        if root is not None:messagebox.showinfo('Teste pronto',message,parent=root)
        return 0
    except Exception as exc:
        message='Nao foi possivel criar a copia.\n'+str(exc)+'\n\nO projeto original nao foi substituido.'
        print(message)
        if root is not None:messagebox.showerror('Teste nao criado',message,parent=root)
        return 1
    finally:
        if root is not None:root.destroy()


if __name__=='__main__':sys.exit(main())
