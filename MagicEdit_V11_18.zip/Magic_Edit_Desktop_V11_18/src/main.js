import { formatTime, suggestSilences, cutRanges, keepRanges, summarizeTimeline, exportFcp7Xml, findWordAtTime } from './engine.js';
import { normalizedSelection, chooseRange, toggleTranscriptCut } from './selection.js';
import { analyzeTranscript, automaticCuts, projectCutsOnOpen, candidateWordTypes } from './autoedit.js';
import { groupParagraphs, transcriptCutMarkers, detectVerifiedSilences, reviewableAudioGaps, timeAtClientX } from './editor_v09.js';
import { playbackTarget, filmstripSamples, manualCutRange, splitFrameAt, segmentAtTime } from './preview_v11.js';
import { wordFromPoint } from './word_hit.js';

const state={path:'',media:null,words:[],deleted:new Set(),extraCuts:[],proposals:[],page:0,
  projectName:'',wavePeaks:[],waveRate:20,waveNorm:255,viewStart:0,viewSpan:0,autoSuggestions:[],busy:false,history:[],selection:null,selectionAnchor:null,model:'whisper-large-v3',
  activeWord:-1,followSpeech:true,animationFrame:0,cutCache:[],autoSilencePending:false,vadSpeech:null,vadState:'idle',reviewGaps:[],hoverTime:null,thumbs:new Map(),thumbPending:0,thumbVersion:0,cutJump:null,manualStart:null,timelineRange:null,rangeMode:false,splitFrames:[],recovery:null,pendingResumeTime:null};
const el=(id)=>document.getElementById(id);
async function api(path, payload=null) {
  const opts=payload===null?{}:{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)};
  const r=await fetch('/api/'+path,opts);
  const obj=await r.json();
  if(!r.ok)throw new Error(obj.error||('Falha '+r.status));
  return obj;
}
function pause(ms){return new Promise(resolve=>setTimeout(resolve,ms));}
async function waitJob(onProgress=()=>{}) {
  while(true) {
    const job=await api('status');
    el('progress').textContent=job.message||job.state;
    onProgress(job);
    if(job.state==='done')return job.result;
    if(job.state==='error')throw new Error(job.message||'Falha no processamento.');
    await pause(900);
  }
}

const fileSafe=(s)=>String(s||'MagicEdit').replace(/[<>:"/\\|?*]/g,'-').replace(/[. ]+$/,'').slice(0,90)||'MagicEdit';
const safe=(s)=>String(s).replace(/[&<>"']/g,x=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[x]));

document.body.classList.add('home-open');
el('app').innerHTML=`
<section id="home" class="home-screen" aria-label="Início Magic Edit">
  <header class="home-top"><div class="brand"><span class="logo-symbol">✦</span><div><strong>MAGIC EDIT</strong><small>DESKTOP · V11.18</small></div></div><span>Edição de vídeo pela transcrição</span></header>
  <div class="home-content"><div class="home-intro"><span class="home-eyebrow">SEU ESPAÇO DE EDIÇÃO</span><h1>O que vamos editar hoje?</h1><p>Abra um vídeo para começar ou continue um projeto já salvo. Seus vídeos permanecem no computador.</p></div>
  <button class="continue-edit" id="homeContinue" type="button" hidden><span>Continuar de onde parei</span><strong id="continueName"></strong><small id="continueTime"></small></button>
  <p class="home-auto-hint">Novo vídeo: transcrição e edição bruta automáticas. Revise os cortes antes de finalizar no DaVinci.</p>
  <div class="home-actions"><button type="button" class="home-card import" id="homeImport"><span class="home-icon">＋</span><strong>Importar vídeo</strong><small>MP4, MOV, MKV e outros formatos</small></button><button type="button" class="home-card" id="homeOpen"><span class="home-icon">▣</span><strong>Abrir projeto</strong><small>Continue a edição de um arquivo JSON</small></button></div>
  <label class="home-auto-hint"><input type="checkbox" id="fullAutoEdit" checked> Edição completa com Groq: analisa o texto e corta tomadas ruins e falas laterais de alta confiança. Usa a cota da sua conta; pode errar.</label>
  <section id="homeProcess" class="home-process" aria-label="Preparação do vídeo" hidden>
    <span class="home-eyebrow">PREPARANDO A EDIÇÃO</span><h2 id="homeProcessName">Vídeo selecionado</h2>
    <p id="homeProcessStatus" role="status" aria-live="polite">Preparando vídeo...</p>
    <div class="home-progress-track" role="progressbar" aria-label="Progresso da análise" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0" id="homeProgressTrack"><div id="homeProgressFill"></div></div>
    <span id="homeProgressNumber" class="home-progress-number">0%</span>
    <form id="homeKeyForm" class="home-key-form" hidden><label for="homeApiKey">Chave Groq para transcrever o áudio</label><div><input id="homeApiKey" type="password" autocomplete="off" spellcheck="false" placeholder="gsk_..." required><button type="submit" id="homeStart">Transcrever e editar</button></div><small>A chave fica somente nesta sessão e não entra no projeto ou no XML.</small></form>
    <button type="button" id="homeRetry" class="home-retry" hidden>Tentar novamente</button>
  </section>
  <div class="recent-heading"><h2>Vídeos e projetos recentes</h2><span>Remover da lista não apaga arquivos</span></div><div id="recentProjects" class="recent-list"></div></div>
</section>
<header class="topbar">
  <div class="brand"><button class="home-back" id="backHome" type="button" title="Voltar ao início">‹</button><span class="logo-symbol">✦</span><div><strong>MAGIC EDIT</strong><small>DESKTOP · V11.18</small></div></div>
  <div class="header-actions">
    <button class="hbtn" id="pickVideo" type="button">＋ Importar vídeo</button>
    <label class="project-name-label">Projeto <input id="projectNameInput" maxlength="90" aria-label="Nome do projeto" placeholder="Nome do projeto" value="" /></label>
    <button class="hbtn" id="loadProject" type="button">Abrir projeto</button>
    <button class="hbtn" id="saveProject" type="button">Salvar projeto</button><span id="autosaveStatus" class="autosave-status" role="status">Salvamento automático ativo</span>
    <details class="tools-menu" id="toolsMenu"><summary class="hbtn">⚙ Ferramentas <span aria-hidden="true">▾</span></summary>
      <div class="tools-popover">
        <div class="tools-title">Edição bruta automática</div>
        <button class="action primary" id="autoRoughCut" type="button">✦ Editar automaticamente este projeto</button>
        <label for="editorialContext">Assunto ou roteiro (opcional, ajuda a distinguir falas laterais)</label><textarea id="editorialContext" rows="2" maxlength="3000" placeholder="Ex.: explicar como funciona a bolsa; preservar exemplos e explicações"></textarea>
        <p id="roughCutStatus" class="hint">Pausas, duplicatas e contexto: cada corte pode ser restaurado no texto ou desfeito com Ctrl+Z.</p>
        <input type="checkbox" id="autoSilenceEnabled" checked hidden aria-hidden="true"/>
        <p class="hint">Ao importar, as pausas seguras são cortadas automaticamente. Ajuste abaixo apenas se quiser outro ritmo.</p>
        <label for="silenceStrength">Quanto encurtar as pausas <strong id="silenceStrengthLabel">Equilibrado</strong></label>
        <input id="silenceStrength" type="range" min="0" max="100" step="25" value="50" aria-label="Intensidade do corte de pausas"/>
        <div class="strength-scale"><span>Natural</span><span>Mais rápido</span></div>
        <p id="silenceEstimate" class="hint">A prévia dos cortes aparece após analisar o áudio.</p>
        <p class="hint">Palavras e voz detectada pelo Silero recebem proteção em todos os níveis. Trechos duvidosos podem aparecer na revisão.</p>
        <button class="action primary" id="applyVerifiedSilences" type="button">✂ Aplicar novo ritmo neste projeto</button>
        <p class="progress" id="acousticStatus">Aguardando vídeo e análise Silero.</p>
        <details class="tool-section"><summary>Trechos de áudio para conferir <span id="audioReviewCount"></span></summary>
          <p class="hint">Vá ao trecho, pressione Espaço para ouvir e depois selecione. Voz não reconhecida também aparece aqui; Delete só remove depois da sua escolha.</p>
          <div id="audioReview" class="audio-review"></div>
          <button id="moreAudioReview" class="action subtle" type="button" hidden>Ver mais trechos</button>
        </details>
        <details class="tool-section"><summary>Tomadas e repetições para revisar</summary>
          <p class="hint" id="autoStatus" role="status">Clique direito no texto para restaurar uma fala.</p>
          <button class="action subtle" id="markNewRestarts" type="button">Marcar novas tentativas interrompidas</button>
          <button class="action subtle" id="reviewTakesGroq" type="button">Analisar contexto com Groq (só sugestões)</button>
          <p class="hint">Envia a transcrição à Groq apenas quando você clicar. Usa a cota da sua conta; confira seu plano. A IA sugere, você decide o corte.</p>
          <p class="progress" id="semanticStatus"></p>
          <div id="autoSuggestions" class="auto-suggestions"></div>
        </details>
        <details class="tool-section"><summary>Transcrição e chave Groq</summary>
        <label for="apiKey">Chave Groq</label><input id="apiKey" type="password" autocomplete="off" spellcheck="false" placeholder="gsk_..."/>
        <p class="hint">Usada apenas nesta sessão; não entra no projeto.</p>
        <label for="model">Modelo</label><select id="model"><option value="whisper-large-v3">Whisper Large V3 • qualidade</option><option value="whisper-large-v3-turbo">Whisper Turbo • velocidade</option></select>
        <button class="action primary" id="transcribe" type="button">✦ Transcrever na nuvem</button>
        <p class="progress" id="progress" role="status">Aguardando gravação</p>
        </details>
        <details class="tool-section"><summary>Ferramentas adicionais</summary>
        <button class="action" id="silences" type="button">Revisar intervalos sem palavras</button>
        <div class="silence-box" id="silencesBox"></div>
        <button class="action subtle" id="undo" type="button">↶ Desfazer corte (Ctrl+Z)</button>
        <button class="action subtle" id="preview" type="button">Criar prévia leve para MKV</button>
        </details>
      </div>
    </details>
    <button class="export-main" id="exportXml" type="button">⇧ Exportar FCP XML</button>
    <button class="export-main export-mp4" id="exportMp4" type="button">⬇ Exportar MP4</button>
  </div>
</header>
<main class="workspace">
  <section class="script-panel" aria-label="Edição pela transcrição">
    <div class="script-heading">
      <div class="script-file" id="mediaCard">Nenhum vídeo selecionado</div>
      <span class="stat-label" id="wordCount">0 palavras</span>
    </div>
    <nav class="script-tabs"><span class="current">✎ Transcrição</span><span class="script-hint">Selecione como no Word</span></nav>
    <div class="transcript-toolbar">
      <input id="search" type="search" placeholder="Buscar palavra..." />
      <div class="transcript-tools"><button id="reviewAuto" type="button" class="auto-review">Sugestões: 0</button><button id="followSpeech" class="follow-btn selected" type="button" aria-pressed="true">● Acompanhar fala</button></div>
    </div>
    <div class="editing-hint">Clique posiciona · Arraste seleciona · Direito corta/restaura · Espaço reproduz · <span class="hint-candidate">Vermelho riscado: pré-corte · Pausa riscada: clique para restaurar</span></div>
    <div class="selection-bar"><span id="selectionStatus" aria-live="polite">Arraste sobre o texto para selecionar o trecho.</span><div class="selection-buttons"><button id="selectionAction" type="button" disabled>✂ Cortar seleção</button><button id="clearSelection" type="button" disabled>Limpar</button></div></div>
    <div class="transcript" id="transcript"><div class="empty-transcript">Importe uma gravação e transcreva para começar.</div></div>
  </section>
  <section class="view-panel" aria-label="Prévia do vídeo">
    <div class="preview-heading"><strong>Pré-visualização</strong><span class="preview-shortcut">Espaço = Play / Pause</span></div>
    <div class="player-box"><div class="video-wrap"><video id="player" preload="metadata" controls playsinline></video><div id="videoEmpty">Importe uma gravação para começar</div></div></div>
    <div class="player-actions"><span class="time" id="time">00:00:00 / 00:00:00</span><div class="speeds"><span>Velocidade</span><button data-speed="1" class="selected" type="button">1x</button><button data-speed="1.5" type="button">1,5x</button><button data-speed="2" type="button">2x</button></div></div>
  </section>
  <section class="timeline-box" aria-label="Timeline com onda de áudio e escala de frames">
    <div class="timeline-title"><div><strong>Timeline • Vídeo + áudio</strong> <span class="summary" id="summary">Duração final: —</span></div>
      <div class="timeline-controls"><span class="legend"><i class="keep"></i> Manter <i class="remove"></i> Cortar</span>
      <button id="splitAtPlayhead" type="button" title="Dividir no playhead, sem retirar conteúdo (tecla C)">C · Cortar aqui</button><button id="rangeMode" type="button" aria-pressed="false" title="Opcional: arraste na onda para selecionar um intervalo livre">Selecionar intervalo</button><button id="deleteRange" type="button" disabled title="Retirar o trecho selecionado da prévia e exportação">✂ Delete</button><button id="clearRange" type="button" title="Limpar seleção">Limpar seleção</button>
      <button id="markStart" type="button" title="Marca o primeiro ponto do corte">Marcar início</button><button id="cutToPlayhead" type="button" disabled title="Corta do ponto marcado até a posição atual">✂ Cortar até aqui</button>
      <button id="zoomOut" type="button" title="Afastar">−</button><button id="zoomFit" type="button">Tudo</button><button id="zoomIn" type="button" title="Aproximar">＋</button>
      <span id="timelineZoom">Vídeo inteiro</span></div></div>
    <div class="filmstrip" id="filmstrip"><canvas id="thumbCanvas"></canvas><div class="filmstrip-label">Frames reais · Cortes em rosa</div></div><div class="timeline-ruler" id="timelineRuler"><canvas id="rulerCanvas"></canvas></div>
    <div class="timeline" id="timeline" title="C divide; clique no trecho e Delete remove. Botão direito sobre corte rosa restaura."><canvas id="waveCanvas"></canvas><div id="splitMarkers" class="split-markers" aria-hidden="true"></div><div id="rangeSelection" class="range-selection" hidden></div><div id="playhead" class="playhead" hidden></div><div id="hoverhead" class="hoverhead" hidden><span id="hoverTime" class="hover-time">00:00:00:00</span></div><span id="waveStatus" class="wave-status">Importe um vídeo para visualizar a forma de onda.</span></div>
    <div class="timeline-footer"><span class="timeline-tip" id="rangeStatus">Posicione · C divide · clique no trecho · Delete remove · Ctrl+Z desfaz</span><input type="range" id="timelinePan" min="0" max="1000" value="0" step="1" aria-label="Rolar horizontalmente a região visível da timeline" disabled /></div>
    <div class="mp4-export-status" id="mp4ExportStatus" hidden><div class="mp4-progress-track" id="mp4ProgressTrack" role="progressbar" aria-label="Renderização MP4" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><div id="mp4ProgressFill"></div></div><div id="mp4Progress" class="mp4-progress" role="status" aria-live="polite"></div><div id="mp4FinalPath" class="mp4-final-path" hidden></div></div>
  </section>
</main>
<div id="toast" role="status" aria-live="polite"></div>`;

function toast(message,err=false) { const n=el('toast');n.textContent=message;n.className=err?'show error':'show';clearTimeout(toast.timeout);toast.timeout=setTimeout(()=>{n.className='';},4500); }
function busy(v) {state.busy=v;['pickVideo','transcribe','loadProject','saveProject','exportXml','exportMp4','preview','homeImport','homeOpen','splitAtPlayhead','applyVerifiedSilences','reviewTakesGroq'].forEach(id=>el(id).disabled=v);el('transcribe').textContent=v?'Processando...':'✦ Transcrever na nuvem';}
const RECENT_KEY='magicedit.recent.v11';
const SILENCE_KEY='magicedit.silenceStrength.v11';
const strengthNames=['Conservador','Suave','Equilibrado','Encurtar mais','Forte'];
function silenceOptions(){return {norm:state.waveNorm,speech:state.vadSpeech,strength:Number(el('silenceStrength').value)||0};}
function freshSilenceRanges(ranges){
 let parts=ranges.map(x=>({...x}));
 for(const old of state.cutCache){
   parts=parts.flatMap(p=>old.end<=p.start||old.start>=p.end?[p]:[
     ...(old.start>p.start?[{start:p.start,end:old.start}]:[]),
     ...(old.end<p.end?[{start:old.end,end:p.end}]:[])
   ]);
 }
 return parts.filter(p=>p.end-p.start>=.12);
}
function updateSilenceEstimate(){
 const strength=Math.max(0,Math.min(100,Number(el('silenceStrength').value)||0));
 el('silenceStrengthLabel').textContent=strengthNames[Math.round(strength/25)];
 if(!state.media||!state.words.length||!state.wavePeaks.length||state.vadState!=='done')return;
 const ranges=detectVerifiedSilences(state.words,state.media.duration,state.wavePeaks,state.waveRate,silenceOptions());
 const fresh=freshSilenceRanges(ranges);
 el('silenceEstimate').textContent=`Prévia: ${fresh.length} pausas · ${fresh.reduce((sum,c)=>sum+c.end-c.start,0).toFixed(1)} s. Mover o controle não altera o projeto.`;
}
try{const raw=localStorage.getItem(SILENCE_KEY);if(raw!==null&&[0,25,50,75,100].includes(Number(raw)))el('silenceStrength').value=raw;}catch{}
el('silenceStrength').oninput=()=>{updateSilenceEstimate();try{localStorage.setItem(SILENCE_KEY,el('silenceStrength').value);}catch{}};
updateSilenceEstimate();
function recentItems(){return state.recent||[];}
function renderRecent(){
 const items=recentItems();
 el('recentProjects').innerHTML=items.length?items.map((item,i)=>{
   const name=safe(item.name||item.path.split(/[\\/]/).pop());
   return `<div class="recent-item"><button type="button" class="recent-open" data-recent="${i}" title="Abrir ${name}"><span class="recent-thumb"><span class="recent-icon">${item.kind==='project'?'▣':'▶'}</span><img src="/api/recent_thumbnail?path=${encodeURIComponent(item.path)}" alt="" loading="lazy"></span><span class="recent-info"><strong>${name}</strong><small>${item.kind==='project'?'Projeto':'Vídeo'} · ${safe(item.path)}</small></span><span class="recent-arrow" aria-hidden="true">→</span></button><button type="button" class="recent-remove" data-recent-remove="${i}" aria-label="Remover ${name} do histórico" title="Remover do histórico sem apagar o arquivo">×</button></div>`;
 }).join(''):'<p class="recent-empty">Seus projetos salvos aparecerão aqui.</p>';
}
let recentSave=Promise.resolve(),recentRevision=0,recentRemoving=false;
function storeRecentLocally(){try{localStorage.setItem(RECENT_KEY,JSON.stringify(state.recent));}catch{/* A lista tambem e salva no servidor. */}}
function rememberRecent(kind,path,name){
 const items=recentItems().filter(x=>x.path!==path);items.unshift({kind,path,name});state.recent=items.slice(0,12);renderRecent();
 recentRevision++;storeRecentLocally();
 const snapshot=state.recent;recentSave=recentSave.then(()=>api('recent',{items:snapshot})).catch(()=>{});
}
async function removeRecent(index){
 if(recentRemoving)return;
 const item=recentItems()[index];if(!item)return;
 recentRemoving=true;
 const next=recentItems().filter(x=>x.path!==item.path);
 const revision=++recentRevision;
 try{
   await recentSave;
   await api('recent',{items:next});
   if(revision!==recentRevision)return;
   state.recent=next;storeRecentLocally();renderRecent();
   toast('Removido do histórico. O vídeo e o projeto continuam no computador.');
 }catch{toast('Não foi possível atualizar o histórico. Tente novamente.',true);}
 finally{recentRemoving=false;}
}
async function loadRecent(){try{
 const revision=recentRevision;
 const remote=(await api('recent')).items||[];
 if(revision!==recentRevision)return;
 const merged=[...remote,...recentItems()].filter((x,i,all)=>x&&typeof x.path==='string'&&['video','project'].includes(x.kind)&&all.findIndex(y=>y.path===x.path)===i);
 state.recent=merged.slice(0,12);renderRecent();
}catch{/* Em caso de falha, a lista do navegador segue disponivel. */}}

function showEditor(){document.body.classList.remove('home-open');}
function showHome(){el('player').pause();el('homeProcess').hidden=true;document.body.classList.add('home-open');renderRecent();}
try{const stored=JSON.parse(localStorage.getItem(RECENT_KEY)||'[]');state.recent=Array.isArray(stored)?stored.filter(x=>x&&typeof x.path==='string'&&['video','project'].includes(x.kind)).slice(0,12):[];}catch{state.recent=[];}
renderRecent();loadRecent();
let autosaveTimer=0,autosaveQueue=Promise.resolve(),lastPositionSave=0;
function projectDocument(){
 if(!state.media||!state.words.length)return null;
 return {schema:1,autoEditVersion:3,projectName:state.projectName,path:state.path,media:state.media,
   words:state.words,deletedIndices:[...state.deleted],extraCuts:state.extraCuts,splitFrames:state.splitFrames,
   model:state.model,editingReport:state.autoSuggestions,editorialContext:el('editorialContext').value||'',playhead:Math.max(0,el('player').currentTime||0)};
}
function recoveryCard(doc){
 state.recovery=doc;
 el('homeContinue').hidden=!doc;
 if(doc){el('continueName').textContent=doc.projectName||doc.media?.name||'Última edição';el('continueTime').textContent=`Parei em ${formatTime(doc.playhead||0)} · Cortes guardados automaticamente neste computador`;}
}
api('autosave').then(result=>recoveryCard(result.project)).catch(()=>{});
function scheduleAutosave(){
 if(!projectDocument())return;
 el('autosaveStatus').textContent='Salvando edição...';
 clearTimeout(autosaveTimer);
 autosaveTimer=setTimeout(()=>{
   const doc=projectDocument();if(!doc)return;
   autosaveQueue=autosaveQueue.catch(()=>{}).then(()=>api('autosave',doc)).then(()=>{recoveryCard(doc);el('autosaveStatus').textContent='Edição salva automaticamente';}).catch(()=>{el('autosaveStatus').textContent='Falha ao salvar automaticamente';});
 },700);
}
function savePosition(){
 if(!state.media||!state.words.length)return;
 const time=el('player').currentTime;
 if(!Number.isFinite(time))return;
 lastPositionSave=Date.now();
 api('autosave_position',{path:state.path,time}).then(()=>{if(state.recovery?.path===state.path){state.recovery.playhead=time;recoveryCard(state.recovery);}}).catch(()=>{});
}
window.addEventListener('pagehide',()=>{
 const doc=projectDocument();if(!doc)return;
 navigator.sendBeacon?.('/api/autosave',new Blob([JSON.stringify(doc)],{type:'application/json'}));
});
function snapshot() {state.history.push({deleted:new Set(state.deleted),extraCuts:state.extraCuts.map(x=>({...x})),splitFrames:[...state.splitFrames]});if(state.history.length>45)state.history.shift();}
function updateSelectionUi(){
  const selection=state.selection;
  const {covered}=transcriptCutMarkers(state.words,state.extraCuts);
  const count=selection?selection.end-selection.start+1:0;
  el('selectionStatus').textContent=count?`${count} palavra${count===1?'':'s'} selecionada${count===1?'':'s'} · Clique direito para cortar ou restaurar.`:'Arraste sobre o texto para selecionar o trecho.';
  el('selectionAction').disabled=!count;
  if(count){
    const removed=Array.from({length:count},(_,i)=>selection.start+i).every(i=>state.deleted.has(i)||covered.has(i));
    el('selectionAction').textContent=removed?'↶ Restaurar seleção':'✂ Cortar seleção';
  }else{el('selectionAction').textContent='✂ Cortar seleção';}
  el('clearSelection').disabled=!count;
}
function clearNativeSelection(){window.getSelection()?.removeAllRanges();}
function restoreNativeSelection(){
  if(!state.selection)return;
  const a=el('transcript').querySelector(`[data-idx="${state.selection.start}"]`);
  const b=el('transcript').querySelector(`[data-idx="${state.selection.end}"]`);
  if(!a||!b||!a.firstChild||!b.firstChild)return;
  const range=document.createRange();
  range.setStart(a.firstChild,0);range.setEnd(b.firstChild,b.firstChild.textContent.length);
  const selection=window.getSelection();selection.removeAllRanges();selection.addRange(range);
}
function nativeSelectedWords(){
  const selection=window.getSelection();
  if(!selection||selection.isCollapsed||!selection.toString().trim())return null;
  if(!el('transcript').contains(selection.anchorNode)||!el('transcript').contains(selection.focusNode))return null;
  const range=selection.getRangeAt(0);
  let a=Infinity,b=-1;
  for(const item of el('transcript').querySelectorAll('.word[data-idx]')){
    if(range.intersectsNode(item)){const idx=Number(item.dataset.idx);a=Math.min(idx,a);b=Math.max(idx,b);}
  }
  return Number.isFinite(a)?normalizedSelection(a,b,state.words.length):null;
}
function selectRange(a,b){state.selection=normalizedSelection(a,b,state.words.length);updateSelectionUi();}
function clearSelection(){state.selection=null;clearNativeSelection();updateSelectionUi();}
function applyCut(range){
  if(!range)return;
  const result=toggleTranscriptCut(state.words,state.deleted,state.extraCuts,range);
  if(result.action==='noop')return;
  snapshot();
  state.deleted=result.deleted;
  state.extraCuts=result.extraCuts;
  state.selection={...range};
  updateAll();restoreNativeSelection();
  toast(`${range.end-range.start+1} palavra(s) ${result.action==='deleted'?'removidas':'restauradas'}. Clique direito novamente para inverter.`);
}

function setVideo(path,media,{openEditor=true}={}) {state.path=path;state.media=media;state.projectName=media.name.replace(/\.[^.]+$/,'');state.pendingResumeTime=null;state.reviewExpanded=false;state.thumbVersion++;state.thumbs=new Map();state.thumbPending=0;state.cutJump=null;state.manualStart=null;state.timelineRange=null;state.splitFrames=[];state.rangeMode=false;el('rangeMode').classList.remove('selected');el('rangeMode').setAttribute('aria-pressed','false');el('deleteRange').disabled=true;el('cutToPlayhead').disabled=true;el('markStart').textContent='Marcar início';el('projectNameInput').value=state.projectName;state.wavePeaks=[];state.waveNorm=255;state.vadSpeech=null;state.vadState='running';state.autoSilencePending=false;el('silenceEstimate').textContent='A prévia dos cortes aparece após analisar o áudio.';el('acousticStatus').textContent='Silero VAD: analisando áudio local...';state.viewStart=0;state.viewSpan=Math.min(media.duration,150);el('mediaCard').innerHTML=`<strong>${safe(media.name)}</strong><small>${formatTime(media.duration)} · ${(media.fpsNum/media.fpsDen).toFixed(2)} fps · ${media.width}×${media.height}</small>`;el('videoEmpty').style.display='none';el('player').src='/api/video';el('player').load();el('progress').textContent='Vídeo pronto para transcrever';if(openEditor)showEditor();updateAll();state.analysisTasks=Promise.all([loadWaveform(),loadVad()]);}
function renderWords(){
  const node=el('transcript');const priorScroll=node.scrollTop;
  if(!state.words.length){state.wordNodes=[];node.innerHTML='<div class="empty-transcript">Importe um vídeo e clique em “Transcrever na nuvem”.</div>';el('wordCount').textContent='0 palavras';return;}
  const {markers,covered}=transcriptCutMarkers(state.words,state.extraCuts);
  const candidates=candidateWordTypes(state.autoSuggestions,state.words.length);
  const marker=(idx)=>(markers.get(idx)||[]).map(c=>`<button type="button" class="cut-marker" data-restore-cut="${c.index}" title="Áudio sem palavras reconhecidas. Clique ou use o botão direito para restaurar ${formatTime(c.start)} a ${formatTime(c.end)}">✂ <s>Áudio sem texto ${Math.max(0,c.end-c.start).toFixed(1).replace('.',',')} s</s> · restaurar</button>`).join(' ');
  // Documento CONTÍNUO: toda a transcrição no mesmo bloco com apenas UMA rolagem.
  // Fragmentos HTML são produzidos uma vez por edição; reprodução atualiza apenas a classe ativa.
  node.innerHTML=groupParagraphs(state.words).map(group=>{
    const parts=[];
    for(let idx=group.start;idx<=group.end;idx++){
      const w=state.words[idx];
      parts.push(`${marker(idx)}<span class="word ${state.deleted.has(idx)||covered.has(idx)?'deleted':''} ${state.activeWord===idx?'speaking':''} ${candidates.has(idx)?'candidate candidate-'+candidates.get(idx):''}" title="${formatTime(w.start)} • ${w.start.toFixed(2)}s${w.timingEstimated?' • Tempo estimado pelo reconhecimento; confira no áudio':''}" data-idx="${idx}">${safe(w.word)}</span>`);
    }
    return `<p class="transcript-paragraph">${parts.join(' ')}${group.end===state.words.length-1?marker(state.words.length):''}</p>`;
  }).join('');
  state.wordNodes=[...node.querySelectorAll('.word[data-idx]')];
  node.scrollTop=priorScroll;
  el('wordCount').textContent=`${state.words.length.toLocaleString('pt-BR')} palavras`;
}
function setFollowSpeech(on) {
  state.followSpeech=Boolean(on);
  const button=el('followSpeech');
  button.classList.toggle('selected',state.followSpeech);
  button.setAttribute('aria-pressed',String(state.followSpeech));
  button.textContent=state.followSpeech?'● Acompanhar fala: ligado':'○ Acompanhar fala: pausado';
  if(state.followSpeech) syncSpeech({force:true});
}
function ensureWordVisible(wordEl){
  const transcript=el('transcript');
  if(!wordEl || !state.followSpeech) return;
  const top=wordEl.getBoundingClientRect().top-transcript.getBoundingClientRect().top+transcript.scrollTop;
  const viewTop=transcript.scrollTop, viewBottom=viewTop+transcript.clientHeight;
  // Antecipar a linha seguinte: manter a fala na metade superior do painel.
  // A tolerancia evita reflow/rolagem a cada palavra da mesma linha.
  if(top<viewTop+24 || top+wordEl.offsetHeight>viewTop+transcript.clientHeight*.64){
    transcript.scrollTop=Math.max(0,top-transcript.clientHeight*.30);
  }
}
function syncSpeech({force=false}={}) {
  if(!state.words.length) {state.activeWord=-1;return;}
  const time=el('player').currentTime;
  const found=findWordAtTime(state.words,time);
  const idx=state.deleted.has(found)||state.cutCache.some(c=>time>=c.start&&time<c.end)?-1:found;
  if(!force && idx===state.activeWord) return;
  const previous=state.wordNodes?.[state.activeWord]||el('transcript').querySelector('.word.speaking');
  if(previous) previous.classList.remove('speaking');
  state.activeWord=idx;
  if(idx<0) return;
  const wordEl=state.wordNodes?.[idx]||el('transcript').querySelector(`[data-idx="${idx}"]`);
  if(wordEl){wordEl.classList.add('speaking');if(state.followSpeech)ensureWordVisible(wordEl);}
}
function followFrame(){
  state.animationFrame=0;
  if(el('player').paused || el('player').ended) return;
  skipCutIfNeeded();
  if(state.cutJump)return;
  syncSpeech();movePlayhead();
  state.animationFrame=requestAnimationFrame(followFrame);
}
function skipCutIfNeeded(){
  const player=el('player');
  if(!state.media||!state.cutCache.length||player.paused||state.cutJump)return;
  const t=player.currentTime;
  const cut=state.cutCache.find(x=>t>=x.start&&t<x.end);
  if(!cut)return;
  const next=playbackTarget(Math.max(t,cut.start),state.cutCache,state.media.duration);
  if(next.ended){player.pause();player.currentTime=Math.max(0,cut.start-1/(state.media.fpsNum/state.media.fpsDen));return;}
  // O HTMLVideoElement usa o original. Pausamos e silenciamos DURANTE a busca,
  // para nao emitir audio nem destacar palavras dos frames removidos.
  state.cutJump={target:next.time,resume:true,muted:player.muted};
  player.muted=true;player.pause();player.currentTime=Math.min(state.media.duration,next.time);
}
function startPlayback(){
  if(!state.media)return;
  const player=el('player');
  const next=playbackTarget(player.currentTime,state.cutCache,state.media.duration);
  if(next.ended){player.pause();return;}
  if(next.time>player.currentTime+0.001){
    state.cutJump={target:next.time,resume:true,muted:player.muted};
    player.muted=true;player.currentTime=Math.min(state.media.duration,next.time);
  }else player.play().catch(()=>toast('O navegador bloqueou a reprodução.',true));
}
function startFollowFrame(){
  if(state.animationFrame)cancelAnimationFrame(state.animationFrame);
  // Um clique na palavra pausa e suspende a rolagem; ao iniciar a reproducao
  // (Espaco ou controles do video), voltar a acompanhar a fala.
  if(!state.followSpeech)setFollowSpeech(true);
  skipCutIfNeeded();
  if(state.cutJump)return;
  syncSpeech({force:true});
  state.animationFrame=requestAnimationFrame(followFrame);
}
function stopFollowFrame(){
  if(state.animationFrame)cancelAnimationFrame(state.animationFrame);
  state.animationFrame=0;
  if(!state.cutJump)syncSpeech({force:true});
}
function renderTimeline(){
  if(!state.media){state.cutCache=[];el('summary').textContent='Sem vídeo';drawWaveform();return;}
  state.cutCache=cutRanges(state.words,state.deleted,state.extraCuts,state.media.duration);
  const sums=summarizeTimeline(state.media,state.words,state.deleted,state.extraCuts);
  el('summary').innerHTML=`Original: <b>${formatTime(sums.original)}</b> · Cortado: <b>${formatTime(sums.removed)}</b> · Final: <b>${formatTime(sums.edited)}</b> · <b>${sums.clips}</b> trechos${state.contextState==='error'?' · ⚠ Contexto pendente: confira Ferramentas':''}`;
  drawWaveform();
}
function viewData(){const duration=state.media?.duration||1;const span=Math.min(duration,Math.max(4,state.viewSpan||duration));const start=Math.max(0,Math.min(duration-span,state.viewStart||0));return {duration,span,start,end:start+span};}
function timecode(sec){
  const fps=(state.media?.fpsNum||30)/(state.media?.fpsDen||1),base=Math.round(fps);
  const t=Math.max(0,sec);const whole=Math.floor(t);const hh=Math.floor(whole/3600),mm=Math.floor(whole/60)%60,ss=whole%60,ff=Math.min(base-1,Math.floor((t-whole)*fps+.00001));
  return [hh,mm,ss,ff].map(n=>String(n).padStart(2,'0')).join(':');
}
function canvasSetup(canvas){const rect=canvas.getBoundingClientRect();const dpr=window.devicePixelRatio||1;const w=Math.max(1,Math.round(rect.width*dpr)),h=Math.max(1,Math.round(rect.height*dpr));if(canvas.width!==w||canvas.height!==h){canvas.width=w;canvas.height=h;}const ctx=canvas.getContext('2d');ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,rect.width,rect.height);return {ctx,w:rect.width,h:rect.height};}
function ticks(view,width){const fps=(state.media?.fpsNum||30)/(state.media?.fpsDen||1),pxFrame=width/(view.span*fps);let step;
  if(pxFrame>=8)step=1/fps;else if(view.span<=20)step=.25;else if(view.span<=60)step=1;else if(view.span<=180)step=5;else if(view.span<=600)step=15;else if(view.span<=2400)step=60;else step=300;
  const out=[];const first=Math.ceil((view.start-1e-8)/step);for(let i=first;i*step<=view.end+1e-7&&out.length<1000;i++){const t=i*step;out.push({time:t,x:(t-view.start)/view.span*width,frameLevel:pxFrame>=8});}return out;
}

function drawFilmstrip(){
 const canvas=el('thumbCanvas'); if(!canvas) return;
 const v=viewData(); const c=canvasSetup(canvas); const {ctx,w,h}=c;
 ctx.fillStyle='#0e1723'; ctx.fillRect(0,0,w,h);
 if(!state.media)return;
 const samples=filmstripSamples(v,w),segW=w/samples.length;
 for(let i=0;i<samples.length;i++){
   const time=samples[i],key=time.toFixed(2),x=i*segW;
   const img=state.thumbs.get(key);
   if(img?.complete&&img.naturalWidth){
     const sourceWidth=Math.min(img.naturalWidth,img.naturalHeight*segW/h);
     ctx.drawImage(img,(img.naturalWidth-sourceWidth)/2,0,sourceWidth,img.naturalHeight,x,0,segW+.5,h);
   }else{
     ctx.fillStyle='#203345';ctx.fillRect(x,0,segW,h);
     if(!img&&state.thumbPending<2){
       const thumb=new Image(),version=state.thumbVersion;
       state.thumbs.set(key,thumb);state.thumbPending++;
       thumb.onload=thumb.onerror=()=>{if(version!==state.thumbVersion)return;state.thumbPending--;drawFilmstrip();};
       thumb.src=`/api/thumbnail?t=${encodeURIComponent(time.toFixed(3))}`;
     }
   }
 }
 for(const cut of state.cutCache){
   const x1=Math.max(0,(cut.start-v.start)/v.span*w),x2=Math.min(w,(cut.end-v.start)/v.span*w);
   if(x2>x1){ctx.fillStyle='rgba(230,95,117,.55)';ctx.fillRect(x1,0,x2-x1,h);}
 }
 const fps=state.media.fpsNum/state.media.fpsDen;
 for(const frame of state.splitFrames){
   const x=(frame/fps-v.start)/v.span*w;
   if(x>=0&&x<=w){ctx.strokeStyle='#8cdbff';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,h);ctx.stroke();}
 }
 ctx.strokeStyle='rgba(255,255,255,.13)';
 for(let i=0;i<=samples.length;i++){const x=Math.round(i*segW)+.5;ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,h);ctx.stroke();}
 const t=el('player').currentTime||0;
 if(t>=v.start && t<=v.end){
   const x=(t-v.start)/v.span*w;
   ctx.strokeStyle='#ffd65a'; ctx.lineWidth=1; ctx.beginPath(); ctx.moveTo(x+.5,0); ctx.lineTo(x+.5,h); ctx.stroke();
 }
}

function drawWaveform(){
 const v=viewData(),canvas=el('waveCanvas'),ruler=el('rulerCanvas');if(!canvas||!ruler)return;
 drawFilmstrip();
 const c=canvasSetup(canvas),r=canvasSetup(ruler);const {ctx,w,h}=c;
 ctx.fillStyle='#121e2d';ctx.fillRect(0,0,w,h);
 for(const cut of state.cutCache){const x1=Math.max(0,(cut.start-v.start)/v.span*w),x2=Math.min(w,(cut.end-v.start)/v.span*w);if(x2>x1){ctx.fillStyle='rgba(230,95,117,.26)';ctx.fillRect(x1,0,x2-x1,h);}}
 const center=h/2;ctx.strokeStyle='#33495c';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(0,center);ctx.lineTo(w,center);ctx.stroke();
 if(state.wavePeaks.length){
   const peaks=state.wavePeaks,rate=state.waveRate||20;
   // Corpo RMS contrasta melhor fala x silêncios, enquanto picos finos preservam transientes.
   const n=Math.max(1,Math.floor(w)), samples=[];
   for(let x=0;x<n;x++){
     const t0=v.start+x/w*v.span,t1=v.start+(x+1)/w*v.span;
     const a=Math.max(0,Math.floor(t0*rate)),b=Math.min(peaks.length,Math.max(a+1,Math.ceil(t1*rate)));
     let max=0,sum=0,count=0;
     for(let k=a;k<b;k++){const p=peaks[k];max=Math.max(max,p);sum+=p*p;count++;}
     const rms=Math.sqrt(sum/Math.max(1,count));
     samples.push({max,rms});
   }
   const norm=Math.max(8,state.waveNorm||255);
   // Dinamica intencionalmente NÂO comprimida: deixa as pausas visiveis.
   // Em zoom distante, mostrar RMS por janela (nao o maior pico por pixel).
   const ampAt=s=>s.rms<=norm*.055?0:Math.pow(Math.min(1,s.rms/norm),1.65)*(h*.43);
   ctx.fillStyle='rgba(25,159,148,.23)';ctx.beginPath();ctx.moveTo(0,center);
   for(let x=0;x<n;x++)ctx.lineTo(x,center-ampAt(samples[x]));
   for(let x=n-1;x>=0;x--)ctx.lineTo(x,center+ampAt(samples[x]));
   ctx.closePath();ctx.fill();
   ctx.strokeStyle='#42ddc2';ctx.lineWidth=1;ctx.beginPath();
   for(let x=0;x<n;x++){
     const amp=ampAt(samples[x]);if(amp<1)continue;
     ctx.moveTo(x+.5,center-amp);ctx.lineTo(x+.5,center+amp);
   }ctx.stroke();
   // Transientes individuais somente quando ha resolucao temporal suficiente.
   if(v.span<=120){
     ctx.strokeStyle='rgba(200,255,243,.28)';ctx.lineWidth=.65;ctx.beginPath();
     for(let x=0;x<n;x++){
       const amp=Math.pow(Math.min(1,samples[x].max/norm),1.4)*(h*.44);
       if(amp<2)continue;ctx.moveTo(x+.5,center-amp);ctx.lineTo(x+.5,center+amp);
     }ctx.stroke();
   }
 }
 const tt=ticks(v,w);for(const p of tt){ctx.strokeStyle=p.frameLevel?'rgba(173,192,207,.22)':'rgba(118,155,179,.12)';ctx.beginPath();ctx.moveTo(Math.round(p.x)+.5,0);ctx.lineTo(Math.round(p.x)+.5,h);ctx.stroke();}
 const rr=r.ctx;rr.fillStyle='#a9c1d3';rr.font='11px Consolas,monospace';rr.textBaseline='middle';
 const minLabel=70;let prev=-1e9;for(const p of tt){rr.strokeStyle='#547086';rr.beginPath();rr.moveTo(p.x,r.h-11);rr.lineTo(p.x,r.h);rr.stroke();if(p.x-prev>minLabel){rr.fillText(p.frameLevel?timecode(p.time):formatTime(p.time),p.x+3,11);prev=p.x;}}
 const pan=el('timelinePan');pan.disabled=v.span>=v.duration-.001;pan.value=String(Math.round(1000*v.start/Math.max(.001,v.duration-v.span)));
 el('timelineZoom').textContent=v.span>=v.duration-.001?'Vídeo inteiro':`${v.span<60?v.span.toFixed(1)+'s':formatTime(v.span)} visíveis`;
 drawSplitMarkers();
 drawRangeSelection();
 movePlayhead();
}
function drawSplitMarkers(){
 const node=el('splitMarkers');if(!state.media){node.innerHTML='';return;}
 const v=viewData(),fps=state.media.fpsNum/state.media.fpsDen;
 node.innerHTML=state.splitFrames.map(frame=>frame/fps).filter(time=>time>=v.start&&time<=v.end)
   .map(time=>`<span class="split-marker" style="left:${100*(time-v.start)/v.span}%" title="Divisão ${timecode(time)}"></span>`).join('');
}
function splitAtPlayhead(){
 if(!state.media||state.busy)return;
 const player=el('player');player.pause();cancelCutJump();
 const fps=state.media.fpsNum/state.media.fpsDen,total=Math.round(state.media.duration*fps);
 const frame=splitFrameAt(player.currentTime,total,fps);
 if(frame===null)return toast('Posicione o cursor dentro do vídeo para marcar o corte.',true);
 if(state.splitFrames.includes(frame))return toast(`Já existe uma divisão em ${timecode(frame/fps)}.`,true);
 snapshot();state.splitFrames.push(frame);state.splitFrames.sort((a,b)=>a-b);
 clearTimelineRange();drawWaveform();
 el('rangeStatus').textContent=`Divisão em ${timecode(frame/fps)} · posicione o cursor no fim e pressione C novamente.`;
 toast(`Divisão marcada em ${timecode(frame/fps)}. Nada foi removido.`);
}
function selectSplitSegment(time){
 if(!state.splitFrames.length||!state.media)return;
 const fps=state.media.fpsNum/state.media.fpsDen;
 const segment=segmentAtTime(time,state.splitFrames,Math.round(state.media.duration*fps),fps);
 if(segment)setTimelineRange(segment.start,segment.end,true);
}
function drawRangeSelection(){
 const node=el('rangeSelection'),range=state.timelineRange;
 if(!state.media||!range||range.end<=range.start){node.hidden=true;return;}
 const v=viewData(),start=Math.max(v.start,range.start),end=Math.min(v.end,range.end);
 if(end<=start){node.hidden=true;return;}
 node.hidden=false;node.style.left=`${100*(start-v.start)/v.span}%`;
 node.style.width=`${100*(end-start)/v.span}%`;
}
function setTimelineRange(first,second,fromSplit=false){
 if(!state.media)return;
 state.timelineRange=fromSplit?{start:first,end:second}:manualCutRange(first,second,state.media.duration);
 el('deleteRange').disabled=!state.timelineRange;
 el('rangeStatus').textContent=state.timelineRange?`Selecionado ${timecode(state.timelineRange.start)} a ${timecode(state.timelineRange.end)} · Delete remove`:'Arraste entre dois pontos da onda para selecionar.';
 drawRangeSelection();
}
function clearTimelineRange(){state.timelineRange=null;el('deleteRange').disabled=true;el('rangeStatus').textContent='Posicione · C divide · clique no trecho · Delete remove · Ctrl+Z desfaz';drawRangeSelection();}
function deleteTimelineRange(){
 if(!state.timelineRange||state.busy)return;
 snapshot();state.extraCuts.push(state.timelineRange);clearTimelineRange();
 state.rangeMode=false;el('rangeMode').classList.remove('selected');el('rangeMode').setAttribute('aria-pressed','false');
 updateAll();toast('Intervalo removido da prévia. Ctrl+Z desfaz; o vídeo original permanece intacto.');
}
function restoreTimelineCut(time){
 if(!state.media||state.busy)return false;
 const cut=state.cutCache.find(c=>time>=c.start&&time<c.end);
 if(!cut)return false;
 snapshot();
 state.extraCuts=state.extraCuts.filter(c=>c.end<=cut.start||c.start>=cut.end);
 state.deleted=new Set([...state.deleted].filter(i=>{
   const word=state.words[i];return !word||word.end+.018<=cut.start||word.start-.018>=cut.end;
 }));
 clearTimelineRange();updateAll();toast('Corte restaurado na timeline e na transcrição.');
 return true;
}
function movePlayhead(){
 const h=el('playhead');if(!state.media){h.hidden=true;return;}
 let v=viewData();const t=el('player').currentTime;
 if((t<v.start||t>v.end-.08)&&!el('player').paused){
   state.viewStart=Math.max(0,Math.min(v.duration-v.span,t-v.span*.12));
   v=viewData();drawWaveform();
 }
 if(t<v.start||t>v.end){h.hidden=true;return;}
 h.hidden=false;h.style.left=`${100*(t-v.start)/v.span}%`;
 drawFilmstrip();
}

function changeZoom(dir){if(!state.media)return;const duration=state.media.duration;const old=viewData();const center=el('player').currentTime||old.start+old.span/2;const next=dir===0?duration:Math.max(4,Math.min(duration,dir>0?old.span/2:old.span*2));state.viewSpan=next;state.viewStart=Math.max(0,Math.min(duration-next,center-next/2));drawWaveform();}
async function loadWaveform(){
 const original=state.path;const status=el('waveStatus');status.textContent='Preparando forma de onda local...';status.hidden=false;
 for(let i=0;i<100;i++){
   if(original!==state.path)return;
   try{
     const result=await api('waveform');
     if(original!==state.path)return;
     if(result.state==='done'){state.wavePeaks=result.peaks||[];state.waveRate=result.rate||20;const sample=state.wavePeaks.filter((_,i)=>i%Math.max(1,Math.floor(state.wavePeaks.length/4000))===0).sort((a,b)=>a-b);state.waveNorm=Math.max(12,sample[Math.floor(sample.length*.96)]||255);status.hidden=true;drawWaveform();renderAudioWarnings();updateSilenceEstimate();if(state.autoSilencePending)applySilenceFromWaveform(true);return;}
     if(result.state==='error'){status.textContent='Não foi possível gerar a onda. A edição continua disponível.';return;}
   }catch{status.textContent='Onda indisponível. A edição continua disponível.';return;}
   await pause(900);
 }
 status.textContent='Áudio não disponível para forma de onda.';
}
async function loadVad(){
 const original=state.path;
 for(let i=0;i<180;i++){
   if(original!==state.path)return;
   try{
     const result=await api('vad');
     if(original!==state.path)return;
     if(result.state==='done'){
       state.vadSpeech=result.speech||[];state.vadState='done';
       el('acousticStatus').textContent=`Silero VAD: ${state.vadSpeech.length} regiões de voz${result.cached?' (cache)':''}. Voz sem legenda fica protegida.`;
       renderAudioWarnings();updateSilenceEstimate();if(state.autoSilencePending)applySilenceFromWaveform(true);return;
     }
     if(result.state==='error'){
       state.vadState='error';state.autoSilencePending=false;
       el('acousticStatus').textContent='Silero indisponível: '+(result.message||'verifique a instalação')+'. Nenhum silêncio será cortado.';return;
     }
   }catch{state.vadState='error';state.autoSilencePending=false;el('acousticStatus').textContent='Silero indisponível. Nenhum silêncio será cortado.';return;}
   await pause(1000);
 }
 state.vadState='error';state.autoSilencePending=false;el('acousticStatus').textContent='Análise Silero excedeu o tempo. Nenhum silêncio será cortado.';
}
function cancelCutJump(){if(state.cutJump){el('player').muted=state.cutJump.muted;state.cutJump=null;}}
function seekFromTimeline(event){if(!state.media)return;const rect=el('timeline').getBoundingClientRect();const v=viewData();const player=el('player');cancelCutJump();player.pause();player.currentTime=timeAtClientX(event.clientX,rect,v);movePlayhead();syncSpeech({force:true});}
function hoverTimeline(event){
 if(!state.media)return;
 const node=el('timeline'),rect=node.getBoundingClientRect(),view=viewData();
 const x=Math.max(0,Math.min(rect.width,event.clientX-rect.left));
 const t=timeAtClientX(event.clientX,rect,view);
 const head=el('hoverhead');head.hidden=false;head.style.left=`${x}px`;
 const label=el('hoverTime');label.textContent=timecode(t);label.style.left=x>rect.width-110?'-112px':'6px';
 const idx=findWordAtTime(state.words,t);
 if(idx>=0 && idx!==state.activeWord){ const prev=el('transcript').querySelector('.word.previewing'); if(prev) prev.classList.remove('previewing'); const cur=el('transcript').querySelector(`[data-idx="${idx}"]`); if(cur) cur.classList.add('previewing'); }
}
function unhoverTimeline(){el('hoverhead').hidden=true; const prev=el('transcript').querySelector('.word.previewing'); if(prev) prev.classList.remove('previewing');}

function renderAudioWarnings(){
 const box=el('audioReview');if(!box)return;
 const gaps=state.media&&state.words.length?reviewableAudioGaps(state.words,state.media.duration,state.wavePeaks,state.waveRate,{norm:state.waveNorm,speech:state.vadSpeech}):[];
 state.reviewGaps=gaps.filter(g=>g.end-g.start>=1&&!state.cutCache.some(c=>c.start<=g.start+.04&&c.end>=g.end-.04));
 el('audioReviewCount').textContent=state.reviewGaps.length?`(${state.reviewGaps.length})`:'';
 const limit=state.reviewExpanded?30:6;
 box.innerHTML=state.reviewGaps.length?state.reviewGaps.slice(0,limit).map((g,i)=>`<div class="audio-review-item"><span>${formatTime(g.start)}–${formatTime(g.end)} · ${safe(g.reason)}</span><div><button class="audio-warning" type="button" data-audio-time="${g.start}">▶ Ir ao trecho</button><button class="audio-warning" type="button" data-review-range="${i}">Selecionar</button></div></div>`).join(''):'<p class="hint">Nenhum trecho pendente.</p>';
 el('moreAudioReview').hidden=state.reviewGaps.length<=limit;
}
function updateAll(){renderWords();renderTimeline();syncSpeech({force:true});updateSelectionUi();renderAudioWarnings();renderAutoSuggestions();updateSilenceEstimate();scheduleAutosave();}
function resetTranscript(){state.contextState='idle';clearNativeSelection();state.words=[];el('semanticStatus').textContent='';el('roughCutStatus').textContent='Aguardando edição bruta.';state.deleted=new Set();state.extraCuts=[];state.proposals=[];state.page=0;state.autoSuggestions=[];state.history=[];state.selection=null;state.selectionAnchor=null;state.cutCache=[];state.activeWord=-1;el('silencesBox').innerHTML='';renderAutoSuggestions();updateAll();}
function homeProgress(percent,message){
 const value=Math.max(0,Math.min(100,Math.round(percent)));
 el('homeProcessStatus').textContent=message;
 el('homeProgressFill').style.width=`${value}%`;
 el('homeProgressTrack').setAttribute('aria-valuenow',String(value));
 el('homeProgressNumber').textContent=`${value}%`;
}
async function prepareVideo(path,media){
 el('editorialContext').value='';resetTranscript();setVideo(path,media,{openEditor:false});rememberRecent('video',path,media.name);
 showHome();el('homeProcess').hidden=false;el('homeProcessName').textContent=media.name;
 el('homeRetry').hidden=true;homeProgress(0,'Vídeo selecionado. Preparando análise...');
 if(el('homeApiKey').value.trim()||el('apiKey').value.trim())await analyzeHomeVideo();
 else{el('homeKeyForm').hidden=false;homeProgress(0,'Informe sua chave Groq para iniciar a transcrição.');el('homeApiKey').focus();}
}
async function analyzeHomeVideo(){
 const key=el('homeApiKey').value.trim()||el('apiKey').value.trim();
 if(!key){el('homeKeyForm').hidden=false;el('homeApiKey').focus();return;}
 el('apiKey').value=key;el('homeKeyForm').hidden=true;el('homeRetry').hidden=true;
 try{
   busy(true);homeProgress(1,'Preparando áudio...');
   await transcribe({onProgress:job=>{
     const done=Number(job.done)||0,total=Math.max(1,Number(job.total)||1);
     homeProgress(job.state==='done'?95:Math.min(94,Math.floor(94*done/total)),job.message||'Transcrevendo áudio...');
   },throwOnError:true});
   homeProgress(96,'Identificando voz, pausas e possíveis erros de gravação...');
   await state.analysisTasks;
   if(state.autoSilencePending)applySilenceFromWaveform(true);
   homeProgress(100,'Análise concluída. Abrindo editor...');
   el('homeProcess').hidden=true;showEditor();updateAll();
 }catch(err){
   homeProgress(0,`Não foi possível concluir: ${err.message||err}`);
   el('homeKeyForm').hidden=false;
   el('homeRetry').hidden=false;
 }finally{busy(false);}
}
async function selectVideo(){
  try {busy(true);const result=await api('choose',{kind:'video'});if(result.cancelled)return;
    await prepareVideo(result.path,result.media);
  }catch(e){toast(String(e),true);}finally{busy(false);}
}
async function createPreview() {
  if(!state.media)return toast('Importe um vídeo primeiro.',true);
  if(!confirm('Criar uma prévia de baixa resolução pode usar bastante CPU enquanto é preparada. Deseja continuar?'))return;
  try {busy(true);await api('preview',{});const result=await waitJob();
    el('player').src=result.preview+'&cache='+Date.now();el('player').load();
    toast('Prévia 480p pronta. O vídeo original continua intacto.');
  }catch(e){toast(String(e),true);}finally{busy(false);}
}
async function editContextAutomatically(key){
 try{
   state.contextState='running';el('semanticStatus').textContent='Editando tomadas e falas laterais com Groq...';
   await api('review_takes',{apiKey:key,words:state.words,context:el('editorialContext').value||state.projectName});
   const result=await waitJob(job=>{el('semanticStatus').textContent=job.message||'Analisando contexto...';});
   const candidates=(result.suggestions||[]).filter(s=>Number.isInteger(s.from)&&Number.isInteger(s.to)&&s.from>=0&&s.to>=s.from&&s.to<state.words.length);
   const automatic=candidates.filter(s=>s.requiresReview===false&&s.confidence==='alta');
   const selected=new Set(automatic.flatMap(s=>Array.from({length:s.to-s.from+1},(_,i)=>s.from+i)));
   if(selected.size&&new Set([...state.deleted,...selected]).size<state.words.length){
     snapshot();for(const i of selected)state.deleted.add(i);
   }
   state.autoSuggestions=[...state.autoSuggestions.filter(s=>s.origin!=='groq'),...candidates].sort((a,b)=>a.start-b.start);
   state.contextState='done';updateAll();
   el('semanticStatus').textContent=`Contexto analisado: ${automatic.length} corte(s) de alta confiança; ${candidates.length-automatic.length} sugestão(ões) para conferir. A IA pode errar; clique direito restaura.`;
   el('roughCutStatus').textContent='Edição local e análise de contexto concluídas. Revise e exporte para finalizar no DaVinci.';
   return true;
 }catch(error){
   state.contextState='error';renderTimeline();
   el('semanticStatus').textContent=`Contexto pendente: ${error.message||error}. Os cortes locais foram preservados.`;
   el('roughCutStatus').textContent='Edição local pronta; a etapa de contexto não foi concluída. Tente Editar automaticamente novamente.';
   toast('A etapa de contexto falhou; somente os cortes locais estão aplicados.',true);
   return false;
 }
}
el('autoRoughCut').onclick=async()=>{
 if(state.busy||!state.words.length)return;
 snapshot();
 const suggestions=analyzeTranscript(state.words,state.media.duration);
 const local=automaticCuts(suggestions,state.words);
 for(const i of local.deleted)state.deleted.add(i);
 state.autoSuggestions=suggestions.filter(s=>s.type!=='silence');updateAll();
 applySilenceFromWaveform(true);
 const key=el('apiKey').value.trim();
 if(el('fullAutoEdit').checked&&key){busy(true);try{await editContextAutomatically(key);}finally{busy(false);}}
 else el('roughCutStatus').textContent=el('fullAutoEdit').checked?'Edição local aplicada. Informe a chave Groq para executar o contexto.':'Edição local aplicada. A etapa Groq está desativada na tela inicial.';
};
async function transcribe({onProgress=()=>{},throwOnError=false}={}){if(!state.media)return toast('Selecione primeiro um vídeo.',true);const apiKey=el('apiKey').value.trim();if(!apiKey)return toast('Informe sua chave Groq gratuita.',true);
  if(state.words.length&&!confirm('Refazer a transcrição apagará os cortes atuais. Deseja continuar?'))return;
  try{busy(true);el('progress').textContent='Preparando áudio...';await api('transcribe',{apiKey,model:el('model').value});const data=await waitJob(onProgress);resetTranscript();state.words=data.words;state.model=data.model;const suggestions=analyzeTranscript(state.words,state.media.duration);const auto=automaticCuts(suggestions,state.words);state.deleted=auto.deleted;state.autoSuggestions=suggestions.filter(s=>s.type!=='silence');setFollowSpeech(true);updateAll();
    state.autoSilencePending=el('autoSilenceEnabled').checked;
    if(state.autoSilencePending)applySilenceFromWaveform(true);
    if(el('fullAutoEdit').checked)await editContextAutomatically(apiKey);
    toast(`${state.words.length} palavras transcritas; ${state.deleted.size} palavras cortadas na edição bruta. Clique direito restaura.`);el('progress').textContent=`Concluído • ${data.chunks} partes • ${data.model}`;
  }catch(e){el('progress').textContent='Erro de transcrição';if(throwOnError)throw e;toast(String(e),true);}finally{busy(false);}}
function applySilenceFromWaveform(automatic=false){
 if(state.busy&&!automatic)return;
 if(!state.media||!state.words.length)return;
 if(!state.wavePeaks.length||state.vadState!=='done'||!state.vadSpeech){
   el('acousticStatus').textContent=state.vadState==='error'?'Silero indisponível: nenhum silêncio será cortado.':'Aguardando Silero e forma de onda. Nenhum corte aplicado ainda.';
   if(!automatic)toast('Aguarde a forma de onda do áudio ficar pronta.',true);
   return;
 }
 const ranges=detectVerifiedSilences(state.words,state.media.duration,state.wavePeaks,state.waveRate,silenceOptions());
 state.autoSilencePending=false;
 if(!ranges.length){el('acousticStatus').textContent='Nenhum silêncio longo confirmado acusticamente.';if(!automatic)toast('Nenhum silêncio confirmado para cortar.');return;}
 const fresh=freshSilenceRanges(ranges);
 if(!fresh.length){el('acousticStatus').textContent='Silêncios já cortados neste projeto.';if(!automatic)toast('Os silêncios encontrados já estavam cortados.');return;}
 if(!automatic&&!confirm(`Cortar ${fresh.length} silêncios confirmados pelo áudio? Use Ctrl+Z para desfazer.`))return;
 snapshot();state.extraCuts.push(...fresh);updateAll();
 const secs=fresh.reduce((sum,c)=>sum+c.end-c.start,0);
 el('acousticStatus').textContent=`${fresh.length} silêncios acústicos cortados (${secs.toFixed(1)} s). Ctrl+Z desfaz.`;
 toast(`${fresh.length} silêncios cortados com proteção reforçada das falas. Revise antes de exportar.`);
}
el('applyVerifiedSilences').onclick=()=>applySilenceFromWaveform(false);
function proposeSilences(){if(!state.words.length)return toast('Transcreva o vídeo antes de procurar pausas.',true);state.proposals=suggestSilences(state.words,state.media.duration,0.72,0.14);const box=el('silencesBox');if(!state.proposals.length){box.innerHTML='<p class="hint">Nenhum intervalo longo encontrado.</p>';return;}
  box.innerHTML=`<p>${state.proposals.length} intervalos sem palavras reconhecidas.</p><p class="hint">Sem palavras na transcrição pode haver fala não reconhecida. Só o Silero com áudio baixo pode confirmar silêncio. Ouça os alertas de áudio; aqui não há corte em lote.</p>`;}
async function exportXml(){if(!state.media||!state.words.length)return toast('É preciso transcrever antes de exportar.',true);
  try{const xml=exportFcp7Xml({path:state.path,media:state.media,words:state.words,deletedIndices:state.deleted,extraCuts:state.extraCuts,sequenceName:`Magic Edit - ${state.projectName}`});
    const r=await api('save',{kind:'xml',default:`${fileSafe(state.projectName)}_editado.xml`,contents:xml});if(r.cancelled)return;toast('XML exportado! Importe como Timeline no DaVinci Resolve.');
  }catch(e){toast(String(e),true);}}
async function exportMp4(){
 if(!state.media)return toast('Selecione um vídeo antes de exportar.',true);
 const fps=state.media.fpsNum/state.media.fpsDen;
 const segments=keepRanges(state.media.duration,cutRanges(state.words,state.deleted,state.extraCuts,state.media.duration),fps);
 if(!segments.length)return toast('Todos os trechos foram cortados; restaure um para exportar.',true);
 const showProgress=(percent,message)=>{
   const n=Math.max(0,Math.min(100,Math.floor(percent)));
   el('mp4ExportStatus').hidden=false;
   el('mp4ProgressTrack').setAttribute('aria-valuenow',String(n));
   el('mp4ProgressFill').style.width=`${n}%`;
   el('mp4Progress').textContent=`${n}% · ${message}`;
 };
 try{
   busy(true);el('mp4FinalPath').hidden=true;el('mp4FinalPath').textContent='';
   showProgress(0,'Escolha onde salvar o vídeo final...');
   const response=await api('export_mp4',{segments,default:`${fileSafe(state.projectName)}_bruto_editado.mp4`});
   if(response.cancelled){el('mp4ExportStatus').hidden=true;return;}
   const result=await waitJob(job=>{
     const percent=job.state==='done'?100:Math.min(99,100*(Number(job.done)||0)/Math.max(1,Number(job.total)||1));
     showProgress(percent,job.message||'Renderizando vídeo final...');
   });
   showProgress(100,'Vídeo final pronto. Um arquivo MP4 foi salvo em:');
   el('mp4FinalPath').textContent=result.path;
   el('mp4FinalPath').hidden=false;
   toast('MP4 final salvo. Veja o caminho completo abaixo da timeline.');
 }catch(err){el('mp4Progress').textContent=`Exportação interrompida: ${err.message||err}`;toast(String(err),true);}finally{busy(false);}
}
async function saveProject(){if(!state.media||!state.words.length)return toast('Transcreva um vídeo antes de salvar o projeto.',true);
  try{const doc=projectDocument();
    const r=await api('save',{kind:'json',default:`${fileSafe(state.projectName)}_MagicEdit.json`,contents:JSON.stringify(doc)});if(!r.cancelled){rememberRecent('project',r.path,state.projectName);toast('Projeto salvo no seu computador.');}
  }catch(e){toast(String(e),true);}}
async function loadProject(recentPath=null,recovered=null){try{const file=recovered?{path:null,text:JSON.stringify(recovered)}:recentPath?await api('open_project',{path:recentPath}):await api('choose',{kind:'project'});if(file.cancelled)return;
    const doc=JSON.parse(file.text);
    if(doc.schema!==1||!Array.isArray(doc.words)||!doc.media||!doc.path)throw Error('Formato de projeto inválido.');
    if(doc.words.some(w=>!w||!Number.isFinite(w.start)||!Number.isFinite(w.end)||w.end<w.start||typeof w.word!=='string'))throw Error('Projeto com tempos de palavras inválidos; arquivo preservado.');
    busy(true);const realMedia=await api('set_video',{path:doc.path});resetTranscript();setVideo(realMedia.path,realMedia.media);
    state.words=doc.words;
    state.projectName=String(doc.projectName||realMedia.media.name.replace(/\.[^.]+$/,''));el('projectNameInput').value=state.projectName;
    state.extraCuts=(doc.extraCuts||[]).filter(x=>Number.isFinite(x.start)&&Number.isFinite(x.end));
    const totalFrames=Math.round(state.media.duration*state.media.fpsNum/state.media.fpsDen);
    state.splitFrames=[...new Set((Array.isArray(doc.splitFrames)?doc.splitFrames:[]).filter(frame=>Number.isInteger(frame)&&frame>0&&frame<totalFrames))].sort((a,b)=>a-b);
    state.model=doc.model||'whisper-large-v3';state.autoSilencePending=false;
    el('editorialContext').value=typeof doc.editorialContext==='string'?doc.editorialContext:'';
    const suggestions=analyzeTranscript(state.words,state.media.duration);
    state.deleted=projectCutsOnOpen(doc,suggestions,state.words);
    state.autoSuggestions=Array.isArray(doc.editingReport)?doc.editingReport.filter(s=>s&&Number.isInteger(s.from)&&Number.isInteger(s.to)&&s.from>=0&&s.to>=s.from&&s.to<state.words.length):suggestions.filter(s=>s.type!=='silence');
    state.pendingResumeTime=Number.isFinite(doc.playhead)?Math.max(0,Math.min(doc.playhead,state.media.duration)):null;
    if(state.pendingResumeTime!==null)el('player').currentTime=state.pendingResumeTime;
    setFollowSpeech(true);updateAll();if(state.autoSilencePending)applySilenceFromWaveform(true);
    if(!recovered)rememberRecent('project',file.path,state.projectName);
    toast(recovered?'Edição recuperada. Confira o ponto e continue com Espaço.':'Projeto restaurado com os cortes salvos. Nenhuma edição automática foi refeita.');
  }catch(e){toast(String(e),true);}finally{busy(false);}}

el('homeImport').onclick=selectVideo;el('homeOpen').onclick=()=>loadProject();el('backHome').onclick=showHome;
el('homeContinue').onclick=()=>{if(state.recovery)return loadProject(null,state.recovery);};
el('moreAudioReview').onclick=()=>{state.reviewExpanded=true;renderAudioWarnings();};
el('markNewRestarts').onclick=()=>{
 if(!state.words.length)return toast('Abra um projeto transcrito para revisar as tentativas.',true);
 const candidates=analyzeTranscript(state.words,state.media.duration).filter(s=>s.type==='restart'&&s.reason.startsWith('Tentativa interrompida'));
 const fresh=candidates.flatMap(s=>Array.from({length:s.to-s.from+1},(_,i)=>s.from+i)).filter(i=>!state.deleted.has(i));
 if(!fresh.length)return toast('Não há novas tentativas interrompidas para marcar.');
 snapshot();for(const i of fresh)state.deleted.add(i);
 state.autoSuggestions=analyzeTranscript(state.words,state.media.duration).filter(s=>s.type!=='silence');
 updateAll();toast(`${candidates.length} tentativa(s) marcadas para revisão. Clique direito restaura.`);
};
el('reviewTakesGroq').onclick=async()=>{
 if(!state.words.length)return toast('Abra primeiro um vídeo transcrito.',true);
 const key=el('apiKey').value.trim();
 if(!key)return toast('Informe a chave Groq em Ferramentas > Transcrição.',true);
 if(!confirm('Esta revisão envia o TEXTO transcrito para a Groq e usa a cota da sua conta. Confira seu plano no painel Groq. Continuar?'))return;
 try{
   busy(true);el('semanticStatus').textContent='Preparando revisão textual...';
   await api('review_takes',{apiKey:key,words:state.words,context:el('editorialContext').value||state.projectName});
   const result=await waitJob(job=>{el('semanticStatus').textContent=job.message||'Revisando tomadas...';});
   const candidates=(result.suggestions||[]).filter(s=>Number.isInteger(s.from)&&Number.isInteger(s.to)&&
     s.from>=0&&s.to>=s.from&&s.to<state.words.length).map(s=>({...s,requiresReview:true}));
   const previous=state.autoSuggestions.filter(s=>s.origin!=='groq');
   const extra=candidates.filter(s=>!previous.some(old=>{
     const overlap=Math.max(0,Math.min(s.to,old.to)-Math.max(s.from,old.from)+1);
     return overlap/Math.max(1,Math.min(s.to-s.from+1,old.to-old.from+1))>=.7;
   }));
   state.autoSuggestions=[...previous,...extra]
     .sort((a,b)=>a.start-b.start);
   renderAutoSuggestions();
   el('semanticStatus').textContent=`${extra.length} possível(is) tomada(s) para conferir. Nenhuma fala foi cortada pela revisão Groq.`;
   el('autoSuggestions').querySelector('details[data-auto-type="restart"]')?.setAttribute('open','');
 }catch(err){el('semanticStatus').textContent=`Revisão não concluída: ${err.message||err}`;toast(String(err),true);}
 finally{busy(false);}
};
el('homeKeyForm').onsubmit=e=>{e.preventDefault();analyzeHomeVideo();};
el('homeRetry').onclick=analyzeHomeVideo;
el('audioReview').addEventListener('click',e=>{
 const selected=e.target.closest('[data-review-range]');
 if(selected){const gap=state.reviewGaps[Number(selected.dataset.reviewRange)];if(!gap)return;el('toolsMenu').open=false;cancelCutJump();el('player').pause();el('player').currentTime=gap.start;setTimelineRange(gap.start,gap.end);movePlayhead();syncSpeech({force:true});toast('Trecho selecionado para revisão. Ouça e pressione Delete se quiser retirar.');return;}
 const target=e.target.closest('[data-audio-time]');if(!target)return;el('toolsMenu').open=false;cancelCutJump();el('player').pause();el('player').currentTime=Number(target.dataset.audioTime);syncSpeech({force:true});movePlayhead();
});
el('recentProjects').addEventListener('click',async e=>{
  const remove=e.target.closest('[data-recent-remove]');
  if(remove){e.stopPropagation();if(!state.busy)await removeRecent(Number(remove.dataset.recentRemove));return;}
  const node=e.target.closest('[data-recent]');if(!node||state.busy)return;
  const item=recentItems()[Number(node.dataset.recent)];if(!item)return;
  if(item.kind==='project'){await loadProject(item.path);return;}
  try{busy(true);const media=await api('set_video',{path:item.path});await prepareVideo(media.path,media.media);}
  catch(err){toast(`Não foi possível abrir ${item.name}: ${err.message}`,true);}finally{busy(false);}
});
el('recentProjects').addEventListener('error',e=>{if(e.target.tagName==='IMG'&&e.target.closest('.recent-thumb'))e.target.hidden=true;},true);

el('undo').onclick=()=>{if(!state.history.length)return toast('Nenhuma edição anterior para desfazer.');const prev=state.history.pop();state.deleted=new Set(prev.deleted);state.extraCuts=prev.extraCuts.map(c=>({...c}));state.splitFrames=prev.splitFrames||[];clearTimelineRange();state.selection=null;clearNativeSelection();updateAll();toast('Última edição desfeita.');};
el('preview').onclick=createPreview;el('pickVideo').onclick=selectVideo;el('transcribe').onclick=()=>transcribe();el('silences').onclick=proposeSilences;el('exportXml').onclick=exportXml;el('exportMp4').onclick=exportMp4;el('saveProject').onclick=saveProject;el('loadProject').onclick=()=>loadProject();
// V07 — selecao NATIVA do navegador, igual a editor de texto (Word).
// Clique reproduz; arraste seleciona caracteres/palavras continuamente;
// clique direito transforma a selecao em corte/restauracao de video e audio.
const transcript=el('transcript');
const getWord=e=>wordFromPoint(e,transcript);
function restoreTextMarker(idx){
 if(!Number.isInteger(idx)||!state.extraCuts[idx])return;
 el('player').pause();snapshot();state.extraCuts.splice(idx,1);updateAll();toast('Áudio restaurado no texto e na timeline.');
}
transcript.addEventListener('click',e=>{
 const button=e.target.closest('[data-restore-cut]');if(!button)return;
 restoreTextMarker(Number(button.dataset.restoreCut));
});
let pressedWord=null;
function positionAtWord(idx){
  const word=state.words[idx];if(!word)return;
  clearSelection();setFollowSpeech(false);
  const player=el('player');
  cancelCutJump();player.pause();
  player.currentTime=Math.max(0,word.start);
  movePlayhead();syncSpeech({force:true});
}
transcript.addEventListener('mousedown',e=>{
  if(e.button!==0)return;
  const word=getWord(e);pressedWord=word?Number(word.dataset.idx):null;
  if(word){
    el('player').pause();setFollowSpeech(false);
    // Deixar o navegador criar a selecao nativa, sem preventDefault.
    if(e.shiftKey){
      const anchor=state.selectionAnchor??state.selection?.start??pressedWord;
      e.preventDefault();selectRange(anchor,pressedWord);restoreNativeSelection();
      pressedWord=null;
    }
  }
});
transcript.addEventListener('mouseup',e=>{
  if(e.button!==0)return;
  const selected=nativeSelectedWords();
  if(selected){state.selectionAnchor=selected.start;state.selection=selected;updateSelectionUi();pressedWord=null;return;}
  if(pressedWord!==null){const idx=pressedWord;pressedWord=null;state.selectionAnchor=idx;positionAtWord(idx);}
});
transcript.addEventListener('dblclick',()=>{
  // Selecao por duplo clique funciona como no Word.
  const selected=nativeSelectedWords();if(selected){state.selection=selected;updateSelectionUi();}
});
transcript.addEventListener('contextmenu',e=>{
  const marker=e.target.closest?.('[data-restore-cut]');
  if(marker){e.preventDefault();restoreTextMarker(Number(marker.dataset.restoreCut));return;}
  const word=getWord(e);if(!word)return;
  e.preventDefault();
  const idx=Number(word.dataset.idx);
  // Se o clique direito cair dentro da selecao, cortar/restaurar a frase.
  const {covered}=transcriptCutMarkers(state.words,state.extraCuts);
  const effective=new Set([...state.deleted,...covered]);
  const range=chooseRange(effective,state.selection,idx,state.words.length);
  if(!range)return;
  state.selectionAnchor=range.start;applyCut(range);
});
el('selectionAction').onclick=()=>applyCut(state.selection);
el('clearSelection').onclick=clearSelection;

el('search').addEventListener('change',e=>{const term=e.target.value.trim().toLocaleLowerCase('pt-BR');if(!term)return;const found=state.words.findIndex(w=>w.word.toLocaleLowerCase('pt-BR').includes(term));if(found<0)return toast('Palavra não encontrada.');setFollowSpeech(false);el('transcript').querySelector(`[data-idx="${found}"]`)?.scrollIntoView({block:'center'});});
el('followSpeech').onclick=()=>setFollowSpeech(!state.followSpeech);
el('transcript').addEventListener('wheel',()=>{if(state.followSpeech)setFollowSpeech(false);},{passive:true});
el('transcript').addEventListener('touchstart',()=>{if(state.followSpeech)setFollowSpeech(false);},{passive:true});
document.querySelectorAll('[data-speed]').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll('[data-speed]').forEach(v=>v.classList.remove('selected'));b.classList.add('selected');el('player').playbackRate=Number(b.dataset.speed);}));
el('player').addEventListener('error',()=>{if(state.path)toast('Seu vídeo pode usar um codec não compatível com o navegador. Clique em Criar prévia leve (para MKV).',true);});
el('player').addEventListener('play',startFollowFrame);
el('player').addEventListener('pause',stopFollowFrame);
el('player').addEventListener('seeked',()=>{
  const jump=state.cutJump;
  if(jump){state.cutJump=null;el('player').muted=jump.muted;
    if(Math.abs(el('player').currentTime-jump.target)<0.15&&jump.resume)el('player').play().catch(()=>toast('O navegador bloqueou a reprodução.',true));
  }
  syncSpeech({force:true});movePlayhead();
});
el('player').addEventListener('loadedmetadata',()=>{if(state.pendingResumeTime!==null){el('player').currentTime=state.pendingResumeTime;state.pendingResumeTime=null;}syncSpeech({force:true});});
el('player').addEventListener('timeupdate',()=>{const video=el('player');const t=video.currentTime;
  el('time').textContent=`${formatTime(t)} / ${formatTime(state.media?.duration || 0)}`;
  skipCutIfNeeded();
  if(!state.cutJump)syncSpeech();
  movePlayhead();
  if(Date.now()-lastPositionSave>2000)savePosition();
});
el('player').addEventListener('pause',savePosition);
el('player').addEventListener('seeked',savePosition);

el('projectNameInput').addEventListener('change',e=>{const val=e.target.value.trim();if(!val){e.target.value=state.projectName;return;}state.projectName=val;toast('Nome do projeto atualizado. Use Salvar projeto para guardar a alteração.');});
el('zoomOut').onclick=()=>changeZoom(-1);
el('markStart').onclick=()=>{if(!state.media)return;el('player').pause();state.manualStart=el('player').currentTime;el('markStart').textContent=`Início ${formatTime(state.manualStart)}`;el('cutToPlayhead').disabled=false;};
el('cutToPlayhead').onclick=()=>{if(!state.media||state.manualStart===null)return;
 const range=manualCutRange(state.manualStart,el('player').currentTime,state.media.duration);
 if(!range)return toast('Posicione o cursor em outro ponto da timeline para definir o fim.',true);
 snapshot();state.extraCuts.push(range);state.manualStart=null;el('cutToPlayhead').disabled=true;el('markStart').textContent='Marcar início';updateAll();toast('Trecho cortado. O vídeo original permanece intacto.');
};
el('zoomIn').onclick=()=>changeZoom(1);
el('zoomFit').onclick=()=>changeZoom(0);
el('timelinePan').addEventListener('input',e=>{const v=viewData();state.viewStart=Number(e.target.value)/1000*(v.duration-v.span);drawWaveform();});
el('splitAtPlayhead').onclick=splitAtPlayhead;
el('rangeMode').onclick=()=>{if(!state.media)return toast('Importe um vídeo primeiro.',true);state.rangeMode=!state.rangeMode;el('rangeMode').classList.toggle('selected',state.rangeMode);el('rangeMode').setAttribute('aria-pressed',String(state.rangeMode));el('rangeStatus').textContent=state.rangeMode?'Arraste sobre a onda para selecionar o trecho.':'Clique posiciona o cursor. Use Selecionar intervalo para cortar.';};
el('deleteRange').onclick=deleteTimelineRange;
el('clearRange').onclick=clearTimelineRange;
let scrubbing=false,selecting=false,rangeAnchor=0,downX=0,moved=false;
el('timeline').addEventListener('pointerdown',e=>{if(!state.media||state.busy)return;el('timeline').setPointerCapture(e.pointerId);
 if(state.rangeMode){selecting=true;rangeAnchor=timeAtClientX(e.clientX,el('timeline').getBoundingClientRect(),viewData());el('player').pause();clearTimelineRange();}
 else{scrubbing=true;downX=e.clientX;moved=false;seekFromTimeline(e);}
});
el('timeline').addEventListener('pointermove',e=>{hoverTimeline(e);if(scrubbing){if(Math.abs(e.clientX-downX)>4)moved=true;seekFromTimeline(e);}if(selecting)setTimelineRange(rangeAnchor,timeAtClientX(e.clientX,el('timeline').getBoundingClientRect(),viewData()));});
el('timeline').addEventListener('pointerenter',hoverTimeline);
el('timeline').addEventListener('pointerleave',()=>{if(!scrubbing&&!selecting)unhoverTimeline();});
el('timeline').addEventListener('pointerup',e=>{if(selecting)setTimelineRange(rangeAnchor,timeAtClientX(e.clientX,el('timeline').getBoundingClientRect(),viewData()));else if(scrubbing&&!moved&&Math.abs(e.clientX-downX)<=4&&state.splitFrames.length)selectSplitSegment(timeAtClientX(e.clientX,el('timeline').getBoundingClientRect(),viewData()));scrubbing=false;selecting=false;unhoverTimeline();});
el('timeline').addEventListener('pointercancel',()=>{scrubbing=false;selecting=false;unhoverTimeline();});
el('timeline').addEventListener('contextmenu',e=>{
 if(!state.media||state.busy)return;
 const time=timeAtClientX(e.clientX,el('timeline').getBoundingClientRect(),viewData());
 if(state.cutCache.some(c=>time>=c.start&&time<c.end)){e.preventDefault();el('player').pause();restoreTimelineCut(time);}
});
el('timelineRuler').addEventListener('click',seekFromTimeline);
window.addEventListener('resize',()=>drawWaveform());

function renderAutoSuggestions(){
  const types=['restart','repeat','filler'];
  const names={filler:'Hesitações',repeat:'Frases repetidas',restart:'Recomeços e erros falados'};
  const box=el('autoSuggestions'),total=state.autoSuggestions.length;
  const opened=new Set([...box.querySelectorAll('details[open]')].map(node=>node.dataset.autoType));
  const applied=state.autoSuggestions.filter(s=>Array.from({length:s.to-s.from+1},(_,i)=>s.from+i).every(i=>state.deleted.has(i))).length;
  const pending=state.autoSuggestions.filter(s=>
    !Array.from({length:s.to-s.from+1},(_,i)=>s.from+i).every(i=>state.deleted.has(i))).length;
  el('reviewAuto').textContent=total?`Revisar ${applied} pré-cortes${pending?` · ${pending} novas tomadas`:''}`:'Revisar cortes';
  el('autoStatus').textContent=total?`${applied} de ${total} sugestões riscadas; ${pending} sugestões preservadas para conferir. Clique direito restaura.`:'Nenhuma sugestão textual detectada.';
  box.innerHTML=types.map(type=>{
    const items=state.autoSuggestions.map((s,index)=>({s,index})).filter(x=>x.s.type===type);
    if(!items.length)return '';
    return `<details class="auto-list" data-auto-type="${type}" ${opened.has(type)?'open':''}><summary>${names[type]} <b>${items.length}</b></summary>${items.map(({s,index})=>{
      const cut=Array.from({length:s.to-s.from+1},(_,i)=>s.from+i).every(i=>state.deleted.has(i));
      return `<div class="auto-item"><span>${safe(s.reason)} <small>${cut?'Riscado':'Mantido'} · Confiança ${safe(s.confidence||'baixa')} · ${formatTime(s.start)}–${formatTime(s.end)}</small></span><button type="button" data-auto-time="${s.start}" title="Ouvir a ocorrência">▶ Ir ao trecho</button><button type="button" data-auto-toggle="${index}">${cut?'Restaurar':'Cortar'}</button></div>`;
    }).join('')}</details>`;
  }).join('')+`<p class="hint">Cada palavra riscada pode ser restaurada pelo clique direito. Ausência de palavras nunca comprova silêncio.</p>`;
}
el('autoSuggestions').addEventListener('click',e=>{
 const toggle=e.target.closest('[data-auto-toggle]');
 if(toggle){
   const s=state.autoSuggestions[Number(toggle.dataset.autoToggle)];if(!s)return;
   const cut=Array.from({length:s.to-s.from+1},(_,i)=>s.from+i).every(i=>state.deleted.has(i));
   snapshot();for(let i=s.from;i<=s.to;i++){if(cut)state.deleted.delete(i);else state.deleted.add(i);}
   updateAll();toast(cut?'Fala restaurada.':'Fala riscada.');return;
 }
 const button=e.target.closest('[data-auto-time]');if(!button||!state.media)return;
 const player=el('player');cancelCutJump();player.pause();player.currentTime=Number(button.dataset.autoTime)||0;movePlayhead();syncSpeech({force:true});
});
el('reviewAuto').onclick=()=>{el('toolsMenu').open=true;el('autoSuggestions').scrollIntoView({block:'nearest'});};
window.addEventListener('keydown',e=>{
  const target=e.target;
  const typing=target?.isContentEditable||['INPUT','TEXTAREA','SELECT'].includes(target?.tagName);
  if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='z'&&!typing){e.preventDefault();el('undo').click();return;}
  if(e.key.toLowerCase()==='c'&&!typing&&!e.ctrlKey&&!e.metaKey&&!e.altKey&&!e.repeat&&state.media){e.preventDefault();splitAtPlayhead();return;}
  if((e.key==='Delete'||e.key==='Backspace')&&!typing&&state.timelineRange&&!e.ctrlKey&&!e.metaKey){e.preventDefault();deleteTimelineRange();return;}
  if(e.key==='Escape'&&state.timelineRange){clearTimelineRange();return;}
  if((e.code==='Space'||e.key===' ')&&!typing&&!e.ctrlKey&&!e.metaKey&&!e.altKey&&!e.repeat){
    // Botoes acionados por teclado devem manter seu comportamento acessivel.
    if(target?.closest?.('button,summary,a,[role="button"]')&&target!==el('player'))return;
    e.preventDefault();const player=el('player');if(!state.media)return;
    if(player.paused)startPlayback();else player.pause();
  }
});
updateAll();
