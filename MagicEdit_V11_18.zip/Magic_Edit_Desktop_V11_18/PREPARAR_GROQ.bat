@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Preparar biblioteca oficial Groq
set "PY=py -3"
where py >nul 2>nul
if errorlevel 1 set "PY=python"
echo Instalando Groq oficial e analise local de voz (NumPy e ONNX Runtime).
echo Requer internet. Este passo e feito somente na primeira vez.
echo.
%PY% -m pip install --disable-pip-version-check groq numpy onnxruntime
if errorlevel 1 (
  echo.
  echo ERRO ao instalar o SDK. Confira o erro acima.
  pause
  exit /b 1
)
echo.
%PY% -c "from groq import Groq; print('SDK Groq instalado corretamente.')"
echo.
echo Pronto! Agora abra INICIAR_MAGIC_EDIT.bat.
pause
