"""Resolve-side adapter: marker plan -> verified in-place V1/A1 edits."""
import datetime,hashlib,json,math,os,signal,subprocess,time,uuid
from pathlib import Path
ROOT=Path(__file__).resolve().parent
PREFIX='SIL_ESTAVEL_2F_'
POLICY='pauses-over-two-frames-v1'

def state_dir():
    return Path(os.environ.get('LOCALAPPDATA',str(Path.home()/'.local/share')))/'MagicEdit/Silencios09'
def read_config():return json.loads((state_dir()/'active.json').read_text('utf-8'))
def dump(path,data):
    path.parent.mkdir(parents=True,exist_ok=True);temp=path.with_name(path.name+'.'+uuid.uuid4().hex+'.tmp')
    try:temp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8');temp.replace(path)
    finally:temp.unlink(missing_ok=True)
def ctx(bmd):
    resolve=bmd.scriptapp('Resolve')
    if not resolve:raise ValueError('Nao consegui conectar ao Resolve.')
    project=resolve.GetProjectManager().GetCurrentProject()
    timeline=project.GetCurrentTimeline() if project else None
    if not timeline:raise ValueError('Abra o projeto e a timeline do bruto.')
    return resolve,project,timeline,project.GetMediaPool()
def uid(obj):
    method=getattr(obj,'GetUniqueId',None)
    return str(method() if callable(method) else obj.GetName())
def source_item(clip):
    media=clip.GetMediaPoolItem()
    if not media:raise ValueError('Clipe gerado/composto nao suportado no primeiro corte.')
    start,end=int(clip.GetStart()),int(clip.GetEnd());api_start=int(clip.GetSourceStartFrame());api_end=int(clip.GetSourceEndFrame())
    offset=float(clip.GetLeftOffset())
    if not math.isfinite(offset) or offset<0 or abs(offset-round(offset))>1e-6:raise ValueError('Offset subframe nao suportado neste primeiro corte.')
    source=round(offset)
    # SourceStartFrame has measured one-frame readback errors; placement uses LeftOffset.
    if end<=start or min(abs(api_end-api_start-(end-start)),abs(api_end-api_start+1-(end-start)))>1:raise ValueError('Clipe retimado ou limites fonte incompatíveis; use o bruto sem alteracao de velocidade.')
    if clip.GetFusionCompCount():raise ValueError('Ha composicao Fusion; execute o primeiro corte antes dos motions.')
    for name in ('GetMarkers','GetFlagList'):
        method=getattr(clip,name,None)
        if callable(method) and method():raise ValueError('Use o bruto antes de adicionar marcadores/flags aos clipes.')
    enabled=getattr(clip,'GetClipEnabled',None)
    if callable(enabled) and enabled() is False:raise ValueError('Ha clipe desativado; use uma timeline do bruto.')
    props=clip.GetProperty() or {}
    for name,default in {'ZoomX':1,'ZoomY':1,'Pan':0,'Tilt':0,'RotationAngle':0,'Opacity':100}.items():
        if name in props and abs(float(props[name])-default)>1e-6:raise ValueError('Ha transformacoes no clipe; use uma timeline do bruto antes dos efeitos.')
    path=media.GetClipProperty('File Path')
    if not path or not Path(path).is_file():raise ValueError('Midia original indisponivel: '+str(path))
    stat=Path(path).stat()
    return {'path':path,'start':start,'end':end,'source_start':source,'source_end':source+end-start,'size':stat.st_size,'mtime':stat.st_mtime_ns},media

def capture(project,timeline):
    if any(timeline.GetItemListInTrack('subtitle',i) for i in range(1,(timeline.GetTrackCount('subtitle') or 0)+1)):raise ValueError('Use o bruto antes de adicionar legendas.')
    for kind in ('video','audio'):
        locked=getattr(timeline,'GetIsTrackLocked',None)
        if callable(locked) and locked(kind,1):raise ValueError('Desbloqueie V1/A1 antes de analisar ou aplicar.')
        for track in range(2,timeline.GetTrackCount(kind)+1):
            if timeline.GetItemListInTrack(kind,track):raise ValueError('Use o bruto em V1/A1, antes de adicionar camadas ou B-roll.')
    videos=sorted(timeline.GetItemListInTrack('video',1) or [],key=lambda c:c.GetStart())
    audios=sorted(timeline.GetItemListInTrack('audio',1) or [],key=lambda c:c.GetStart())
    if not videos or len(videos)!=len(audios):raise ValueError('Este primeiro corte exige video e audio correspondentes em V1/A1.')
    fps=float(timeline.GetSetting('timelineFrameRate'))
    items=[];refs=[]
    for video,audio in zip(videos,audios):
        data,media=source_item(video);adata,amedia=source_item(audio)
        if data!=adata:raise ValueError('V1/A1 tem cortes, fontes ou sincronizacao diferentes; aplicacao interrompida.')
        source_fps=float(media.GetClipProperty('FPS'))
        if abs(source_fps-fps)>.01:raise ValueError('FPS da fonte diferente da timeline.')
        if items and data['start']<items[-1]['end']:raise ValueError('Sobreposicao/transicao entre clipes nao suportada no primeiro corte.')
        items.append(data);refs.append(media)
    audio_type=getattr(timeline,'GetTrackSubType',None)
    audio_type=audio_type('audio',1) if callable(audio_type) else None
    snap={'audioType':audio_type,'project':uid(project),'timeline':uid(timeline),'name':timeline.GetName(),'fps':fps,'start':int(timeline.GetStartFrame()),'items':items}
    return snap,refs

def fingerprint(snapshot):return hashlib.sha256(json.dumps(snapshot,sort_keys=True).encode()).hexdigest()
def merge(cuts):
    result=[]
    for a,b in sorted(cuts):
        if b<=a:raise ValueError('Intervalo de corte invalido.')
        if result and a<=result[-1][1]:result[-1][1]=max(result[-1][1],b)
        else:result.append([a,b])
    return result

def build_keeps(items,cuts):
    for a,b in cuts:
        if not any(x['start']<=a<b<=x['end'] for x in items):raise ValueError('Marcador fora do clipe analisado.')
    cuts=merge(cuts)
    def removed_before(t):return sum(max(0,min(t,b)-a) for a,b in cuts if a<t)
    result=[]
    for index,item in enumerate(items):
        cursor=item['start']
        for a,b in cuts+[[item['end'],item['end']]]:
            if b<=item['start'] or a>item['end']:continue
            a=max(item['start'],a);b=min(item['end'],b)
            if a>cursor:
                result.append({'item_index':index,'source_start':item['source_start']+cursor-item['start'],'source_end':item['source_start']+a-item['start'],'record':cursor-removed_before(cursor)})
            cursor=max(cursor,b)
    if not result:raise ValueError('O plano eliminaria todo o material. Nenhuma copia criada.')
    return result

def plan_path(timeline):return state_dir()/'plans'/('timeline_'+hashlib.sha256(uid(timeline).encode()).hexdigest()+'.json')
def owned(marker):return marker.get('name','').upper().startswith(('SIL_ESTAVEL_','EMENDA_FINAL_'))
def add_marker(timeline,frame,data):
    return timeline.AddMarker(int(frame),data['color'],data['name'],data.get('note',''),int(data['duration']),data.get('customData',''))

def begin_analysis(bmd,strength=50):
    resolve,project,timeline,_=ctx(bmd);snapshot,_=capture(project,timeline);config=read_config()
    if strength not in (0,25,50,75,100):raise ValueError('Intensidade invalida.')
    work=state_dir()/'runs'/uuid.uuid4().hex;work.mkdir(parents=True)
    request=work/'request.json';output=work/'output.json'
    dump(request,{'items':snapshot['items'],'fps':snapshot['fps'],'strength':strength,'minPauseFrames':2,'config':config})
    print('Magic Edit: pausas maiores que 2 frames; margens de fala de 1 frame por lado.')
    process=subprocess.Popen(config['python']+[str(ROOT/'worker.py'),str(request),str(output)],creationflags=(subprocess.CREATE_NEW_PROCESS_GROUP if os.name=='nt' else 0),start_new_session=(os.name!='nt'))
    return {'resolve':resolve,'project':project,'timeline':timeline,'snapshot':snapshot,'output':output,'process':process,'strength':strength,'started':time.monotonic()}

def finish_analysis(job):
    project,timeline,snapshot,output,process,strength=(job[k] for k in ('project','timeline','snapshot','output','process','strength'))
    if process.poll() is None:raise RuntimeError('Analise ainda em andamento.')
    active=job['resolve'].GetProjectManager().GetCurrentProject()
    if not active or uid(active)!=snapshot['project']:raise ValueError('O projeto ativo mudou durante a analise. Resultado nao aplicado.')
    if project.GetCurrentTimeline() is not timeline and uid(project.GetCurrentTimeline())!=uid(timeline):raise ValueError('A timeline ativa mudou durante a analise. Resultado nao aplicado.')
    if not output.is_file():raise RuntimeError('O analisador local nao concluiu. Confira a Console do Resolve.')
    report=json.loads(output.read_text('utf-8'))
    if process.returncode or not report.get('ok'):raise RuntimeError(report.get('error','Falha no analisador local.'))
    current,_=capture(project,timeline)
    if fingerprint(snapshot)!=fingerprint(current):raise ValueError('A timeline mudou durante a analise. Analise novamente.')
    sources={s['path']:s for s in report['sources']};cuts=[]
    for item in snapshot['items']:
        source=sources[item['path']];fps=source['fps']
        for cut in source['cuts']:
            a=max(item['source_start'],cut.get('startFrame',math.ceil(cut['start']*fps-1e-7)));b=min(item['source_end'],cut.get('endFrame',math.floor(cut['end']*fps+1e-7)))
            if b>a:cuts.append((item['start']+a-item['source_start'],item['start']+b-item['source_start']))
    # Never combine adjacent markers across separate source clips.
    cuts=sorted(set(cuts));build_keeps(snapshot['items'],cuts)
    markers=timeline.GetMarkers() or {};old={int(k):v for k,v in markers.items() if owned(v)};new={}
    token=uuid.uuid4().hex
    for n,(a,b) in enumerate(cuts,1):
        frame=a-snapshot['start']
        if frame in markers and frame not in old:raise ValueError('Um marcador seu ocupa o inicio de um silencio; ele foi preservado.')
        if frame in new:raise ValueError('Dois silencios com inicio igual. Analise cancelada.')
        new[frame]={'color':'Green','name':PREFIX+str(n).zfill(3),'note':'Magic Edit | pausa >2 frames | margem 1 frame por lado | confira antes de aplicar','duration':b-a,'customData':'MagicEdit09:'+token}
    try:
        for frame in old:
            if not timeline.DeleteMarkerAtFrame(frame):raise RuntimeError('Nao consegui atualizar um marcador antigo.')
        for frame,data in new.items():
            if not add_marker(timeline,frame,data):raise RuntimeError('Resolve recusou um marcador; plano nao aplicado.')
        confirmed=timeline.GetMarkers() or {}
        if any(confirmed.get(frame,{}).get('customData')!=data['customData'] or int(confirmed[frame]['duration'])!=data['duration'] for frame,data in new.items()):raise RuntimeError('Os marcadores nao foram confirmados pelo Resolve. Nenhum corte aplicado.')
        dump(plan_path(timeline),{'policy':POLICY,'cuts':cuts,'snapshot':snapshot,'fingerprint':fingerprint(snapshot),'token':token,'sources':report['sources'],'strength':strength})
    except Exception:
        for frame in new:
            m=(timeline.GetMarkers() or {}).get(frame,{})
            if m.get('customData')=='MagicEdit09:'+token:timeline.DeleteMarkerAtFrame(frame)
        for frame,data in old.items():
            if frame not in (timeline.GetMarkers() or {}):add_marker(timeline,frame,data)
        raise
    for source in report['sources']:
        print('Protecao de palavras:',source['words'],'| JSON:',source['word_source'] or 'sem JSON correspondente; voz protegida pelo Silero')
    print('Analise pronta:',len(cuts),'marcadores. Nenhum corte aplicado.')
    return len(cuts)


def cancel_analysis(job):
    process=job['process']
    if process.poll() is not None:return
    if os.name=='nt':
        subprocess.run(['taskkill','/PID',str(process.pid),'/T','/F'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=15)
    else:
        try:os.killpg(process.pid,signal.SIGTERM)
        except ProcessLookupError:pass
    try:process.wait(timeout=10)
    except subprocess.TimeoutExpired:process.kill();process.wait(timeout=10)

def analisar(bmd,strength=50):
    job=begin_analysis(bmd,strength)
    try:job['process'].wait(timeout=14400);return finish_analysis(job)
    except BaseException:
        cancel_analysis(job)
        raise


def _clip_readback(clip):
    media=clip.GetMediaPoolItem()
    return {'start':float(clip.GetStart()),'end':float(clip.GetEnd()),'source_start':float(clip.GetLeftOffset()),'path':media.GetClipProperty('File Path') if media else None}

def _verify(timeline,keeps,items,stage):
    results=[];errors=[]
    for kind in ('video','audio'):
        clips=sorted(timeline.GetItemListInTrack(kind,1) or [],key=lambda c:c.GetStart())
        if len(clips)!=len(keeps):errors.append(f'{kind}: {len(clips)} clipes; esperado {len(keeps)}')
        for index,(keep,clip) in enumerate(zip(keeps,clips)):
            expected={'start':keep['record'],'end':keep['record']+keep['source_end']-keep['source_start'],'source_start':keep['source_start'],'path':items[keep['item_index']]['path']}
            actual=_clip_readback(clip)
            mismatch=[key for key in ('start','end','source_start') if abs(actual[key]-expected[key])>1e-4]
            if os.path.normcase(os.path.realpath(actual['path'] or ''))!=os.path.normcase(os.path.realpath(expected['path'])):mismatch.append('path')
            results.append({'track':kind,'clip':index+1,'expected':expected,'actual':actual,'mismatch':mismatch})
            if mismatch:errors.append(f'{kind} clipe {index+1}: '+', '.join(mismatch))
    for kind in ('video','audio','subtitle'):
        count=timeline.GetTrackCount(kind) or 0
        for track in range(2 if kind!='subtitle' else 1,count+1):
            if timeline.GetItemListInTrack(kind,track):errors.append(f'Conteudo inesperado em {kind}{track}')
    if errors:
        dump(state_dir()/'ultimo_posicionamento.json',{'stage':stage,'timeline':timeline.GetName(),'clips':results,'errors':errors})
        first=next((r for r in results if r['mismatch']),None)
        detail=(f"{first['track']} #{first['clip']}: esperado {first['expected']}; recebido {first['actual']}" if first else '; '.join(errors))
        raise RuntimeError('Posicionamento divergente. '+detail+' | ultimo_posicionamento.json')
    return results

def _require_current(project,timeline):
    current=project.GetCurrentTimeline()
    if not current or uid(current)!=uid(timeline):raise RuntimeError('A timeline ativa mudou. Nenhuma remontagem sera iniciada.')

def _select_original(project,timeline):
    if project.SetCurrentTimeline(timeline) is False:raise RuntimeError('Nao consegui retornar a timeline original. Original intacta se a aplicacao nao iniciou.')
    _require_current(project,timeline)

def _mount(project,timeline,pool,refs,keeps,offset,properties=None):
    _require_current(project,timeline)
    for keep in keeps:
        common={'mediaPoolItem':refs[keep['item_index']],'startFrame':keep['source_start'],'endFrame':keep['source_end']+offset,'trackIndex':1,'recordFrame':keep['record']}
        _require_current(project,timeline)
        result=pool.AppendToTimeline([{**common,'mediaType':1},{**common,'mediaType':2}])
        if not result:raise RuntimeError('Falha ao montar trechos V1/A1.')
        if not timeline.SetClipsLinked(result,True):raise RuntimeError('Nao consegui vincular video e audio.')
    if properties:
        for kind in ('video','audio'):
            clips=sorted(timeline.GetItemListInTrack(kind,1) or [],key=lambda c:c.GetStart())
            if len(clips)!=len(keeps):raise RuntimeError('Quantidade de clipes inesperada ao preservar propriedades.')
            for keep,clip in zip(keeps,clips):
                before=properties[kind][keep['item_index']];current=clip.GetProperty() or {}
                for key,value in before.items():
                    if current.get(key)!=value:
                        if not clip.SetProperty(key,value) or (clip.GetProperty() or {}).get(key)!=value:raise RuntimeError('Nao consegui preservar a propriedade '+key+'. Use o bruto sem efeitos.')

def _clear(project,timeline):
    _require_current(project,timeline)
    clips=[]
    for kind in ('video','audio'):
        for track in range(1,(timeline.GetTrackCount(kind) or 0)+1):clips.extend(timeline.GetItemListInTrack(kind,track) or [])
    if clips and not timeline.DeleteClips(clips,False):raise RuntimeError('Resolve recusou a remocao dos clipes.')
    if any(timeline.GetItemListInTrack(kind,track) for kind in ('video','audio') for track in range(1,(timeline.GetTrackCount(kind) or 0)+1)):raise RuntimeError('Resolve nao esvaziou os clipes para remontagem.')

def _set_markers(timeline,markers):
    current=timeline.GetMarkers() or {}
    for frame in current:
        if not timeline.DeleteMarkerAtFrame(frame):raise RuntimeError('Nao consegui atualizar marcadores.')
    for frame,data in markers.items():
        if not add_marker(timeline,frame,data):raise RuntimeError('Nao consegui preservar um marcador.')
    readback=timeline.GetMarkers() or {}
    if len(readback)!=len(markers) or any(frame not in readback or readback[frame].get('name')!=data.get('name') for frame,data in markers.items()):raise RuntimeError('Marcadores nao conferem apos remontagem.')

def _shift_markers(markers,start,cuts,token):
    def shifted(t):return t-sum(max(0,min(t,b)-a) for a,b in cuts if a<t)
    result={}
    for frame,data in markers.items():
        if data.get('customData')=='MagicEdit09:'+token and data.get('name','').startswith(PREFIX):continue
        a=start+int(frame);b=a+int(data.get('duration',1));new=round(shifted(a)-start)
        if new in result:raise ValueError('Dois marcadores seus ocupariam o mesmo frame apos o corte. Ajuste-os antes de aplicar.')
        result[new]={**data,'duration':max(1,round(shifted(b)-shifted(a)))}
    return result

def _probe_mount(resolve,project,original,pool,snapshot,refs,keeps,properties):
    # Short-lived validation only: no duplicate remains in the user's project.
    last_error=None
    for offset in (-1,0):
        scratch=pool.CreateEmptyTimeline('__MAGIC_EDIT_TESTE_'+uuid.uuid4().hex[:8])
        if not scratch:raise RuntimeError('Nao consegui preparar a verificacao de montagem.')
        scratch_id=uid(scratch)
        try:
            if abs(float(scratch.GetSetting('timelineFrameRate'))-snapshot['fps'])>.01:
                scratch.SetSetting('useCustomSettings','1');scratch.SetSetting('timelineFrameRate',str(snapshot['fps']))
            if snapshot.get('audioType'):
                if scratch.GetTrackSubType('audio',1)!=snapshot['audioType']:
                    prior=scratch.GetTrackCount('audio')
                    if not scratch.AddTrack('audio',{'audioType':snapshot['audioType'],'index':1}) or scratch.GetTrackCount('audio')!=prior+1:raise RuntimeError('Nao consegui preservar o formato de canais A1 no teste.')
                    for track in range(prior+1,1,-1):
                        if not scratch.DeleteTrack('audio',track):raise RuntimeError('Nao consegui configurar A1 no teste.')
                    if scratch.GetTrackSubType('audio',1)!=snapshot['audioType']:raise RuntimeError('Formato A1 diferente do original.')
            scratch.SetStartTimecode(original.GetStartTimecode())
            if abs(float(scratch.GetSetting('timelineFrameRate'))-snapshot['fps'])>.01 or int(scratch.GetStartFrame())!=snapshot['start']:raise RuntimeError('Verificacao ficou com FPS/timecode diferentes.')
            if project.SetCurrentTimeline(scratch) is False:raise RuntimeError('Nao consegui selecionar verificacao.')
            try:
                _mount(project,scratch,pool,refs,keeps,offset,properties);_verify(scratch,keeps,snapshot['items'],'preflight')
                return offset
            except RuntimeError as exc:last_error=exc
        finally:
            _select_original(project,original)
            deleted=pool.DeleteTimelines([scratch])
            count=getattr(project,'GetTimelineCount',None)
            if callable(count):
                if any(uid(project.GetTimelineByIndex(i))==scratch_id for i in range(1,count()+1)):raise RuntimeError('Nao consegui remover a verificacao temporaria. Original intacta.')
            elif not deleted:raise RuntimeError('Nao consegui remover a verificacao temporaria. Original intacta.')
    raise RuntimeError('Teste de montagem falhou antes de alterar a timeline. '+str(last_error))

def aplicar(bmd):
    resolve,project,original,pool=ctx(bmd);snapshot,refs=capture(project,original)
    path=plan_path(original)
    if not path.is_file():raise ValueError('Clique em ANALISAR antes de aplicar os cortes.')
    plan=json.loads(path.read_text('utf-8'))
    if plan.get('policy')!=POLICY:raise ValueError('Analise novamente com o limite de 2 frames antes de aplicar.')
    if fingerprint(snapshot)!=plan['fingerprint']:raise ValueError('A timeline mudou depois da analise. Analise novamente.')
    markers={int(k):v for k,v in (original.GetMarkers() or {}).items()};cuts=[]
    for frame,data in markers.items():
        if data.get('customData')=='MagicEdit09:'+plan['token'] and data.get('name','').startswith(PREFIX):
            a=snapshot['start']+frame;b=a+int(data['duration'])
            if not any(x<=a<b<=y for x,y in plan['cuts']):raise ValueError('Marcador foi movido para fora do silencio protegido. Analise novamente.')
            cuts.append((a,b))
    if not cuts:raise ValueError('Nenhum marcador desta analise encontrado.')
    keeps=build_keeps(snapshot['items'],cuts);cuts=merge(cuts);new_markers=_shift_markers(markers,snapshot['start'],cuts,plan['token'])
    properties={kind:[c.GetProperty() or {} for c in sorted(original.GetItemListInTrack(kind,1) or [],key=lambda c:c.GetStart())] for kind in ('video','audio')}
    recovery=state_dir()/'recovery'/(datetime.datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:6]);recovery.mkdir(parents=True)
    drt=recovery/'antes_dos_cortes.drt'
    if not original.Export(str(drt),resolve.EXPORT_DRT) or not drt.is_file() or not drt.stat().st_size:raise RuntimeError('Nao consegui salvar recuperacao DRT. Nenhum corte aplicado.')
    offset=_probe_mount(resolve,project,original,pool,snapshot,refs,keeps,properties)
    current,_=capture(project,original)
    if fingerprint(snapshot)!=fingerprint(current) or original.GetMarkers()!=markers:raise ValueError('A timeline/marcadores mudaram durante a verificacao. Analise novamente.')
    journal={'snapshot':snapshot,'markers':markers,'properties':properties,'cuts':cuts,'keeps':keeps,'endOffset':offset,'drt':str(drt),'drtSha':hashlib.sha256(drt.read_bytes()).hexdigest(),'stage':'prepared'}
    journal_path=recovery/'journal.json';dump(journal_path,journal)
    original_keeps=[{'item_index':i,'source_start':item['source_start'],'source_end':item['source_end'],'record':item['start']} for i,item in enumerate(snapshot['items'])]
    try:
        journal['stage']='applying';dump(journal_path,journal)
        _require_current(project,original);_clear(project,original);_mount(project,original,pool,refs,keeps,offset,properties);_verify(original,keeps,snapshot['items'],'applied');_set_markers(original,new_markers)
        journal['stage']='verified';dump(journal_path,journal)
        dump(state_dir()/'last_result.json',{'timeline':original.GetName(),'cuts':cuts,'keeps':keeps,'verified':True,'inPlace':True,'recovery':str(recovery)})
        path.unlink(missing_ok=True)
        print('Cortes aplicados:',len(cuts),'| mesma timeline | recuperacao:',drt)
        return True
    except Exception as error:
        try:
            _select_original(project,original);_clear(project,original);_mount(project,original,pool,refs,original_keeps,offset,properties);_verify(original,original_keeps,snapshot['items'],'rollback');_set_markers(original,markers)
            journal.update(stage='rolled_back',error=str(error));dump(journal_path,journal)
        except Exception as rollback:
            journal.update(stage='recovery_required',error=str(error),rollbackError=str(rollback));dump(journal_path,journal)
            raise RuntimeError('Falha na aplicacao e restauracao automatica. Importe a recuperacao: '+str(drt)) from error
        raise RuntimeError('Aplicacao interrompida; timeline restaurada. '+str(error)) from error
