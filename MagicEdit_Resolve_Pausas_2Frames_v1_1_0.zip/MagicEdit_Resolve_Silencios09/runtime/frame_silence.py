"""Conservative short-pause detector. No inference from missing transcript words."""
import math,os,subprocess

def detect(peaks,rms,step,duration,fps,words,min_frames=2,speech=None):
    import numpy as np
    peaks=np.asarray(peaks,dtype=float);rms=np.asarray(rms,dtype=float)
    if not 10<=fps<=120 or not step>0 or min_frames!=2:raise ValueError('Parametros de frames invalidos.')
    if peaks.size!=rms.size or peaks.size<2 or not np.isfinite(peaks).all() or not np.isfinite(rms).all():raise ValueError('Energia invalida.')
    if speech is not None and not speech:return []
    reference=float(np.quantile(peaks,.90))
    if reference<.01:return [] # Do not cut an almost-inaudible recording.
    # Cap the threshold: quiet consonants/breaths cannot raise the noise floor.
    peak_limit=min(10**(-48/20),max(10**(-72/20),reference*.018))
    rms_limit=min(10**(-58/20),max(10**(-78/20),reference*.006))
    quiet=(peaks<=peak_limit)&(rms<=rms_limit)
    changes=np.diff(np.concatenate(([False],quiet,[False])).astype(np.int8))
    starts=np.flatnonzero(changes==1);ends=np.flatnonzero(changes==-1);cuts=[]
    for a,b in zip(starts,ends):
        start=float(a)*step;end=min(duration,float(b)*step)
        if (end-start)*fps<=min_frames+1e-7:continue
        # Keep one full video frame at each speech boundary. Only whole frames
        # entirely within the quiet region can be marked, never round outward.
        left=math.ceil((start+(1/fps if a else 0))*fps-1e-7)
        right=math.floor((end-(1/fps if b<len(quiet) else 0))*fps+1e-7)
        if right<=left:continue
        if any(left/fps<w['end']+1/fps and right/fps>w['start']-1/fps for w in words):continue
        cuts.append({'start':left/fps,'end':right/fps,'startFrame':left,'endFrame':right,'pauseFrames':round((end-start)*fps,3)})
    return cuts

def analyze(path,ffmpeg,duration,fps,words,speech,channels=1):
    if not isinstance(channels,int) or not 1<=channels<=32:raise ValueError('Formato de canais de audio nao suportado.')
    import numpy as np
    # One second of PCM at a time; 5 ms bins retain transients and low syllables.
    rate=16000;block=80;peaks=[];rms=[]
    flags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0
    with __import__('tempfile').TemporaryFile() as errors:
        process=subprocess.Popen([ffmpeg,'-v','error','-nostdin','-i',path,'-vn','-map','0:a:0','-ac',str(channels),'-ar',str(rate),'-f','s16le','-'],stdout=subprocess.PIPE,stderr=errors,creationflags=flags)
        pending=b''
        try:
            while True:
                data=process.stdout.read(rate*channels*2)
                if not data:break
                pending+=data;size=len(pending)//(block*channels*2)*block*channels*2
                if not size:continue
                samples=np.frombuffer(pending[:size],dtype='<i2').astype(float).reshape(-1,block,channels)/32768
                peaks.extend(np.max(np.abs(samples),axis=(1,2)));rms.extend(np.sqrt(np.mean(samples*samples,axis=1)).max(axis=1));pending=pending[size:]
            if pending:
                samples=np.frombuffer(pending,dtype='<i2').astype(float).reshape(-1,channels)/32768;peaks.append(float(np.max(np.abs(samples))));rms.append(float(np.max(np.sqrt(np.mean(samples*samples,axis=0)))))
            if process.wait(timeout=30):
                errors.seek(0);raise RuntimeError('Falha na energia detalhada: '+errors.read().decode('utf-8','replace')[-500:])
        finally:
            if process.poll() is None:process.kill();process.wait()
            process.stdout.close()
    return detect(peaks,rms,.005,duration,fps,words,2,speech)
