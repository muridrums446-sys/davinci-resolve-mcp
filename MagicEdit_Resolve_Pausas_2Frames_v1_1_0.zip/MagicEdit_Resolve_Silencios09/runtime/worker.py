"""Same local detector as Desktop. No network, uploads or source-media writes."""
import json,math,os,subprocess,sys
from pathlib import Path
from fractions import Fraction
from audio_wave import peaks_from_pcm
import vad_local

def read_words(path,duration):
    source=Path(path);candidates=[Path(os.environ.get('APPDATA',str(Path.home()/'.config')))/'MagicEditDesktop/autosave.json',source.with_name(source.stem+'_MagicEdit.json')]
    for candidate in candidates:
        try:
            if candidate.stat().st_size>9_000_000:continue
            doc=json.loads(candidate.read_text('utf-8-sig'))
            if os.path.normcase(os.path.realpath(doc['path']))!=os.path.normcase(os.path.realpath(path)):continue
            if abs(float(doc['media']['duration'])-duration)>.1:continue
            words=doc['words']
            if not isinstance(words,list) or len(words)>100000:continue
            if any(not isinstance(w,dict) or not isinstance(w.get('word'),str) or type(w.get('start')) not in (float,int) or type(w.get('end')) not in (float,int) or not 0<=w['start']<w['end']<=duration+.15 for w in words):continue
            return words,str(candidate)
        except (OSError,ValueError,TypeError,KeyError):pass
    return [],None

def energy_peaks(path,ffmpeg):
    pcm=subprocess.check_output([ffmpeg,'-v','error','-nostdin','-i',path,'-vn','-map','0:a:0','-ac','1','-ar','2000','-f','s16le','-'],timeout=14400)
    peaks=peaks_from_pcm(pcm,rate=2000,bins_per_second=20)
    sample=sorted(peaks[::max(1,math.floor(len(peaks)/4000))])
    percentile=sample[math.floor(len(sample)*.96)] if sample else 0
    return peaks,max(12,percentile or 255)

def media_fps(video):
    rate=video.get('avg_frame_rate','0/0')
    if rate in ('0/0','0'):rate=video.get('r_frame_rate','0/0')
    try:
        fps=Fraction(rate);nominal=Fraction(video.get('r_frame_rate','0/1'))
        standards=[Fraction(x) for x in ('24','25','30','48','50','60','100','120','24000/1001','30000/1001','60000/1001')]
        if nominal in standards and abs(float(fps/nominal)-1)<.001:fps=nominal
        if not 10<=float(fps)<=120:raise ValueError()
        return float(fps)
    except (ValueError,ZeroDivisionError):raise ValueError('FPS nao identificado na fonte.')


def analyze(request):
    config=request['config'];result=[]
    for path in dict.fromkeys(item['path'] for item in request['items']):
        probe=json.loads(subprocess.check_output([config['ffprobe'],'-v','error','-show_streams','-show_format','-of','json',path],timeout=60))
        video=next(s for s in probe['streams'] if s['codec_type']=='video')
        fps=media_fps(video)
        duration=float(probe['format']['duration'])
        if abs(fps-request['fps'])>.01:raise ValueError('Fonte com FPS diferente da timeline; este primeiro corte exige FPS iguais.')
        if request.get('minPauseFrames')==2:
            streams=[s for s in probe['streams'] if s['codec_type']=='audio']
            if len(streams)!=1:raise ValueError('Este modo exige uma fonte com um unico stream de audio; nao vou arriscar a fala de outra faixa.')
            try:
                video_start=float(video['start_time']);audio_start=float(streams[0]['start_time'])
            except (KeyError,TypeError,ValueError):raise ValueError('Nao consegui confirmar o inicio de audio e video. Analise interrompida.')
            if not math.isfinite(video_start) or not math.isfinite(audio_start) or abs(video_start-audio_start)>.001:raise ValueError('O inicio do audio e do video difere na fonte. Este modo preserva a fala e interrompe sem marcar cortes.')
        vad=vad_local.analyze(path,config['ffmpeg'],duration)
        words,word_source=read_words(path,duration)
        if request.get('minPauseFrames')==2:
            from frame_silence import analyze as frame_analyze
            cuts=frame_analyze(path,config['ffmpeg'],duration,fps,words,vad['speech'],channels=int(streams[0]['channels']))
        else:
            peaks,norm=energy_peaks(path,config['ffmpeg'])
            payload={'words':words,'duration':duration,'peaks':peaks,'rate':20,'options':{'norm':norm,'speech':vad['speech'],'speechPadding':vad['speechPadding'],'strength':request['strength'],'minSilenceSeconds':.9}}
            raw=subprocess.run([config['node'],str(Path(__file__).parent/'engine/detect.mjs')],input=json.dumps(payload),text=True,capture_output=True,timeout=120,check=True)
            cuts=json.loads(raw.stdout)
        result.append({'path':path,'fps':fps,'duration':duration,'cuts':cuts,'word_source':word_source,'words':len(words),'speech_regions':len(vad['speech'])})
    return result
if __name__=='__main__':
    request=Path(sys.argv[1]);output=Path(sys.argv[2])
    try:output.write_text(json.dumps({'ok':True,'sources':analyze(json.loads(request.read_text('utf-8')))},ensure_ascii=False),encoding='utf-8')
    except Exception as exc:
        output.write_text(json.dumps({'ok':False,'error':str(exc)[:1000]},ensure_ascii=False),encoding='utf-8');raise
