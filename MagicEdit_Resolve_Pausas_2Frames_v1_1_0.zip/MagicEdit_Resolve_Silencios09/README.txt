MAGIC EDIT NO DAVINCI — PAUSAS MAIORES QUE2FRAMES — v1.1.0

COMO INSTALAR
Salve o projeto e feche completamente Resolve.exe. Extraia o ZIP e execute
INSTALAR.bat. Confirme a mensagem Instalacao concluida. Abra Resolve > Area de
Trabalho > Scripts > Magic Edit. O titulo deve mostrar1.1.0.
Atualiza as versoes1.0.0/1.0.1/1.0.2 com fontes e backups verificados.

DOIS BOTOES
1. ANALISAR: le audio local e cria/verifica marcadores verdes na REGUA DA TIMELINE,
   na aba Editar. Nao corta nenhum clipe. A contagem e o status atualizam sozinhos.
   Aplique fica desabilitado ate concluir com marcadores confirmados.
2. APLICAR CORTES: aplica os marcadores aprovados na MESMA timeline e fecha os
   intervalos removidos em V1/A1. Nao deixa outra timeline de resultado no projeto.
   Salve o projeto depois. Para excluir um corte proposto, apague seu marcador
   antes de aplicar. Mover/estender para fora da area protegida exige reanalisar.
O antigo ATUALIZAR so recontava; foi retirado.

O LIMITE CONFIRMADO
Procura pausas ESTRITAMENTE MAIORES que2frames, em vez de0,9segundos.
Nao significa que a pausa final tera2frames nem que toda pausa curta sera cortada.
Mantem1frame de margem em cada borda da fala; so usa frames inteiros dentro da
energia baixa e protege as palavras do JSON correspondente, quando disponivel.
Exemplo ideal a30fps:4frames de pausa,1de margem por lado,2frames centrais cortados.
A resolucao de5ms e o arredondamento para dentro podem preservar mais material.
Som sustentado, fala fraca e limites incertos sao tratados conservadoramente;
confira os marcadores ouvindo. Nao promete reconhecimento perfeito de fonemas.
Mede pico/RMS por canal, sem cancelar canais estereo na analise de energia.
Silero confirma presenca de voz; ausencia de transcricao nao inventa silencio.
Fontes com varios streams de audio, ou inicio audio/video diferente, interrompem
este modo para evitar cortes em tempos incorretos. Nao ativa servicos pagos.

USE NO BRUTO V1/A1, ANTES DE COR, FX E MOTIONS
Exige video/audio correspondentes, FPS iguais, sem retime/camadas/legendas/Fusion,
sem transformacoes ou clipes desativados. Nao transporta grades/FX opacos da API.
Marcadores/flags locais dos clipes sao recusados; os da regua da timeline sao
preservados e deslocados conforme os cortes. Nao use para remontar edicao final.

RECUPERACAO E DIAGNOSTICO
Antes de alterar: exporta .drt e snapshot em
%LOCALAPPDATA%\MagicEdit\Silencios09\recovery
Usa uma timeline temporaria apenas para testar montagem e remove ao concluir.
Se o teste divergir, nao apaga os clipes originais; registra valores esperados e
lidos em %LOCALAPPDATA%\MagicEdit\Silencios09\ultimo_posicionamento.json.
Se a aplicacao falhar depois de iniciar, tenta restaurar a montagem original.
Se ate a restauracao falhar/interromper, importe o .drt indicado pelo erro via
Arquivo > Importar > Timeline. Nao presume que Ctrl+Z desfaca todo o script.
Erros gerais tambem ficam em ultimo_erro.json nessa mesma pasta.

INSTALACAO REVERSIVEL
RESTAURAR.bat, com Resolve fechado, desfaz uma atualizacao por execucao. Isso
restaura o programa anterior; NAO desfaz cortes de uma timeline (use o .drt).
Apenas os13backups de scripts previamente identificados saem do menu; ficam em
history fora de Scripts. Outros utilitarios, Motion, Transcricao e o MCP nao sao
modificados. Videos, projetos privados e chaves nunca entram neste pacote.

VERIFICACAO
42testes automatizados, decoder/worker reais e atualizacao/restauracao simulada
com arquivos originais. API/UI nativa e resultado editorial precisam do primeiro
teste no Resolve do usuario. Esta maquina nao tem Resolve/Windows conectado.
