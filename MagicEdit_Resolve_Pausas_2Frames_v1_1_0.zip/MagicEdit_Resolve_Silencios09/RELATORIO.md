# Magic Edit Resolve1.1.0 — limite em frames e aplicação na própria timeline

Pedido confirmado: detectar pausas maiores que2frames (não deixar2frames finais),
marcar antes de autorização, aplicar na timeline selecionada e retirar Recontar.

## Resultado

- UI dois botões; Aplicar desabilitado até concluir análise e confirmar os
  marcadores lidos pelo Resolve. Análise não chama DeleteClips nem cria timeline.
- Detector separado do Desktop: PCM16k em blocos5ms, pico/RMS conservadores por
  canal; limite estrito antes das margens,1frame de margem por borda, quantização
  para dentro do silêncio. Palavras associadas ao mesmo arquivo/duração protegidas.
- Silero serve como presença de voz. Não desfaz margens do detector externo nem
  reutiliza seus0,9s; esse modo é novo e sua qualidade precisa de revisão auditiva.
- Evita mistura de canais para medir energia. Recusa múltiplos streams de áudio,
  timestamps ausentes/não finitos e diferença de início áudio/vídeo >1ms.
- Aplicação na mesma timeline: recuperação .drt e journal fora do projeto;
  validação descartável de montagem antes da primeira remoção. Verifica seleção
  ativa por UID antes de apagar/inserir e no rollback. Não deixa cópia de resultado.
- Testa duas convenções de endFrame; só aceita a que reproduzir posições e
  durações EXATAS. Não tolera deslocamento fonte/sincronismo. Preserva formato A1.
- Mantém marcadores da régua do usuário e ajusta tempos após remoções. Se dois
  colidirem, interrompe antes de alterar. Excluir um marcador de corte o desativa;
  movê-lo para fora do intervalo protegido exige reanalisar.
- Em falha após início, restaura clipes/marcadores originais; .drt contém
  recuperação completa caso o processo pare ou a API também recuse o rollback.

## Evidência

42testes passam, incluindo regressões RED/GREEN para:

- limite exato2frames, pausa4frames e margens nos FPS24/25/30/60;
- palavra/fonema de baixa energia protegido e energia sustentada;
- cancelamento estéreo real em FFmpeg e timestamp áudio+0,5s real em MKV;
- análise sem cortes, readback falso de marcador sem criar plano válido;
- UI não autoriza Aplicar antes da análise nem aplica ao concluí-la;
- aplicação no mesmo objeto, sem cópias remanescentes, dois padrões de endFrame;
- falha na prova/DRT/reseleção sem limpar original; falha na aplicação com rollback;
- cortes adjacentes em clipes distintos, marcadores de usuário e formato mono A1;
- upgrades dos pacotes reais1.0.1/1.0.2, idempotência, preservação de runtime e
  restauração dos arquivos anteriores, além dos testes prévios de instalação.

Worker real Python/ONNX/FFmpeg: dois trechos privados8,07s/76,87s produziram3/14
intervalos, alinhados a frames e sem alterar hashes dos vídeos. Isso comprova a
execução; não substitui aprovação editorial/auditiva. Nenhum trecho/transcrição
é distribuído. Revisor independente confirmou correções e42testes passando.

## Limites materiais

Uso exclusivamente no bruto V1/A1 antes de cor/FX/motions. A API não permite
preservar com fidelidade toda grade/efeito opaco ao remontar clipes; esta versão
não promete isso. Recusa Fusion, transformações, retime, conteúdo em outras
camadas/legendas, flags/marcadores locais e clipes desativados. Propriedades
expostas são copiadas e conferidas; grades opacas dependem da restrição ao bruto.
Não é detector de repetições/Gemini/pigarros.

O erro original do usuário era genérico e não trouxe os valores de posição.
Não se afirma que sua causa específica foi corrigida. Agora a prova de montagem
antes da edição e ultimo_posicionamento.json permitem verificar sem apagar o
original. Windows/Resolve21.1.1 real ainda precisa do teste do usuário.
