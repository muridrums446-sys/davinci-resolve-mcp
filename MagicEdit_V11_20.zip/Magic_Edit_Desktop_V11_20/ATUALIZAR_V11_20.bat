@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Magic Edit Desktop - Atualizar V11.20
set "PY=py -3"
where py >nul 2>nul
if errorlevel 1 set "PY=python"
echo Feche o Magic Edit e a janela do servidor antes de continuar.
echo Destino: C:\MagicEdit\Desktop_V10
echo O backup integral sera verificado antes de substituir arquivos.
echo.
%PY% update_desktop.py
set "RESULT=%ERRORLEVEL%"
echo.
if not "%RESULT%"=="0" echo Atualizacao interrompida. Leia o erro acima; nao apague o backup.
pause
exit /b %RESULT%
