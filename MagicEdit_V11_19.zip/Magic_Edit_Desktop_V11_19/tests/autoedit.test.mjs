import test from 'node:test';
import assert from 'node:assert/strict';
import {analyzeTranscript,selectionsToCuts,automaticCuts,reviewablePrecuts,projectCutsOnOpen} from '../src/autoedit.js';
const build=(texts)=>texts.map((word,i)=>({word,start:i*.45,end:i*.45+.25}));
test('Detecta repeticao literal de frase e preserva segunda tentativa',()=>{
  const w=build(['hoje','vou','mostrar','hoje','vou','mostrar','resultado']);
  const out=analyzeTranscript(w,4);
  const s=out.find(x=>x.type==='repeat');
  assert.ok(s,JSON.stringify(out)); assert.equal(s.from,0);assert.equal(s.to,2);
});
test('Nao remove automaticamente palavra e / e isolado / termos normais',()=>{
 const w=build(['que','é','importante','o','produto']);
 const out=analyzeTranscript(w,5);
 assert.ok(!out.some(s=>s.type==='filler'));
});
test('Sugere muletas reais e pausa longa sem invadir palavras',()=>{
 const w=[{word:'vamos',start:0,end:.3},{word:'hã',start:.5,end:.8},{word:'continuar',start:4,end:4.4}];
 const out=analyzeTranscript(w,4.5);
 assert.ok(out.some(s=>s.type==='filler'));
 const si=out.find(s=>s.type==='silence');assert.ok(si);assert.ok(si.start>.8&&si.end<4);
});
test('Selecao vira cortes sem aplicar nada ao projeto',()=>{
 const w=build(['olá','ahn','vamos']);const proposals=analyzeTranscript(w,2);
 const before=w.map(x=>({...x}));const result=selectionsToCuts(proposals.filter(x=>x.type==='filler'),w);
 assert.ok(result.deleted.has(1));assert.deepEqual(w,before);
});
test('sem transcricao nao detecta',()=>assert.deepEqual(analyzeTranscript([],10),[]));
test('recomeco parcial e marcado para revisao e nunca aplicado automaticamente',()=>{
 const w=build(['hoje','vamos','explicar','os','lucros','da','empresa','hoje','vamos','explicar','os','ganhos','da','empresa']);
 const out=analyzeTranscript(w,8);
 assert.ok(out.some(s=>s.type==='repeat'&&s.confidence==='baixa'),JSON.stringify(out));
});
test('tentativa interrompida com palavras intermediarias risca somente a primeira fala',()=>{
 const w=build(['então','um','exemplo','de','você','comprou','uma','ação','lá','e','você...','então','exemplo','que','você','comprou','uma','ação','lá','por','cem']);
 const out=analyzeTranscript(w,12);
 const restart=out.find(x=>x.type==='restart'&&x.from===4&&x.to===10);
 assert.ok(restart,JSON.stringify(out));
 assert.equal(restart.confidence,'média');
 const cuts=reviewablePrecuts(out,w);
 assert.ok(cuts.deleted.has(4)&&cuts.deleted.has(10));
 assert.ok(!cuts.deleted.has(14),'a segunda versao permanece');
});
test('reformulacao com pausa vira sugestao, sem corte automatico',()=>{
 const w=build(['para','você,','tipo','daqui','50','anos,','você,','tipo','daqui','10','anos']);
 w[6].start=w[5].end+.8;w[6].end=w[6].start+.2;
 for(let i=7;i<w.length;i++){w[i].start=w[i-1].end+.1;w[i].end=w[i].start+.2;}
 const out=analyzeTranscript(w,10);
 const s=out.find(x=>x.requiresReview&&x.from===1&&x.to===5);
 assert.ok(s,JSON.stringify(out));
 assert.equal(reviewablePrecuts(out,w).deleted.has(1),false);
});
test('elaboracao imediata nao e confundida com tomada ruim',()=>{
 const w=build(['um','pouco','mais','barata,','um','pouco','mais','desvalorizada']);
 assert.equal(analyzeTranscript(w,8).filter(x=>x.requiresReview).length,0);
});
test('frase falada de erro e sugestao revisavel',()=>{
 const w=build(['pera','aí','errei','vou','recomeçar']);
 const out=analyzeTranscript(w,4);
 assert.ok(out.some(s=>s.type==='restart'&&s.confidence==='média'));
});
test('repeticao didatica sinalizada por repito fica preservada',()=>{
 const w=build(['repito','hoje','vamos','falar','hoje','vamos','falar']);
 const out=analyzeTranscript(w,4);
 assert.ok(!out.some(s=>s.type==='repeat'));
});
test('frases curtas repetidas entram riscadas conforme preferencia V11.19',()=>{
 const w=build(['sem','crise,','sem','crise','pode','falar,','pode','falar']);
 const suggestions=analyzeTranscript(w,4);
 const cuts=automaticCuts(suggestions,w);
 assert.deepEqual([...cuts.deleted],[0,1,4,5]);
 assert.deepEqual(cuts.extraCuts,[]);
});
test('repeticoes de palavra e frase curta sao cortes restauraveis',()=>{
 const w=build(['beleza,','beleza','de','boa,','de','boa']);
 const suggestions=analyzeTranscript(w,3);
 assert.ok(suggestions.some(s=>s.type==='repeat'&&s.from===0&&s.confidence==='baixa'));
 assert.ok(suggestions.some(s=>s.type==='repeat'&&s.from===2&&s.confidence==='média'));
 assert.deepEqual([...automaticCuts(suggestions,w).deleted],[0,2,3]);
});
test('tres repeticoes comuns preservam a ultima ocorrencia',()=>{
 const w=build(['beleza?','beleza','beleza']);
 const cuts=automaticCuts(analyzeTranscript(w,2),w);
 assert.deepEqual([...cuts.deleted],[0,1]);
});
test('intervalos sem palavras e falas com enfase jamais entram no autocorte',()=>{
 const w=[...build(['repito','sem','crise','sem','crise']),{word:'fim',start:8,end:8.2}];
 const suggestions=analyzeTranscript(w,9);
 assert.ok(suggestions.some(s=>s.type==='silence'));
 assert.equal(automaticCuts(suggestions,w).deleted.size,0);
 assert.deepEqual(automaticCuts(suggestions,w).extraCuts,[]);
});
test('JSON antigo preserva exatamente as decisões salvas',()=>{
 const w=build(['sem','crise','sem','crise','fim']);
 const suggestions=analyzeTranscript(w,3);
 const legacy={schema:1,deletedIndices:[4]};
 assert.deepEqual([...projectCutsOnOpen(legacy,suggestions,w)].sort(),[4]);
 const reviewed={...legacy,autoEditVersion:1};
 assert.deepEqual([...projectCutsOnOpen(reviewed,suggestions,w)],[4]);
 assert.deepEqual(legacy.deletedIndices,[4]);
});
test('Sugestoes amarelas passam a pre-cortes restauraveis sem aplicar pausas textuais',()=>{
 const w=build(['de','boa,','de','boa','ele','ele','claro,','claro','ahn']);
 const suggestions=analyzeTranscript(w,9);
 const result=reviewablePrecuts(suggestions,w);
 assert.ok(result.deleted.has(0)&&result.deleted.has(1),'de boa pre-cortado');
 assert.ok(result.deleted.has(4),'ele pre-cortado');
 assert.ok(result.deleted.has(6),'claro pre-cortado');
 assert.ok(result.deleted.has(8),'ahn pre-cortado');
 assert.deepEqual(result.extraCuts,[],'lacuna textual nao e silencio acustico');
});
test('Projeto V11.8 abre sem adicionar novos cortes',()=>{
 const w=build(['sem','crise','sem','crise','claro','claro']);
 const suggestions=analyzeTranscript(w,3);
 assert.deepEqual([...projectCutsOnOpen({autoEditVersion:1,deletedIndices:[]},suggestions,w)],[]);
 assert.deepEqual([...projectCutsOnOpen({autoEditVersion:2,deletedIndices:[]},suggestions,w)],[]);
});
