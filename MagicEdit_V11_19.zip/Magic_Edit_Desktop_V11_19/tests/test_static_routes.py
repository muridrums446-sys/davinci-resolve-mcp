import sys
import threading
import unittest
import http.client
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import magicedit_server
from http.server import ThreadingHTTPServer


class TestInterfaceRoutes(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = ThreadingHTTPServer(('127.0.0.1', 0), magicedit_server.Handler)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()

    def test_all_frontend_assets_return_http_200(self):
        for route in ('/', '/src/main.js', '/src/preview_v11.js', '/src/engine.js', '/src/selection.js', '/src/word_hit.js', '/src/style.css'):
            with self.subTest(route=route):
                conn = http.client.HTTPConnection('127.0.0.1', self.server.server_address[1], timeout=5)
                try:
                    conn.request('GET', route)
                    resp = conn.getresponse()
                    content = resp.read()
                    self.assertEqual(200, resp.status)
                    self.assertGreater(len(content), 0)
                finally:
                    conn.close()
