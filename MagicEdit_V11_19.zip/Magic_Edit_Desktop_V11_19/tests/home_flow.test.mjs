import test from 'node:test';
import assert from 'node:assert/strict';

test('importar video pede chave, acompanha transcricao e so entao abre o editor', async () => {
  const nodes=new Map(),classes=new Set(['home-open']),calls=[],requests=[],windowListeners={};
  let savedProject=null,semanticJob=false;
  const ctx={setTransform(){},clearRect(){},fillRect(){},beginPath(){},moveTo(){},lineTo(){},stroke(){},fill(){},closePath(){},fillText(){},drawImage(){}};
  function node(id){
    if(!nodes.has(id))nodes.set(id,{
      id,innerHTML:'',textContent:'',value:'',hidden:false,disabled:false,checked:id==='autoSilenceEnabled',scrollTop:0,
      style:{},dataset:{},classList:{add(){},remove(){},toggle(){}},
      listeners:{},contains(){return true;},setAttribute(name,value){this[name]=value;},addEventListener(name,fn){this.listeners[name]=fn;},querySelector(){return null;},querySelectorAll(){return [];},
      getBoundingClientRect(){return {width:800,height:90,left:0,top:0};},getContext(){return ctx;},
      pause(){this.paused=true;},load(){},focus(){this.focused=true;},setPointerCapture(){},currentTime:0,paused:true
    });
    return nodes.get(id);
  }
  globalThis.document={body:{classList:{add(c){classes.add(c);},remove(c){classes.delete(c);}}},getElementById:node,querySelectorAll(){return [];}};
  globalThis.window={devicePixelRatio:1,addEventListener(name,fn){windowListeners[name]=fn;},getSelection(){return {removeAllRanges(){},isCollapsed:true};}};
  globalThis.localStorage={getItem(){return null;},setItem(){}};
  globalThis.confirm=()=>true;
  globalThis.Image=class {set src(value){this.url=value;}};
  globalThis.requestAnimationFrame=()=>0;
  globalThis.fetch=async (url,opts={})=>{
    const path=url.split('/').pop();calls.push(path);if(opts.body)requests.push({path,data:JSON.parse(opts.body)});
    if(path==='transcribe'||path==='export_mp4')semanticJob=false;
    if(path==='review_takes')semanticJob=true;
    const reply={
      recent:opts.method?{items:[]}:{items:[]},
      choose:{path:'C:/teste.mp4',media:{name:'teste.mp4',duration:60,fpsNum:30,fpsDen:1,width:640,height:360}},
      set_video:{path:'C:/teste.mp4',media:{name:'teste.mp4',duration:60,fpsNum:30,fpsDen:1,width:640,height:360}},
      open_project:{path:'C:/teste.json',text:JSON.stringify(savedProject)},
      waveform:{state:'done',peaks:[],rate:20},vad:{state:'done',speech:[]},
      transcribe:{started:true},review_takes:{started:true},export_mp4:{started:true},save:{path:'C:/teste.json'},
      status:semanticJob?{state:'done',message:'Revisão pronta',result:{suggestions:[{type:'restart',from:0,to:0,start:1,end:1.4,reason:'Revisão Groq: possível recomeço',confidence:'revisar',requiresReview:true,origin:'groq'}]}}:
        {state:'done',message:'Concluido',done:2,total:2,result:{words:[{word:'teste',start:1,end:1.4},{word:'claro',start:2,end:2.3},{word:'claro',start:2.5,end:2.8}],chunks:2,model:'whisper-large-v3',path:'C:/resultado.mp4'}}
    };
    return {ok:true,json:async()=>reply[path]??{}};
  };
  await import('../src/main.js');
  assert.match(node('app').innerHTML,/Quanto encurtar as pausas/);
  assert.match(node('app').innerHTML,/Trechos de áudio para conferir/);
  assert.match(node('app').innerHTML,/Continuar de onde parei/);
  node('silenceStrength').value='75';node('silenceStrength').oninput();
  assert.equal(node('silenceStrengthLabel').textContent,'Encurtar mais');
  await node('homeImport').onclick();
  assert.equal(classes.has('home-open'),true,'a tela inicial permanece ate informar a chave');
  assert.equal(node('homeKeyForm').hidden,false);
  assert.equal(calls.includes('transcribe'),false);
  node('homeApiKey').value='gsk_test-only';
  node('homeKeyForm').onsubmit({preventDefault(){}});
  for(let i=0;i<30&&classes.has('home-open');i++)await new Promise(resolve=>setTimeout(resolve,1));
  assert.equal(classes.has('home-open'),false,'editor abriu apos analise');
  assert.equal(node('homeProgressNumber').textContent,'100%');
  assert.equal(node('wordCount').textContent,'3 palavras');
  assert.match(node('transcript').innerHTML,/class="word deleted[^"]*"[^>]*data-idx="1"/,'repetição comum já entra riscada');
  assert.ok(calls.indexOf('status')>calls.indexOf('transcribe'));
  assert.equal(calls.filter(x=>x==='transcribe').length,1);
  await node('reviewTakesGroq').onclick();
  assert.equal(calls.filter(x=>x==='review_takes').length,1,'revisão Groq só começa pelo botão');
  assert.match(node('semanticStatus').textContent,/1 possível/);
  assert.doesNotMatch(node('transcript').innerHTML,/class="word deleted[^\"]*"[^>]*data-idx="0">teste<\/span>/,
    'revisão textual não corta automaticamente uma fala');
  const word={dataset:{idx:'0'},closest(selector){return selector==='.word[data-idx]'?this:null;}};
  node('player').paused=false;
  node('transcript').listeners.mousedown({button:0,target:word,clientX:10,clientY:10,shiftKey:false});
  node('transcript').listeners.mouseup({button:0,target:word});
  assert.equal(node('player').paused,true,'clique esquerdo pausa o video');
  assert.equal(node('player').currentTime,1,'clique esquerdo posiciona o playhead na palavra');
  const repeated={dataset:{idx:'1'},closest(selector){return selector==='.word[data-idx]'?this:null;}};
  node('transcript').listeners.contextmenu({target:repeated,preventDefault(){}});
  assert.doesNotMatch(node('transcript').innerHTML,/class="word deleted[^"]*"[^>]*data-idx="1"/,'clique direito restaura pre-corte');
  node('backHome').onclick();
  assert.equal(classes.has('home-open'),true);
  await node('homeImport').onclick();
  assert.equal(calls.filter(x=>x==='transcribe').length,2,'a chave da sessao inicia nova importacao automaticamente');
  assert.equal(classes.has('home-open'),false);
  assert.match(node('recentProjects').innerHTML,/recent_thumbnail/,'cartao apresenta miniatura real');
  assert.match(node('recentProjects').innerHTML,/data-recent-remove="0"/,'cartao tem botao para retirar do historico');
  const before=calls.filter(x=>x==='set_video').length;
  await node('recentProjects').listeners.click({stopPropagation(){},target:{closest(selector){return selector==='[data-recent-remove]'?{dataset:{recentRemove:'0'}}:null;}}});
  assert.match(node('recentProjects').innerHTML,/Seus projetos salvos aparecerão aqui/);
  assert.equal(calls.filter(x=>x==='set_video').length,before,'X nao abre nem apaga o video');
  node('backHome').onclick();
  await node('homeImport').onclick();
  node('rangeMode').onclick();
  node('timeline').listeners.pointerdown({pointerId:1,clientX:400});
  node('timeline').listeners.pointermove({pointerId:1,clientX:600});
  node('timeline').listeners.pointerup({pointerId:1,clientX:600});
  assert.equal(node('deleteRange').disabled,false,'arrasto escolhe intervalo');
  assert.equal(node('rangeSelection').hidden,false,'a selecao aparece sobre a onda');
  windowListeners.keydown({key:'Delete',target:{tagName:'DIV'},ctrlKey:false,metaKey:false,preventDefault(){}});
  assert.equal(node('deleteRange').disabled,true,'Delete consome a selecao');
  assert.match(node('summary').innerHTML,/Cortado: <b>00:00:15/,'a duracao final desconta o intervalo selecionado');
  await node('exportMp4').onclick();
  assert.equal(node('mp4ProgressTrack')['aria-valuenow'],'100');
  assert.match(node('mp4Progress').textContent,/100% · Vídeo final pronto/);
  assert.equal(node('mp4FinalPath').textContent,'C:/resultado.mp4');
  const segments=requests.findLast(x=>x.path==='export_mp4').data.segments;
  assert.deepEqual(segments,[{'in':0,'out':59},{'in':70,'out':900},{'in':1350,'out':1800}],
    'MP4 recebe apenas os trechos mantidos, incluindo os cortes textuais');
  node('undo').onclick();
  const originalSummary=node('summary').innerHTML;
  node('player').currentTime=20;
  windowListeners.keydown({key:'c',target:{tagName:'DIV'},ctrlKey:false,metaKey:false,altKey:false,repeat:false,preventDefault(){}});
  node('player').currentTime=25;
  node('splitAtPlayhead').onclick();
  assert.match(node('splitMarkers').innerHTML,/Divisão 00:00:20:00/);
  assert.match(node('splitMarkers').innerHTML,/Divisão 00:00:25:00/);
  assert.equal(node('summary').innerHTML,originalSummary,'C apenas divide, não elimina áudio ou vídeo');
  node('timeline').listeners.pointerdown({pointerId:1,clientX:800*22/60});
  node('timeline').listeners.pointerup({pointerId:1,clientX:800*22/60});
  assert.equal(node('player').paused,true,'clique no trecho mantém o player pausado');
  assert.equal(node('deleteRange').disabled,false);
  assert.match(node('rangeStatus').textContent,/00:00:20:00 a 00:00:25:00/);
  windowListeners.keydown({key:'Delete',target:{tagName:'DIV'},ctrlKey:false,metaKey:false,preventDefault(){}});
  await node('exportMp4').onclick();
  assert.deepEqual(requests.findLast(x=>x.path==='export_mp4').data.segments,
    [{in:0,out:59},{in:70,out:600},{in:750,out:1800}],
    'apenas o segmento selecionado entre duas divisões sai do MP4');
  await node('saveProject').onclick();
  const saved=JSON.parse(requests.findLast(x=>x.path==='save').data.contents);
  assert.deepEqual(saved.splitFrames,[600,750]);
  assert.deepEqual(saved.extraCuts,[{start:20,end:25}]);
  savedProject=saved;
  const transcriptions=calls.filter(x=>x==='transcribe').length;
  await node('recentProjects').listeners.click({target:{closest(selector){return selector==='[data-recent]'?{dataset:{recent:'0'}}:null;}}});
  assert.match(node('splitMarkers').innerHTML,/Divisão 00:00:20:00/,'marcadores persistem no JSON');
  assert.match(node('summary').innerHTML,/Cortado: <b>00:00:05/,'projeto reabre com corte manual');
  assert.equal(calls.filter(x=>x==='transcribe').length,transcriptions,'projeto abre sem retranscrever');
  node('timeline').listeners.contextmenu({clientX:800*22/60,preventDefault(){}});
  assert.doesNotMatch(node('summary').innerHTML,/Cortado: <b>00:00:05/,'restauração na timeline retira o corte do texto e da duração');
  node('rangeMode').onclick();
  node('timeline').listeners.pointerdown({pointerId:1,clientX:800/60});
  node('timeline').listeners.pointermove({pointerId:1,clientX:800*1.5/60});
  node('timeline').listeners.pointerup({pointerId:1,clientX:800*1.5/60});
  node('deleteRange').onclick();
  assert.match(node('transcript').innerHTML,/class="word deleted[^\"]*"[^>]*data-idx="0">teste<\/span>/,'corte temporal risca a palavra real');
  assert.doesNotMatch(node('transcript').innerHTML,/Trecho cortado/,'não mostra caixa genérica onde há palavras');
  node('transcript').listeners.contextmenu({target:word,preventDefault(){}});
  assert.doesNotMatch(node('transcript').innerHTML,/class="word deleted[^\"]*"[^>]*data-idx="0">teste<\/span>/,'direito restaura palavra e timeline');
  await node('saveProject').onclick();
  assert.deepEqual(JSON.parse(requests.findLast(x=>x.path==='save').data.contents).extraCuts,[]);
  node('player').currentTime=31.234;
  node('player').listeners.timeupdate();
  await new Promise(resolve=>setTimeout(resolve,750));
  const recovery=requests.findLast(x=>x.path==='autosave')?.data;
  assert.ok(recovery,'cortes salvos automaticamente sem abrir dialogo');
  assert.equal(recovery.playhead,31.234);
  assert.equal(recovery.words.length,3);
  assert.equal(JSON.stringify(recovery).includes('gsk_test-only'),false,'a chave nao entra no rascunho');
  node('backHome').onclick();
  assert.equal(node('homeContinue').hidden,false);
  await node('homeContinue').onclick();
  assert.equal(node('player').currentTime,31.234,'continuar recupera o playhead');
  assert.equal(calls.filter(x=>x==='transcribe').length,transcriptions,'retomada dispensa Groq');
});
