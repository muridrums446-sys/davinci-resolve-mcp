import sys
import shutil
import contextlib
import io
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from INSTALAR_V11 import FILES, install


class InstallerTest(unittest.TestCase):
    def test_failed_copy_restores_existing_code(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source, target = root / 'package', root / 'Desktop_V10'
            for rel in FILES:
                (source / rel).parent.mkdir(parents=True, exist_ok=True)
                (source / rel).write_text('V11', encoding='utf-8')
            for rel in ('INICIAR_MAGIC_EDIT.bat', 'magicedit_server.py', 'src/main.js'):
                (target / rel).parent.mkdir(parents=True, exist_ok=True)
                (target / rel).write_text('V10', encoding='utf-8')
            (source / 'package.json').write_text('{"version":"0.11.19"}')
            (target / 'package.json').write_text('{"version":"0.11.17"}')
            calls = 0

            def fail_second(src, dst):
                nonlocal calls
                calls += 1
                if calls == 2:
                    raise OSError('simulated copy failure')
                return shutil.copy2(src, dst)

            with contextlib.redirect_stdout(io.StringIO()):
                with self.assertRaisesRegex(OSError, 'simulated'):
                    install(source, target, verify=lambda *_: None, copy=fail_second)
            self.assertEqual((target / 'magicedit_server.py').read_text(), 'V10')
            self.assertEqual((target / 'src/main.js').read_text(), 'V10')

    def test_backup_and_preserve_user_project(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source, target = root / 'package', root / 'Desktop_V10'
            for rel in FILES:
                (source / rel).parent.mkdir(parents=True, exist_ok=True)
                (source / rel).write_text('V11', encoding='utf-8')
            for rel in ('INICIAR_MAGIC_EDIT.bat', 'magicedit_server.py', 'src/main.js', 'project.json'):
                (target / rel).parent.mkdir(parents=True, exist_ok=True)
                (target / rel).write_text('V10', encoding='utf-8')
            (source / 'package.json').write_text('{"version":"0.11.19"}')
            (target / 'package.json').write_text('{"version":"0.11.17"}')
            backup = install(source, target, verify=lambda *_: None)
            self.assertEqual((target / 'src/main.js').read_text(), 'V11')
            self.assertEqual((backup / 'src/main.js').read_text(), 'V10')
            self.assertEqual((backup / 'project.json').read_text(), 'V10')
            self.assertEqual((target / 'project.json').read_text(), 'V10')
            self.assertEqual((target / 'INICIAR_MAGIC_EDIT.bat').read_text(), 'V11')
            self.assertEqual((backup / 'INICIAR_MAGIC_EDIT.bat').read_text(), 'V10')


if __name__ == '__main__':
    unittest.main()
