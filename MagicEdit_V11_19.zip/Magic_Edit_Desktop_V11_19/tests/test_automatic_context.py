import unittest
from review_takes import validate_suggestions

def words(text):
    return [dict(word=t,start=i*.4,end=i*.4+.3) for i,t in enumerate(text.split())]

class AutomaticContextTest(unittest.TestCase):
    def test_model_duplicate_needs_a_matching_later_take_before_automatic_cut(self):
        w=words('hoje vamos explicar os dividendos hoje vamos explicar os dividendos')
        item={'from':0,'to':4,'reason':'A primeira tomada se repete na segunda','category':'duplicate','score':.99,'keepFrom':5,'keepTo':9}
        result=validate_suggestions({'suggestions':[item]},w,(0,10,0,10))
        self.assertFalse(result[0]['requiresReview'])
        self.assertEqual(result[0]['category'],'duplicate')
        item['keepFrom']=999
        self.assertTrue(validate_suggestions({'suggestions':[item]},w,(0,10,0,10))[0]['requiresReview'])

    def test_different_numbers_are_not_a_literal_duplicate(self):
        w=words('daqui a cinquenta anos teremos daqui a dez anos teremos')
        item={'from':0,'to':4,'reason':'Duas falas parecidas','category':'duplicate','score':.99,'keepFrom':5,'keepTo':9}
        self.assertTrue(validate_suggestions({'suggestions':[item]},w,(0,10,0,10))[0]['requiresReview'])

    def test_low_confidence_or_invalid_score_cannot_apply_a_context_cut(self):
        w=words('a bolsa representa empresas fecha aquela janela agora continuamos o investimento')
        for score in [.5,True,float('nan'),1.5]:
            item={'from':4,'to':7,'reason':'Conversa sobre o ambiente da gravacao','category':'offtopic','score':score,'keepFrom':None,'keepTo':None}
            self.assertTrue(validate_suggestions({'suggestions':[item]},w,(0,len(w),0,len(w)))[0]['requiresReview'])

    def test_high_confidence_context_cut_is_auditable_and_not_a_file_mutation(self):
        w=words('a bolsa representa empresas fecha aquela janela agora continuamos o investimento')
        item={'from':4,'to':7,'reason':'Conversa sobre o ambiente da gravacao','category':'offtopic','score':.99,'keepFrom':None,'keepTo':None}
        before=[dict(x) for x in w]
        result=validate_suggestions({'suggestions':[item]},w,(0,len(w),0,len(w)))
        self.assertFalse(result[0]['requiresReview'])
        self.assertEqual(w,before)
