import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import magicedit_server as server


class AutosaveTest(unittest.TestCase):
    def test_recovery_keeps_edits_and_latest_position_without_touching_source(self):
        with tempfile.TemporaryDirectory() as temp:
            base = Path(temp)
            video = base / 'original.mkv'
            video.write_bytes(b'video intacto')
            doc = {
                'schema': 1, 'autoEditVersion': 2, 'projectName': 'Teste',
                'path': str(video), 'media': {'name': video.name, 'duration': 90},
                'words': [{'word': 'fala', 'start': 1, 'end': 1.5}],
                'deletedIndices': [0], 'extraCuts': [{'start': 3, 'end': 7}],
                'splitFrames': [30], 'model': 'whisper-large-v3', 'playhead': 8.5,
            }
            with patch.object(server, 'AUTOSAVE_PATH', base / 'autosave.json'), \
                    patch.object(server, 'AUTOSAVE_POSITION_PATH', base / 'position.json'):
                server.write_autosave(doc)
                server.write_autosave_position(str(video), 25.125)
                restored = server.read_autosave()
                self.assertEqual(restored['playhead'], 25.125)
                self.assertEqual(restored['deletedIndices'], [0])
                self.assertEqual(restored['extraCuts'], [{'start': 3, 'end': 7}])
                self.assertEqual(restored['splitFrames'], [30])
                self.assertEqual(video.read_bytes(), b'video intacto')
                server.write_autosave_position(str(base / 'another.mkv'), 50)
                self.assertEqual(server.read_autosave()['playhead'], 8.5)

    def test_invalid_or_empty_autosave_is_ignored(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / 'autosave.json'
            with patch.object(server, 'AUTOSAVE_PATH', path):
                self.assertIsNone(server.read_autosave())
                path.write_text('not json')
                self.assertIsNone(server.read_autosave())
                with self.assertRaises(ValueError):
                    server.write_autosave({'schema': 1, 'path': 'x', 'words': [], 'playhead': 1})
