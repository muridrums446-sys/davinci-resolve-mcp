import hashlib
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from mp4_export import _publish_video, export_mp4, validate_segments


class MP4ExportTest(unittest.TestCase):
    def test_real_cut_preserves_original_and_exports_synced_av(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            original = root / 'original.mp4'
            output = root / 'resultado.mp4'
            subprocess.run(['ffmpeg', '-hide_banner', '-loglevel', 'error', '-f', 'lavfi', '-i',
                            'testsrc2=size=160x90:rate=25:duration=4', '-f', 'lavfi', '-i',
                            'sine=frequency=440:sample_rate=48000:duration=4', '-shortest',
                            '-c:v', 'libx264', '-c:a', 'aac', str(original)], check=True)
            before = hashlib.sha256(original.read_bytes()).hexdigest()
            media = {'duration': 4.0, 'fpsNum': 25, 'fpsDen': 1}
            updates = []
            seen = []
            def on_progress(done, total):
                updates.append((done, total))
                seen.extend(p.name for p in root.iterdir() if p.is_dir() or p.suffix == '.mkv')
            result = export_mp4(str(original), media,
                                [{'in': 0, 'out': 25}, {'in': 50, 'out': 75}],
                                str(output), 'ffmpeg', on_progress)
            streams = json.loads(subprocess.check_output(['ffprobe', '-v', 'error', '-show_streams',
                                                           '-show_format', '-of', 'json', str(output)]))
            self.assertEqual({stream['codec_type'] for stream in streams['streams']}, {'video', 'audio'})
            self.assertAlmostEqual(float(streams['format']['duration']), 2.0, delta=.14)
            video, audio = sorted(streams['streams'], key=lambda stream: stream['codec_type'], reverse=True)
            self.assertLess(abs(float(video['duration'])-float(audio['duration'])), .15)
            self.assertLess(abs(float(video['start_time'])-float(audio['start_time'])), .08)
            self.assertEqual(result['segments'], 2)
            self.assertEqual(result['path'], str(output))
            self.assertEqual(result['bytes'], output.stat().st_size)
            self.assertEqual(sorted(p.name for p in root.iterdir()), ['original.mp4', 'resultado.mp4'])
            self.assertEqual(seen, [], 'trechos temporarios nao devem aparecer na pasta escolhida')
            self.assertEqual(updates[-1], (100, 100))
            self.assertEqual(hashlib.sha256(original.read_bytes()).hexdigest(), before)
            self.assertGreater(len(updates), 2)
            with self.assertRaisesRegex(ValueError, 'existe'):
                export_mp4(str(original), media, [{'in': 0, 'out': 25}], str(output), 'ffmpeg')
            with self.assertRaisesRegex(ValueError, 'original'):
                export_mp4(str(original), media, [{'in': 0, 'out': 25}], str(original), 'ffmpeg')

    def test_failure_cleans_pending_and_does_not_publish_broken_video(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            original = root / 'original.mp4'
            output = root / 'resultado.mp4'
            subprocess.run(['ffmpeg', '-hide_banner', '-loglevel', 'error', '-f', 'lavfi', '-i',
                            'testsrc2=size=80x48:rate=25:duration=1', '-f', 'lavfi', '-i',
                            'sine=frequency=440:sample_rate=48000:duration=1', '-shortest',
                            '-c:v', 'libx264', '-c:a', 'aac', str(original)], check=True)
            with patch('mp4_export._verify_video', side_effect=RuntimeError('bad probe')):
                with self.assertRaisesRegex(RuntimeError, 'bad probe'):
                    export_mp4(str(original), {'duration': 1.0, 'fpsNum': 25, 'fpsDen': 1},
                               [{'in': 0, 'out': 25}], str(output), 'ffmpeg')
            self.assertEqual(sorted(p.name for p in root.iterdir()), ['original.mp4'])

    def test_publish_falls_back_to_copy_across_disks_and_removes_partial_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            intermediate, output = root / 'render.mp4', root / 'final.mp4'
            intermediate.write_bytes(b'A' * 8_000_000)
            updates = []
            with patch('mp4_export.os.replace', side_effect=OSError('other disk')):
                _publish_video(intermediate, output, lambda done, total: updates.append(done))
            self.assertEqual(output.read_bytes(), intermediate.read_bytes())
            self.assertEqual(sorted(p.name for p in root.iterdir()), ['final.mp4', 'render.mp4'])
            self.assertTrue(any(97 < p <= 99 for p in updates))

    def test_invalid_ranges_rejected(self):
        media = {'duration': 4, 'fpsNum': 25, 'fpsDen': 1}
        for segments in ([], [{'in': 0, 'out': 101}],
                         [{'in': 25, 'out': 50}, {'in': 49, 'out': 75}],
                         [{'in': True, 'out': 25}], [{'in': 2, 'out': 2}]):
            with self.subTest(segments=segments), self.assertRaises(ValueError):
                validate_segments(segments, media)
