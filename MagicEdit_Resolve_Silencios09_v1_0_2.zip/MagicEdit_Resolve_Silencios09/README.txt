CORRECAO DE CONSOLE v1.0.2
Corrige a falha: module fu_stdout has no attribute flush. O console Python
do Resolve nao implementa flush(); o adaptador agora escreve sem exigir isso,
no inicio/fim da analise e na criacao da copia. Detector e ajuste0,9s iguais.
Atualiza1.0.0/1.0.1 com backup verificado; RESTAURAR.bat desfaz uma etapa.

MAGIC EDIT NO DAVINCI — SILENCIOS >0,9s

Instalacao dirigida ao painel/motor que voce enviou para revisao.
1. Salve o projeto e feche o DaVinci Resolve.
2. Extraia o ZIP em Downloads, fora das pastas instaladas.
3. Execute INSTALAR.bat. Aguarde verificacao do ambiente e backup.
4. Apos sucesso, abra Resolve > Area de Trabalho > Scripts > Magic Edit.
5. Use uma timeline do bruto: V1 com seu audio correspondente em A1,
   antes de adicionar motions, B-roll, retimes ou efeitos.
6. O ajuste Equilibrado agora e fixo; o seletor foi removido para simplificar.
7. ANALISAR roda em processo separado e marca pausas maiores que0,9s. Confira os marcadores verdes.
   A janela informa o tempo; Fechar cancela o processo de analise.
8. CRIAR COPIA monta outra timeline com video/audio e confere suas posicoes.
   A original e o video bruto sao preservados. Salve o projeto no Resolve.

MESMO DETECTOR, DADOS COMPATIVEIS
O pacote usa os mesmos arquivos detectVerifiedSilences JavaScript, audio_wave.py,
modelo Silero e vad_local.py do DesktopV11.28:0,9s exatos nao entram, margens de
voz sao preservadas. A intensidade interna permanece50 (Equilibrado), sem seletor na interface.
A analise considera o primeiro stream de audio da fonte, como o aplicativo.
Alteracoes de volume/efeitos da timeline nao mudam o audio original analisado.

Quando houver autosave/JSON do Magic Edit com caminho/duracao correspondentes,
as palavras tambem protegem as bordas. Sem JSON correspondente, a Console
informa que a protecao e Silero+energia; os cortes podem diferir da edicao
externa que tinha transcricao. Nao e detector de repeticoes ou pigarros isolados.

O primeiro corte e para material bruto. A montagem nova usa a midia original;
nao e uma copia de grades, efeitos, transicoes ou mixagem previamente adicionados.
Nao use para remontar uma edicao ja finalizada. Camadas adicionais, composicoes
Fusion, transformacoes e fontes V1/A1 diferentes fazem a aplicacao interromper.

LIMPEZA E RECUPERACAO
Somente os13 arquivos de backup do levantamento sao retirados do menu. Os4
utilitarios sem backup no nome permanecem. Arquivos guardados fora de Scripts:
%LOCALAPPDATA%\MagicEdit\Silencios09\history
Cada instalacao tem copia verificada por SHA256 e manifesto para restaurar.
Execute RESTAURAR.bat com Resolve fechado para desfazer esta atualizacao e
repor os arquivos anteriores, inclusive os backups que apareciam no menu.
Arquivos alterados posteriormente por voce nao sao sobrescritos pela restauracao.

RECURSOS
Usa Node18+ ja utilizado pelo Motion, FFmpeg/FFprobe e Python com numpy/onnxruntime.
Se as bibliotecas Python faltarem, prepara um venv proprio e baixa esses pacotes
gratuitos antes de alterar o painel. Nao muda o venv do MCP. Nao ativa faturamento,
nao usa Gemini, nao envia audio/texto pela internet, nao modifica Motion/Transcricao.
Se Node/FFmpeg faltarem, a instalacao interrompe com aviso.

VERIFICACAO E LIMITES
Testes automatizados locais cobrem detector, fontes/frames, criacao de candidata,
recuperacao, backup e limpeza. API do Resolve simulada na nuvem.
O comportamento real do menu, AppendToTimeline e vinculo A/V precisa de um
primeiro teste no seu Resolve21.1.1; nao foi validado ao vivo nesta maquina.
Se ocorrer erro, preserve a original e envie o aviso/Console. Nao exclua history.
