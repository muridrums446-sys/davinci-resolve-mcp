@echo off
chcp 65001 >nul
cd /d "%~dp0"
set "PY=py -3"
where py >nul 2>nul
if errorlevel 1 set "PY=python"
%PY% instalar.py
set "RESULT=%ERRORLEVEL%"
pause
exit /b %RESULT%
