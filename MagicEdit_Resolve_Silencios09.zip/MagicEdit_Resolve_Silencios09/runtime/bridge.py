"""Resolve-side adapter: marker plan -> verified separate V1/A1 candidate."""
import datetime,hashlib,json,math,os,signal,subprocess,time,uuid
from pathlib import Path
ROOT=Path(__file__).resolve().parent
PREFIX='SIL_ESTAVEL_09_'

def state_dir():
    return Path(os.environ.get('LOCALAPPDATA',str(Path.home()/'.local/share')))/'MagicEdit/Silencios09'
def read_config():return json.loads((state_dir()/'active.json').read_text('utf-8'))
def dump(path,data):
    path.parent.mkdir(parents=True,exist_ok=True);temp=path.with_name(path.name+'.'+uuid.uuid4().hex+'.tmp')
    try:temp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8');temp.replace(path)
    finally:temp.unlink(missing_ok=True)
def ctx(bmd):
    resolve=bmd.scriptapp('Resolve')
    if not resolve:raise ValueError('Nao consegui conectar ao Resolve.')
    project=resolve.GetProjectManager().GetCurrentProject()
    timeline=project.GetCurrentTimeline() if project else None
    if not timeline:raise ValueError('Abra o projeto e a timeline do bruto.')
    return resolve,project,timeline,project.GetMediaPool()
def uid(obj):
    method=getattr(obj,'GetUniqueId',None)
    return str(method() if callable(method) else obj.GetName())
def source_item(clip):
    media=clip.GetMediaPoolItem()
    if not media:raise ValueError('Clipe gerado/composto nao suportado no primeiro corte.')
    start,end=int(clip.GetStart()),int(clip.GetEnd());api_start=int(clip.GetSourceStartFrame());api_end=int(clip.GetSourceEndFrame())
    offset=float(clip.GetLeftOffset())
    if not math.isfinite(offset) or offset<0 or abs(offset-round(offset))>1e-6:raise ValueError('Offset subframe nao suportado neste primeiro corte.')
    source=round(offset)
    # SourceStartFrame has measured one-frame readback errors; placement uses LeftOffset.
    if end<=start or min(abs(api_end-api_start-(end-start)),abs(api_end-api_start+1-(end-start)))>1:raise ValueError('Clipe retimado ou limites fonte incompatíveis; use o bruto sem alteracao de velocidade.')
    if clip.GetFusionCompCount():raise ValueError('Ha composicao Fusion; execute o primeiro corte antes dos motions.')
    props=clip.GetProperty() or {}
    for name,default in {'ZoomX':1,'ZoomY':1,'Pan':0,'Tilt':0,'RotationAngle':0,'Opacity':100}.items():
        if name in props and abs(float(props[name])-default)>1e-6:raise ValueError('Ha transformacoes no clipe; use uma timeline do bruto antes dos efeitos.')
    path=media.GetClipProperty('File Path')
    if not path or not Path(path).is_file():raise ValueError('Midia original indisponivel: '+str(path))
    stat=Path(path).stat()
    return {'path':path,'start':start,'end':end,'source_start':source,'source_end':source+end-start,'size':stat.st_size,'mtime':stat.st_mtime_ns},media

def capture(project,timeline):
    for kind in ('video','audio'):
        for track in range(2,timeline.GetTrackCount(kind)+1):
            if timeline.GetItemListInTrack(kind,track):raise ValueError('Use o bruto em V1/A1, antes de adicionar camadas ou B-roll.')
    videos=sorted(timeline.GetItemListInTrack('video',1) or [],key=lambda c:c.GetStart())
    audios=sorted(timeline.GetItemListInTrack('audio',1) or [],key=lambda c:c.GetStart())
    if not videos or len(videos)!=len(audios):raise ValueError('Este primeiro corte exige video e audio correspondentes em V1/A1.')
    fps=float(timeline.GetSetting('timelineFrameRate'))
    items=[];refs=[]
    for video,audio in zip(videos,audios):
        data,media=source_item(video);adata,amedia=source_item(audio)
        if data!=adata:raise ValueError('V1/A1 tem cortes, fontes ou sincronizacao diferentes; aplicacao interrompida.')
        source_fps=float(media.GetClipProperty('FPS'))
        if abs(source_fps-fps)>.01:raise ValueError('FPS da fonte diferente da timeline.')
        if items and data['start']<items[-1]['end']:raise ValueError('Sobreposicao/transicao entre clipes nao suportada no primeiro corte.')
        items.append(data);refs.append(media)
    snap={'project':uid(project),'timeline':uid(timeline),'name':timeline.GetName(),'fps':fps,'start':int(timeline.GetStartFrame()),'items':items}
    return snap,refs

def fingerprint(snapshot):return hashlib.sha256(json.dumps(snapshot,sort_keys=True).encode()).hexdigest()
def merge(cuts):
    result=[]
    for a,b in sorted(cuts):
        if b<=a:raise ValueError('Intervalo de corte invalido.')
        if result and a<=result[-1][1]:result[-1][1]=max(result[-1][1],b)
        else:result.append([a,b])
    return result

def build_keeps(items,cuts):
    for a,b in cuts:
        if not any(x['start']<=a<b<=x['end'] for x in items):raise ValueError('Marcador fora do clipe analisado.')
    cuts=merge(cuts)
    def removed_before(t):return sum(max(0,min(t,b)-a) for a,b in cuts if a<t)
    result=[]
    for index,item in enumerate(items):
        cursor=item['start']
        for a,b in cuts+[[item['end'],item['end']]]:
            if b<=item['start'] or a>item['end']:continue
            a=max(item['start'],a);b=min(item['end'],b)
            if a>cursor:
                result.append({'item_index':index,'source_start':item['source_start']+cursor-item['start'],'source_end':item['source_start']+a-item['start'],'record':cursor-removed_before(cursor)})
            cursor=max(cursor,b)
    if not result:raise ValueError('O plano eliminaria todo o material. Nenhuma copia criada.')
    return result

def plan_path(timeline):return state_dir()/'plans'/('timeline_'+hashlib.sha256(uid(timeline).encode()).hexdigest()+'.json')
def owned(marker):return marker.get('name','').upper().startswith(('SIL_ESTAVEL_','EMENDA_FINAL_'))
def add_marker(timeline,frame,data):
    return timeline.AddMarker(int(frame),data['color'],data['name'],data.get('note',''),int(data['duration']),data.get('customData',''))

def begin_analysis(bmd,strength=50):
    resolve,project,timeline,_=ctx(bmd);snapshot,_=capture(project,timeline);config=read_config()
    if strength not in (0,25,50,75,100):raise ValueError('Intensidade invalida.')
    work=state_dir()/'runs'/uuid.uuid4().hex;work.mkdir(parents=True)
    request=work/'request.json';output=work/'output.json'
    dump(request,{'items':snapshot['items'],'fps':snapshot['fps'],'strength':strength,'config':config})
    print('Magic Edit: Silero + energia; pausa >0,9s; intensidade',strength,flush=True)
    process=subprocess.Popen(config['python']+[str(ROOT/'worker.py'),str(request),str(output)],creationflags=(subprocess.CREATE_NEW_PROCESS_GROUP if os.name=='nt' else 0),start_new_session=(os.name!='nt'))
    return {'resolve':resolve,'project':project,'timeline':timeline,'snapshot':snapshot,'output':output,'process':process,'strength':strength,'started':time.monotonic()}

def finish_analysis(job):
    project,timeline,snapshot,output,process,strength=(job[k] for k in ('project','timeline','snapshot','output','process','strength'))
    if process.poll() is None:raise RuntimeError('Analise ainda em andamento.')
    active=job['resolve'].GetProjectManager().GetCurrentProject()
    if not active or uid(active)!=snapshot['project']:raise ValueError('O projeto ativo mudou durante a analise. Resultado nao aplicado.')
    if project.GetCurrentTimeline() is not timeline and uid(project.GetCurrentTimeline())!=uid(timeline):raise ValueError('A timeline ativa mudou durante a analise. Resultado nao aplicado.')
    if not output.is_file():raise RuntimeError('O analisador local nao concluiu. Confira a Console do Resolve.')
    report=json.loads(output.read_text('utf-8'))
    if process.returncode or not report.get('ok'):raise RuntimeError(report.get('error','Falha no analisador local.'))
    current,_=capture(project,timeline)
    if fingerprint(snapshot)!=fingerprint(current):raise ValueError('A timeline mudou durante a analise. Analise novamente.')
    sources={s['path']:s for s in report['sources']};cuts=[]
    for item in snapshot['items']:
        source=sources[item['path']];fps=source['fps']
        for cut in source['cuts']:
            a=max(item['source_start'],math.floor(cut['start']*fps+.5));b=min(item['source_end'],math.floor(cut['end']*fps+.5))
            if b>a:cuts.append((item['start']+a-item['source_start'],item['start']+b-item['source_start']))
    # Never combine adjacent markers across separate source clips.
    cuts=sorted(set(cuts));build_keeps(snapshot['items'],cuts)
    markers=timeline.GetMarkers() or {};old={int(k):v for k,v in markers.items() if owned(v)};new={}
    token=uuid.uuid4().hex
    for n,(a,b) in enumerate(cuts,1):
        frame=a-snapshot['start']
        if frame in markers and frame not in old:raise ValueError('Um marcador seu ocupa o inicio de um silencio; ele foi preservado.')
        if frame in new:raise ValueError('Dois silencios com inicio igual. Analise cancelada.')
        new[frame]={'color':'Green','name':PREFIX+str(n).zfill(3),'note':'Magic Edit | Silero + energia | pausa >0,9s | margens Desktop','duration':b-a,'customData':'MagicEdit09:'+token}
    try:
        for frame in old:
            if not timeline.DeleteMarkerAtFrame(frame):raise RuntimeError('Nao consegui atualizar um marcador antigo.')
        for frame,data in new.items():
            if not add_marker(timeline,frame,data):raise RuntimeError('Resolve recusou um marcador; plano nao aplicado.')
        dump(plan_path(timeline),{'snapshot':snapshot,'fingerprint':fingerprint(snapshot),'token':token,'sources':report['sources'],'strength':strength})
    except Exception:
        for frame in new:
            m=(timeline.GetMarkers() or {}).get(frame,{})
            if m.get('customData')=='MagicEdit09:'+token:timeline.DeleteMarkerAtFrame(frame)
        for frame,data in old.items():
            if frame not in (timeline.GetMarkers() or {}):add_marker(timeline,frame,data)
        raise
    for source in report['sources']:
        print('Protecao de palavras:',source['words'],'| JSON:',source['word_source'] or 'sem JSON correspondente; voz protegida pelo Silero',flush=True)
    print('Analise pronta:',len(cuts),'marcadores. Nenhum corte aplicado.',flush=True)
    return len(cuts)


def cancel_analysis(job):
    process=job['process']
    if process.poll() is not None:return
    if os.name=='nt':
        subprocess.run(['taskkill','/PID',str(process.pid),'/T','/F'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=15)
    else:
        try:os.killpg(process.pid,signal.SIGTERM)
        except ProcessLookupError:pass
    try:process.wait(timeout=10)
    except subprocess.TimeoutExpired:process.kill();process.wait(timeout=10)

def analisar(bmd,strength=50):
    job=begin_analysis(bmd,strength)
    try:job['process'].wait(timeout=14400);return finish_analysis(job)
    except BaseException:
        cancel_analysis(job)
        raise


def aplicar(bmd):
    resolve,project,original,pool=ctx(bmd);snapshot,refs=capture(project,original)
    path=plan_path(original)
    if not path.is_file():raise ValueError('Clique em ANALISAR antes de criar a copia.')
    plan=json.loads(path.read_text('utf-8'))
    if fingerprint(snapshot)!=plan['fingerprint']:raise ValueError('A timeline mudou depois da analise. Analise novamente.')
    cuts=[]
    for frame,data in (original.GetMarkers() or {}).items():
        if data.get('customData')=='MagicEdit09:'+plan['token'] and data.get('name','').startswith(PREFIX):
            a=snapshot['start']+int(frame);cuts.append((a,a+int(data['duration'])))
    if not cuts:raise ValueError('Nenhum marcador desta analise encontrado.')
    keeps=build_keeps(snapshot['items'],cuts)
    name=('MAGIC EDIT 09 - '+original.GetName())[:80]+' '+datetime.datetime.now().strftime('%H%M%S')+'_'+uuid.uuid4().hex[:4]
    new=pool.CreateEmptyTimeline(name)
    if not new:raise RuntimeError('Resolve nao criou a timeline de resultado.')
    try:
        new.SetStartTimecode(original.GetStartTimecode())
        if abs(float(new.GetSetting('timelineFrameRate'))-snapshot['fps'])>.01:
            new.SetSetting('useCustomSettings','1');new.SetSetting('timelineFrameRate',str(snapshot['fps']))
        if abs(float(new.GetSetting('timelineFrameRate'))-snapshot['fps'])>.01 or int(new.GetStartFrame())!=snapshot['start']:raise RuntimeError('A copia ficou com FPS/timecode diferentes. Original preservada.')
        if project.SetCurrentTimeline(new) is False:raise RuntimeError('Nao consegui selecionar a copia.')
        for keep in keeps:
            common={'mediaPoolItem':refs[keep['item_index']],'startFrame':keep['source_start'],'endFrame':keep['source_end']-1,'trackIndex':1,'recordFrame':keep['record']}
            result=pool.AppendToTimeline([{**common,'mediaType':1},{**common,'mediaType':2}])
            if not result:raise RuntimeError('Falha ao montar a copia. Original preservada.')
            if not new.SetClipsLinked(result,True):raise RuntimeError('Nao consegui vincular video e audio na copia.')
        videos=sorted(new.GetItemListInTrack('video',1) or [],key=lambda c:c.GetStart());audios=sorted(new.GetItemListInTrack('audio',1) or [],key=lambda c:c.GetStart())
        if len(videos)!=len(keeps) or len(audios)!=len(keeps):raise RuntimeError('A contagem da copia nao bateu com o plano.')
        for keep,video,audio in zip(keeps,videos,audios):
            length=keep['source_end']-keep['source_start']
            for clip in (video,audio):
                if int(clip.GetStart())!=keep['record'] or int(clip.GetEnd())!=keep['record']+length or abs(float(clip.GetLeftOffset())-keep['source_start'])>1e-6 or os.path.normcase(clip.GetMediaPoolItem().GetClipProperty('File Path'))!=os.path.normcase(snapshot['items'][keep['item_index']]['path']):raise RuntimeError('Posicoes, midia ou sincronismo da copia divergiram.')
        dump(state_dir()/'last_result.json',{'original':original.GetName(),'result':name,'cuts':cuts,'keeps':keeps,'verified':True})
        print('Copia conferida:',name,'| original preservada. Salve o projeto no Resolve.',flush=True)
        return True
    except Exception:
        project.SetCurrentTimeline(original)
        print('Copia incompleta mantida para diagnostico:',name,'| original preservada.',flush=True)
        raise
