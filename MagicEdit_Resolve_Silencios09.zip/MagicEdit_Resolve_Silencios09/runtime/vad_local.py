"""Silero VAD ONNX em CPU, áudio FFmpeg em fluxo; nunca toca no vídeo original.
Modelo MIT: https://github.com/snakers4/silero-vad/blob/master/src/silero_vad/data/silero_vad.onnx
"""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tempfile

MODEL_SHA256 = '1a153a22f4509e292a94e67d6f9b85e8deb25b4988682b7e174c65279d8788e3'
MODEL = Path(__file__).with_name('silero_vad.onnx')
CACHE = (Path(os.environ['APPDATA']) if os.environ.get('APPDATA') else Path.home() / '.config') / 'MagicEditDesktop' / 'vad_cache'
SAMPLE_RATE = 16000
FRAME = 512
SPEECH_PADDING = .22


def cache_key(path):
    stat = Path(path).stat()
    return hashlib.sha256(json.dumps([str(Path(path).resolve()), stat.st_size, stat.st_mtime_ns, MODEL_SHA256]).encode()).hexdigest()


def read_cache(path):
    try:
        document = json.loads((CACHE / (cache_key(path) + '.json')).read_text(encoding='utf-8'))
        if document.get('model') == MODEL_SHA256 and isinstance(document.get('speech'), list):
            return document
    except (OSError, ValueError, KeyError):
        pass
    return None


def write_cache(path, result):
    CACHE.mkdir(parents=True, exist_ok=True)
    dest = CACHE / (cache_key(path) + '.json')
    with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', dir=CACHE, suffix='.tmp', delete=False) as handle:
        json.dump(result, handle, ensure_ascii=False)
        pending = Path(handle.name)
    try:
        os.replace(pending, dest)
    finally:
        pending.unlink(missing_ok=True)


def probabilities(frames, session):
    """Entrada Silero: 512 amostras + 64 de contexto, estado recorrente por vídeo."""
    import numpy as np
    state = np.zeros((2, 1, 128), dtype=np.float32)
    context = np.zeros(64, dtype=np.float32)
    for frame in frames:
        x = np.frombuffer(frame, dtype='<i2').astype(np.float32) / 32768.0
        length = x.size
        if length < FRAME:
            x = np.pad(x, (0, FRAME - length))
        padded = np.concatenate((context, x))[None, :]
        out, state = session.run(None, {'input': padded, 'state': state, 'sr': np.array(SAMPLE_RATE, dtype=np.int64)})
        context = padded[0, -64:].copy()
        yield float(out.reshape(-1)[0]), length


def speech_intervals(scores, duration, threshold=.52, release=.35, min_speech=.16, min_silence=.32, padding=SPEECH_PADDING):
    """Histerese: speech=probabilidade, não inferência baseada no texto."""
    raw = []
    active = None
    low_since = None
    step = FRAME / SAMPLE_RATE
    for index, score in enumerate(scores):
        t = index * step
        if score >= threshold:
            if active is None:
                active = t
            low_since = None
        elif active is not None and score < release:
            if low_since is None:
                low_since = t
            if t - low_since >= min_silence:
                if low_since - active >= min_speech:
                    raw.append((active, low_since))
                active = None
                low_since = None
    if active is not None and duration - active >= min_speech:
        raw.append((active, duration))
    merged = []
    for start, end in raw:
        start, end = max(0, start - padding), min(duration, end + padding)
        if merged and start <= merged[-1][1]:
            merged[-1][1] = max(merged[-1][1], end)
        else:
            merged.append([start, end])
    return [{'start': round(a, 3), 'end': round(b, 3)} for a, b in merged]


def analyze(path, ffmpeg, duration):
    import numpy as np  # noqa: F401 - dependency check before decoding
    import onnxruntime as ort
    if hashlib.sha256(MODEL.read_bytes()).hexdigest() != MODEL_SHA256:
        raise RuntimeError('Modelo Silero ausente ou diferente do esperado.')
    cached = read_cache(path)
    if cached:
        return dict(cached, cached=True, speechPadding=SPEECH_PADDING)
    options = ort.SessionOptions()
    options.intra_op_num_threads = 1
    options.inter_op_num_threads = 1
    session = ort.InferenceSession(str(MODEL), sess_options=options, providers=['CPUExecutionProvider'])
    flags = subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0
    proc = subprocess.Popen([ffmpeg, '-hide_banner', '-loglevel', 'error', '-i', path, '-vn', '-map', '0:a:0', '-ac', '1', '-ar', str(SAMPLE_RATE), '-f', 's16le', '-acodec', 'pcm_s16le', '-'], stdout=subprocess.PIPE, stderr=subprocess.PIPE, creationflags=flags)
    scores = []
    count = 0
    try:
        def frames():
            nonlocal count
            while True:
                data = proc.stdout.read(FRAME * 2)
                if not data:
                    break
                count += len(data) // 2
                yield data
        for score, _ in probabilities(frames(), session):
            scores.append(score)
        stderr = proc.stderr.read()
        if proc.wait(timeout=30):
            raise RuntimeError('Falha ao analisar áudio: ' + stderr.decode('utf-8', 'replace')[-250:])
    finally:
        if proc.poll() is None:
            proc.kill()
            proc.wait()
        proc.stdout.close()
        proc.stderr.close()
    actual = min(float(duration), count / SAMPLE_RATE)
    result = {'state': 'done', 'model': MODEL_SHA256, 'speech': speech_intervals(scores, actual), 'duration': actual, 'cached': False, 'speechPadding': SPEECH_PADDING}
    write_cache(path, result)
    return result
