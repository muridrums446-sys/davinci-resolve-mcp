"""Extração leve da forma de onda, localmente, sem enviar vídeo/áudio à nuvem."""
from array import array
import sys


def peaks_from_pcm(data: bytes, rate: int=400, bins_per_second: int=20) -> list[int]:
    if rate <= 0 or bins_per_second <= 0:
        raise ValueError('Taxa de amostragem inválida')
    samples=array('h')
    samples.frombytes(data[:len(data)//2*2])
    if sys.byteorder != 'little': samples.byteswap()
    per=max(1,round(rate/bins_per_second))
    out=[]
    for pos in range(0,len(samples),per):
        seg=samples[pos:pos+per]
        value=max((abs(v) for v in seg),default=0)
        out.append(min(255,round(value*255/32768)))
    return out
