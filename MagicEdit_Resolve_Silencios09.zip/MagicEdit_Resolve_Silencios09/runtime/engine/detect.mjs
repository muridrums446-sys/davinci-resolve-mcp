import {readFileSync} from 'node:fs';
import {detectVerifiedSilences} from './editor_v09.js';
const data=JSON.parse(readFileSync(0,'utf8'));
process.stdout.write(JSON.stringify(detectVerifiedSilences(data.words,data.duration,data.peaks,data.rate,data.options)));
