// Motor puro, sem acesso ao sistema de arquivos. Testavel sem DaVinci e sem Groq.
export function formatTime(seconds = 0) {
  const s = Math.max(0, seconds);
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), sec = Math.floor(s % 60);
  return `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(sec).padStart(2,'0')}`;
}

export function xmlEscape(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&apos;');
}

export function fileUrl(path) {
  // file:///C:/... para o relink pelo Resolve. Escapa #, ?, acentos e espacos.
  const p = String(path).replace(/\\/g,'/');
  if (/^[a-zA-Z]:\//.test(p)) {
    return 'file:///' + p.slice(0,2) + p.slice(2).split('/').map(x => encodeURIComponent(x)).join('/');
  }
  return 'file://' + (p.startsWith('/') ? '' : '/') + p.split('/').map((x,i) => i === 0 && x === '' ? '' : encodeURIComponent(x)).join('/');
}

export function mergeIntervals(intervals, maxEnd, tolerance = 0.02) {
  const arr = intervals.map(x=>({start:Math.max(0,Number(x.start)),end:Math.min(maxEnd,Number(x.end))}))
    .filter(x => Number.isFinite(x.start) && Number.isFinite(x.end) && x.end > x.start)
    .sort((a,b)=>a.start-b.start || a.end-b.end);
  const out=[];
  for(const x of arr) {
    const prev = out.at(-1);
    if(prev && x.start <= prev.end+tolerance) prev.end = Math.max(prev.end,x.end);
    else out.push({...x});
  }
  return out;
}

export function suggestSilences(words, duration, minGap=0.7, pad=0.14) {
  const out=[];
  for(let i=1;i<words.length;i++) {
    const prev=words[i-1], cur=words[i];
    const gap=cur.start-prev.end;
    if(gap>=minGap && cur.start-pad>prev.end+pad) out.push({start:prev.end+pad,end:cur.start-pad});
  }
  if(words.length && words[0].start>1.0) out.unshift({start:0,end:Math.max(0,words[0].start-pad)});
  if(words.length && duration-words.at(-1).end>1.0) out.push({start:words.at(-1).end+pad,end:duration});
  return mergeIntervals(out,duration);
}

export function cutRanges(words, deletedIndices, extraCuts, duration) {
  // Palavras consecutivas excluidas sao um unico corte CONTINUO:
  // inclui os pequenos silencios internos da frase removida.
  const idx=[...deletedIndices].filter(i=>Number.isInteger(i)&&i>=0&&i<words.length).sort((a,b)=>a-b);
  const wordCuts=[];
  // Timestamps do ASR podem se sobrepor. Os vizinhos mantidos têm prioridade.
  const keptBefore=[];let protectedEnd=0;
  for(let i=0;i<words.length;i++){
    keptBefore[i]=protectedEnd;
    if(!deletedIndices.has(i))protectedEnd=Math.max(protectedEnd,words[i].end);
  }
  for(let j=0;j<idx.length;){
    let k=j;
    while(k+1<idx.length && idx[k+1]===idx[k]+1)k++;
    const first=idx[j],last=idx[k];
    const start=Math.max(0,words[first].start-0.018,keptBefore[first]);
    const end=Math.min(duration,Math.max(...words.slice(first,last+1).map(w=>w.end+0.018)),
      last+1<words.length?words[last+1].start:duration);
    if(end>start)wordCuts.push({start,end});
    j=k+1;
  }
  return mergeIntervals([...wordCuts,...extraCuts], duration,0);
}

export function keepRanges(duration, cuts, fps) {
  const merged=mergeIntervals(cuts,duration,0);
  const f=s=>Math.max(0,Math.round(s*fps));
  const total=f(duration);
  let cursor=0; const out=[];
  for(const c of merged) {
    const start=Math.max(cursor, Math.min(total,f(c.start)));
    const end=Math.max(start, Math.min(total,f(c.end)));
    if(start-cursor>=1) out.push({in:cursor,out:start});
    cursor=Math.max(cursor,end);
  }
  if(total-cursor>=1) out.push({in:cursor,out:total});
  return out;
}

export function fpsRate(num,den) {
  const n=Number(num)||30, d=Number(den)||1, fps=n/d;
  const approx=(target)=>Math.abs(fps-target)<0.015;
  if(approx(30000/1001)) return {timebase:30,ntsc:'TRUE',fps};
  if(approx(24000/1001)) return {timebase:24,ntsc:'TRUE',fps};
  if(approx(60000/1001)) return {timebase:60,ntsc:'TRUE',fps};
  if(!Number.isInteger(fps) || fps<10 || fps>120) throw new Error(`FPS nao suportado para XML FCP7: ${n}/${d}`);
  return {timebase:fps,ntsc:'FALSE',fps};
}

export function exportFcp7Xml({path, media, words, deletedIndices, extraCuts=[], sequenceName='Magic Edit'}) {
  if(!path || !media || !Array.isArray(words)) throw new Error('Faltam arquivo e transcricao.');
  const rate=fpsRate(media.fpsNum,media.fpsDen);
  const fps=rate.fps;
  const segments=keepRanges(media.duration,cutRanges(words,deletedIndices,extraCuts,media.duration),fps);
  if(!segments.length) throw new Error('Todos os trechos foram excluidos.');
  const r=`<rate><timebase>${rate.timebase}</timebase><ntsc>${rate.ntsc}</ntsc></rate>`;
  const fileID='file-master-1', fName=xmlEscape(media.name || 'video.mp4');
  const sourcePath=xmlEscape(fileUrl(path));
  const totalFrames=Math.round(media.duration*fps);
  const w=Math.round(media.width||1920), h=Math.round(media.height||1080);
  const file=`<file id="${fileID}"><name>${fName}</name><pathurl>${sourcePath}</pathurl><duration>${totalFrames}</duration>${r}<media><video><samplecharacteristics>${r}<width>${w}</width><height>${h}</height><anamorphic>FALSE</anamorphic></samplecharacteristics></video><audio><samplecharacteristics><depth>16</depth><samplerate>48000</samplerate></samplecharacteristics><channelcount>2</channelcount></audio></media></file>`;
  const entries={video:[],audio:[]}; let position=0;
  for (let i=0;i<segments.length;i++) {
    const seg=segments[i], length=seg.out-seg.in, start=position, end=start+length;
    for(const kind of ['video','audio']) {
      const id=(kind==='video'?'v':'a')+'_'+(i+1);
      const other=(kind==='video'?'a':'v')+'_'+(i+1);
      const refs=`<link><linkclipref>${id}</linkclipref><mediatype>${kind}</mediatype><trackindex>1</trackindex><clipindex>${i+1}</clipindex></link><link><linkclipref>${other}</linkclipref><mediatype>${kind==='video'?'audio':'video'}</mediatype><trackindex>1</trackindex><clipindex>${i+1}</clipindex></link>`;
      const srcFile = (i===0 && kind==='video') ? file : `<file id="${fileID}"/>`;
      const audioInfo=kind==='audio'?'<sourcetrack><mediatype>audio</mediatype><trackindex>1</trackindex></sourcetrack>':'';
      entries[kind].push(`<clipitem id="${id}"><name>${fName}</name><enabled>TRUE</enabled><duration>${totalFrames}</duration>${r}<start>${start}</start><end>${end}</end><in>${seg.in}</in><out>${seg.out}</out>${srcFile}${audioInfo}${refs}</clipitem>`);
    }
    position=end;
  }
  const name=xmlEscape(sequenceName);
  return `<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE xmeml>\n<xmeml version="5"><sequence id="sequence-1"><name>${name}</name><duration>${position}</duration>${r}<timecode>${r}<string>00:00:00:00</string><frame>0</frame><displayformat>NDF</displayformat></timecode><media><video><format><samplecharacteristics>${r}<width>${w}</width><height>${h}</height><anamorphic>FALSE</anamorphic></samplecharacteristics></format><track>${entries.video.join('')}<enabled>TRUE</enabled><locked>FALSE</locked></track></video><audio><track>${entries.audio.join('')}<enabled>TRUE</enabled><locked>FALSE</locked></track></audio></media></sequence></xmeml>`;
}

export function summarizeTimeline(media, words, deletedIndices, extraCuts=[]) {
  if(!media) return {original:0,edited:0,removed:0,clips:0};
  const fps=media.fpsNum/media.fpsDen;
  const keep=keepRanges(media.duration,cutRanges(words,deletedIndices,extraCuts,media.duration),fps);
  const edited=keep.reduce((s,x)=>s+(x.out-x.in)/fps,0);
  return {original:media.duration,edited,removed:Math.max(0,media.duration-edited),clips:keep.length};
}

// Identifica a palavra cujo intervalo coincide com o tempo do player.
// Busca binaria: mesmo transcricoes longas (milhares de palavras) continuam leves.
// Retorna -1 durante silencios longos, evitando manter palavras antigas acesas.
export function findWordAtTime(words, time, anticipation = 0.045, linger = 0.07) {
  if (!Array.isArray(words) || !words.length || !Number.isFinite(time) || time < 0) return -1;
  let lo=0, hi=words.length;
  const target=time+anticipation;
  while (lo<hi) {
    const mid=(lo+hi)>>1;
    if (words[mid].start <= target) lo=mid+1; else hi=mid;
  }
  // Checar a palavra mais recente e sua vizinha evita perder pequenos intervalos
  // de sobreposicao nos timestamps do Whisper.
  for (let i=Math.min(words.length-1,lo-1);i>=Math.max(0,lo-2);i--) {
    const w=words[i];
    if (time >= w.start-anticipation && time <= w.end+linger) return i;
  }
  return -1;
}
